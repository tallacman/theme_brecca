<?php
namespace Concrete\Package\TallacmansContainerMaker\Service;

use Concrete\Core\Page\Theme\Theme;

class ContainerGenerator
{
    public static function getPresets()
    {
        return [
            'hero' => [
                'name' => t('Hero'),
                'description' => t('Large hero section with title and body areas.'),
                'areas' => ['Title', 'Main'],
                'class' => 'cm-hero',
                'inner' => 'container',
            ],
            'two_column' => [
                'name' => t('Two Column'),
                'description' => t('Responsive two-column section.'),
                'areas' => ['Left Column', 'Right Column'],
                'class' => 'cm-two-column',
                'inner' => 'container',
            ],
            'full_width' => [
                'name' => t('Full Width'),
                'description' => t('Full-width editable section.'),
                'areas' => ['Main'],
                'class' => 'cm-full-width',
                'inner' => 'container-fluid',
            ],
            'card_grid' => [
                'name' => t('Card Grid'),
                'description' => t('Section with title and three editable card areas.'),
                'areas' => ['Title', 'Card One', 'Card Two', 'Card Three'],
                'class' => 'cm-card-grid',
                'inner' => 'container',
            ],
            'feature_band' => [
                'name' => t('Feature Band'),
                'description' => t('Headline, intro copy, and two feature columns.'),
                'areas' => ['Title', 'Intro', 'Feature One', 'Feature Two'],
                'class' => 'cm-feature-band',
                'inner' => 'container',
            ],
            'content_sidebar' => [
                'name' => t('Content Sidebar'),
                'description' => t('Main content plus a supporting sidebar area.'),
                'areas' => ['Main Content', 'Sidebar'],
                'class' => 'cm-content-sidebar',
                'inner' => 'container',
            ],
            'cta_banner' => [
                'name' => t('CTA Banner'),
                'description' => t('A centered call-to-action band with headline and buttons.'),
                'areas' => ['Heading', 'Body', 'Actions'],
                'class' => 'cm-cta-banner',
                'inner' => 'container',
            ],
            'testimonial_strip' => [
                'name' => t('Testimonial Strip'),
                'description' => t('A simple testimonial area with three quote blocks.'),
                'areas' => ['Title', 'Testimonial One', 'Testimonial Two', 'Testimonial Three'],
                'class' => 'cm-testimonial-strip',
                'inner' => 'container',
            ],
        ];
    }

    public function generate(Theme $theme, array $handles, $register = true)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $presets = static::getPresets();
        $themePath = $this->getThemePath($theme);

        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        foreach ($handles as $handle) {
            if (!isset($presets[$handle])) {
                $result['errors'][] = t('Unknown preset: %s', $handle);
                continue;
            }
            $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
            if (file_exists($file)) {
                $result['skipped'][] = $file;
            } else {
                $php = $this->buildContainerPhp($presets[$handle]);
                if (@file_put_contents($file, $php) === false) {
                    $result['errors'][] = t('Could not write file: %s', $file);
                    continue;
                }
                $result['created'][] = $file;
            }

            if ($register) {
                $registered = $this->tryRegisterContainer($handle, $presets[$handle]['name']);
                if ($registered === true) {
                    $result['registered'][] = $presets[$handle]['name'] . ' (' . $handle . ')';
                } elseif (is_string($registered)) {
                    $result['errors'][] = $registered;
                }
            }
        }

        return $result;
    }

    protected function buildContainerPhp(array $preset)
    {
        $areas = var_export($preset['areas'], true);
        $class = addslashes($preset['class']);
        $inner = addslashes($preset['inner']);

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Area\ContainerArea;

\$areas = {$areas};
?>
<section class="{$class}">
    <div class="{$inner}">
        <?php foreach (\$areas as \$areaName) { ?>
            <div class="{$class}__area {$class}__area--<?= h(strtolower(str_replace(' ', '-', \$areaName))) ?>">
                <?php
                \$area = new ContainerArea(\$container, \$areaName);
                if (method_exists(\$area, 'setAreaGridMaximumColumns')) {
                    \$area->setAreaGridMaximumColumns(12);
                }
                if (method_exists(\$area, 'enableGridContainer')) {
                    \$area->enableGridContainer();
                }
                \$area->display(\$c);
                ?>
            </div>
        <?php } ?>
    </div>
</section>
<style>
.ccm-edit-mode .{$class}__area {
    min-height: 72px;
    outline: 1px dashed rgba(0, 0, 0, .25);
    outline-offset: -1px;
    padding: .5rem;
}
.ccm-edit-mode .{$class}__area .ccm-area {
    min-height: 48px;
}
</style>
PHP;
    }


    public function generateFlex(Theme $theme, array $data)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $themePath = $this->getThemePath($theme);
        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $name = trim((string) ($data['name'] ?? ''));
        $handle = $this->sanitizeHandle((string) ($data['handle'] ?? ''));
        if ($name === '') {
            $name = t('Custom CSS Grid Container');
        }
        if ($handle === '') {
            $handle = $this->sanitizeHandle($name);
        }
        if ($handle === '') {
            $result['errors'][] = t('Please enter a valid container handle.');
            return $result;
        }

        $areas = $this->parseAreaNames((string) ($data['areas'] ?? 'Main'));
        if (empty($areas)) {
            $result['errors'][] = t('Please enter at least one editable area.');
            return $result;
        }

        $areaWidths = $this->parseAreaWidths((string) ($data['area_widths'] ?? ''), $areas);
        $areaGridColumns = $this->parseAreaGridColumns((string) ($data['area_grid_columns'] ?? ''), $areas);
        $areaFullRows = $this->parseAreaFullRows((string) ($data['area_full_rows'] ?? ''), $areas);
        $settings = $this->normalizeFlexSettings($data);

        $responsiveColumns = $this->parseResponsiveColumns((string) ($data['responsive_columns'] ?? ''), $areas);
        $nestedAreas = $this->parseAreaFullRows((string) ($data['nested_areas'] ?? ''), $areas);
        $gridSettings = $this->parseGridSettings((string) ($data['grid_settings'] ?? ''));
        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
        $overwrite = !empty($data['overwrite']);
        if (file_exists($file) && !$overwrite) {
            $result['skipped'][] = $file;
        } else {
            $php = $this->buildFlexContainerPhp($handle, $areas, $settings, $areaWidths, $areaFullRows, $responsiveColumns ?? [], $nestedAreas ?? [], $gridSettings);
            if (@file_put_contents($file, $php) === false) {
                $result['errors'][] = t('Could not write file: %s', $file);
                return $result;
            }
            $result['created'][] = $file;
        }

        if (!empty($data['register'])) {
            $registered = $this->tryRegisterContainer($handle, $name);
            if ($registered === true) {
                $result['registered'][] = $name . ' (' . $handle . ')';
            } elseif (is_string($registered)) {
                $result['errors'][] = $registered;
            }
        }

        return $result;
    }

    protected function buildFlexContainerPhp($handle, array $areas, array $settings, array $areaWidths = [], array $areaFullRows = [], array $responsiveColumns = [], array $nestedAreas = [], array $gridSettings = [])
    {
        return $this->buildCssGridContainerPhp($handle, $areas, $settings, $areaFullRows, $responsiveColumns, $nestedAreas, $gridSettings);
    }

    protected function buildCssGridContainerPhp($handle, array $areas, array $settings, array $areaFullRows = [], array $responsiveColumns = [], array $nestedAreas = [], array $gridSettings = [])
    {
        $areasExport = var_export($areas, true);
        $class = 'cm-grid-' . str_replace('_', '-', $handle);
        $inner = addslashes($settings['inner']);
        $gap = addslashes($settings['gap']);
        $padding = addslashes($settings['padding']);
        $rowGap = addslashes($gridSettings['rowGap'] ?? '');
        $columnGap = addslashes($gridSettings['columnGap'] ?? '');
        $minTrack = addslashes($gridSettings['minTrack'] ?? '0');
        $justifyItems = addslashes($gridSettings['justifyItems'] ?? 'stretch');
        $alignItems = addslashes($gridSettings['alignItems'] ?? 'stretch');
        $autoFlow = addslashes($gridSettings['autoFlow'] ?? 'row');

        $areaTracks = [];
        foreach ($areas as $areaName) {
            $fullRow = in_array($areaName, $areaFullRows, true);
            $tracks = $responsiveColumns[$areaName] ?? ['desktop' => '1fr', 'tablet' => '1fr', 'mobile' => '1fr'];
            $areaTracks[$areaName] = [
                'desktop' => $fullRow ? '1fr' : $this->safeCssTrackValue($tracks['desktop'] ?? '1fr', '1fr', $minTrack),
                'tablet' => $fullRow ? '1fr' : $this->safeCssTrackValue($tracks['tablet'] ?? '1fr', '1fr', $minTrack),
                'mobile' => $fullRow ? '1fr' : $this->safeCssTrackValue($tracks['mobile'] ?? '1fr', '1fr', $minTrack),
            ];
        }

        $desktopColumns = implode(' ', array_map(static function ($areaName) use ($areaTracks) {
            return $areaTracks[$areaName]['desktop'];
        }, $areas));
        $tabletColumns = implode(' ', array_map(static function ($areaName) use ($areaTracks) {
            return $areaTracks[$areaName]['tablet'];
        }, $areas));
        $mobileColumns = implode(' ', array_map(static function ($areaName) use ($areaTracks) {
            return $areaTracks[$areaName]['mobile'];
        }, $areas));

        $areaTracksExport = var_export($areaTracks, true);
        $fullRowsExport = var_export($areaFullRows, true);
        $nestedExport = var_export($nestedAreas, true);
        $gridSettingsExport = var_export($gridSettings, true);

        $rowGapCss = $rowGap !== '' ? "\n    row-gap: {$rowGap};" : '';
        $columnGapCss = $columnGap !== '' ? "\n    column-gap: {$columnGap};" : '';

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Area\ContainerArea;

\$areas = {$areasExport};
\$areaTracks = {$areaTracksExport};
\$areaFullRows = {$fullRowsExport};
\$nestedAreas = {$nestedExport};
\$gridSettings = {$gridSettingsExport};
?>
<section class="{$class}">
    <div class="{$inner}">
        <div class="{$class}__grid">
            <?php foreach (\$areas as \$areaName) { ?>
                <div class="{$class}__item<?= in_array(\$areaName, \$areaFullRows, true) ? ' {$class}__item--full' : '' ?>">
                    <?php
                    \$area = new ContainerArea(\$container, \$areaName);
                    if (in_array(\$areaName, \$nestedAreas, true)) {
                        if (method_exists(\$area, 'setAreaGridMaximumColumns')) {
                            \$area->setAreaGridMaximumColumns(12);
                        }
                        if (method_exists(\$area, 'enableGridContainer')) {
                            \$area->enableGridContainer();
                        }
                    }
                    \$area->display(\$c);
                    ?>
                </div>
            <?php } ?>
        </div>
    </div>
</section>
<style>
.{$class} {
    padding: {$padding};
}
.{$class}__grid {
    display: grid;
    grid-template-columns: {$desktopColumns};
    gap: {$gap};{$rowGapCss}{$columnGapCss}
    grid-auto-flow: {$autoFlow};
    justify-items: {$justifyItems};
    align-items: {$alignItems};
}
.{$class}__item {
    min-width: 0;
}
.{$class}__item--full {
    grid-column: 1 / -1;
}
@media (max-width: 991px) {
    .{$class}__grid { grid-template-columns: {$tabletColumns}; }
}
@media (max-width: 767px) {
    .{$class}__grid { grid-template-columns: {$mobileColumns}; }
}
</style>
PHP;
    }

    protected function parseAreaNames($input)
    {
        $parts = preg_split('/[\r\n,]+/', $input);
        $areas = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $areas[] = $part;
            }
        }
        return array_values(array_unique($areas));
    }

    protected function parseAreaWidths($input, array $areas)
    {
        $widths = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $width] = array_map('trim', explode('::', $line, 2));
            if ($area !== '' && in_array($area, $areas, true)) {
                $widths[$area] = $this->safeCssLength($width, '0');
            }
        }
        return $widths;
    }


    protected function parseAreaGridColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $span] = array_map('trim', explode('::', $line, 2));
            $span = (int) $span;
            if ($area !== '' && in_array($area, $areas, true) && $span >= 1 && $span <= 12) {
                $columns[$area] = $span;
            }
        }
        return $columns;
    }



    protected function parseResponsiveColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_pad(explode('|', $value), 3, '1fr');
            $columns[$area] = [
                'desktop' => $this->normalizeTrackToken($parts[0]),
                'tablet' => $this->normalizeTrackToken($parts[1]),
                'mobile' => $this->normalizeTrackToken($parts[2]),
            ];
        }
        return $columns;
    }

    protected function parseGridSettings($input)
    {
        $defaults = [
            'rowGap' => '',
            'columnGap' => '',
            'minTrack' => '0',
            'justifyItems' => 'stretch',
            'alignItems' => 'stretch',
            'autoFlow' => 'row',
        ];
        if ($input === '') {
            return $defaults;
        }
        $decoded = json_decode($input, true);
        if (!is_array($decoded)) {
            return $defaults;
        }
        return [
            'rowGap' => $this->safeCssLength($decoded['rowGap'] ?? '', ''),
            'columnGap' => $this->safeCssLength($decoded['columnGap'] ?? '', ''),
            'minTrack' => $this->safeCssLength($decoded['minTrack'] ?? '0', '0'),
            'justifyItems' => $this->inList($decoded['justifyItems'] ?? 'stretch', ['stretch', 'start', 'center', 'end'], 'stretch'),
            'alignItems' => $this->inList($decoded['alignItems'] ?? 'stretch', ['stretch', 'start', 'center', 'end'], 'stretch'),
            'autoFlow' => $this->inList($decoded['autoFlow'] ?? 'row', ['row', 'column', 'row dense', 'column dense'], 'row'),
        ];
    }

    protected function normalizeTrackToken($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '1fr';
        }
        if (preg_match('/^\d+$/', $value)) {
            return max(1, min(12, (int) $value)) . 'fr';
        }
        return $value;
    }

    protected function safeCssTrackValue($value, $default = '1fr', $minTrack = '0')
    {
        $value = $this->normalizeTrackToken($value);
        if (!$this->isSafeCssTrack($value)) {
            $value = $default;
        }
        $minTrack = trim((string) $minTrack);
        if ($minTrack !== '' && $minTrack !== '0' && $this->safeCssLength($minTrack, '') !== '') {
            return 'minmax(' . $this->safeCssLength($minTrack, '0') . ', ' . $value . ')';
        }
        return $value;
    }

    protected function isSafeCssTrack($value)
    {
        $value = trim((string) $value);
        if (preg_match('/^auto$/i', $value)) {
            return true;
        }
        if (preg_match('/^fit-content\([^;]+\)$/i', $value)) {
            return preg_match('/^fit-content\(([-0-9.%a-z,\s]+)\)$/i', $value);
        }
        if (preg_match('/^(\d+(\.\d+)?|\.\d+)fr$/', $value)) {
            return true;
        }
        if (preg_match('/^[-0-9.]+(px|rem|em|%|vw|vh)$/', $value)) {
            return true;
        }
        if (preg_match('/^clamp\([^;]+\)$/i', $value)) {
            return preg_match('/^clamp\(([-0-9.%a-z,\s]+)\)$/i', $value);
        }
        if (preg_match('/^minmax\([^;]+\)$/i', $value)) {
            return preg_match('/^minmax\(([-0-9.%a-z,\s]+)\)$/i', $value);
        }
        return false;
    }

    protected function parseAreaFullRows($input, array $areas)
    {
        $fullRows = [];
        $lines = preg_split('/[\r\n,]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && in_array($line, $areas, true)) {
                $fullRows[] = $line;
            }
        }
        return array_values(array_unique($fullRows));
    }

    protected function normalizeFlexSettings(array $data)
    {
        return [
            'layout_mode' => 'css_grid',
            'framework' => 'custom',
            'direction' => 'row',
            'wrap' => 'wrap',
            'align' => 'stretch',
            'justify' => 'flex-start',
            'inner' => $this->inList($data['inner'] ?? 'container', ['container', 'container-fluid', ''], 'container'),
            'mobile' => 'column',
            'gap' => $this->safeCssLength($data['gap'] ?? '1rem', '1rem'),
            'padding' => $this->safeCssLengthList($data['padding'] ?? '2rem 0', '2rem 0'),
            'basis' => '0',
            'grow' => '0',
            'shrink' => '0',
        ];
    }

    protected function sanitizeHandle($handle)
    {
        $handle = strtolower(trim($handle));
        $handle = preg_replace('/[^a-z0-9]+/', '_', $handle);
        return trim($handle, '_');
    }

    protected function inList($value, array $allowed, $default)
    {
        $value = (string) $value;
        return in_array($value, $allowed, true) ? $value : $default;
    }

    protected function safeCssLength($value, $default)
    {
        $value = trim((string) $value);
        return preg_match('/^[-0-9.]+(px|rem|em|%|vw|vh)?$/', $value) ? $value : $default;
    }

    protected function safeCssLengthList($value, $default)
    {
        $value = trim((string) $value);
        return preg_match('/^[-0-9. ]+(px|rem|em|%|vw|vh)?( [-0-9.]+(px|rem|em|%|vw|vh)?){0,3}$/', $value) ? $value : $default;
    }

    protected function getThemePath(Theme $theme)
    {
        if (method_exists($theme, 'getThemeDirectory')) {
            $dir = $theme->getThemeDirectory();
            if ($dir && is_dir($dir)) {
                return $dir;
            }
        }

        $handle = $theme->getThemeHandle();
        $paths = [
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ];
        foreach ($paths as $path) {
            if (is_dir($path)) {
                return $path;
            }
        }
        return null;
    }

    protected function tryRegisterContainer($handle, $name)
    {
        // Concrete 9 stores containers as Doctrine entities. Class names have varied in some builds,
        // so this method is intentionally defensive. File generation still works if this fails.
        $classes = [
            '\\Concrete\\Core\\Entity\\Page\\Container',
            '\\Concrete\\Core\\Entity\\Page\\ContainerTemplate',
        ];

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                continue;
            }
            try {
                $app = \Core::make('app');
                $em = $app->make('database/orm')->entityManager();
                $repo = $em->getRepository($class);
                $existing = method_exists($repo, 'findOneBy') ? $repo->findOneBy(['containerHandle' => $handle]) : null;
                if ($existing) {
                    return true;
                }
                $entity = new $class();
                if (method_exists($entity, 'setContainerName')) {
                    $entity->setContainerName($name);
                }
                if (method_exists($entity, 'setContainerHandle')) {
                    $entity->setContainerHandle($handle);
                }
                $em->persist($entity);
                $em->flush();
                return true;
            } catch (\Throwable $e) {
                return t('Created file for %s, but automatic registration failed: %s', $handle, $e->getMessage());
            }
        }

        return t('Created file for %s, but automatic registration is not available on this Concrete install. Add it manually in Dashboard → Pages & Themes → Containers.', $handle);
    }
}
