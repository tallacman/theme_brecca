<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>

<div class="alert alert-info">
    <?= t('Tallacmans Container Maker v0.8.6 focuses the designer on browser-native CSS Grid output with fr and clamp() track sizing.') ?>
</div>

<ul class="nav nav-tabs mb-3" id="cmContainerMakerTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#cm-builder" type="button"><?= t('Visual Designer') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-library" type="button"><?= t('Container Library') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-presets" type="button"><?= t('Preset Installer') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-manage" type="button"><?= t('Manage Installed Containers') ?></button></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade show active" id="cm-builder">
        <form method="post" action="<?= $view->action('build_flex') ?>" id="cmBuilderForm">
            <?php $token->output('tallacmans_container_maker_build_flex'); ?>
            <input type="hidden" name="areas" id="flexAreas" value="Main">
            <input type="hidden" name="area_widths" id="flexAreaWidths" value="">
            <input type="hidden" name="area_grid_columns" id="flexAreaGridColumns" value="">
            <input type="hidden" name="area_full_rows" id="flexAreaFullRows" value="">
            <input type="hidden" name="responsive_columns" id="flexResponsiveColumns" value="">
            <input type="hidden" name="nested_areas" id="flexNestedAreas" value="">
            <input type="hidden" name="layout_mode" id="flexLayoutMode" value="css_grid">
            <input type="hidden" name="grid_settings" id="flexGridSettings" value="">
            <input type="hidden" name="editing_handle" id="cmEditingHandle" value="">

            <div class="row">
                <div class="col-xl-4">
                    <fieldset>
                        <legend><?= t('Container') ?></legend>
                        <div class="mb-3">
                            <label class="form-label" for="flexThemeID"><?= t('Active Theme') ?></label>
                            <div class="form-control-plaintext border rounded px-3 py-2">
                                <?php if ($activeTheme && $activeTheme->getThemeID()) { ?>
                                    <strong><?= h($activeTheme->getThemeName()) ?></strong> — <?= h($activeTheme->getThemeHandle()) ?>
                                <?php } else { ?>
                                    <?= t('No active theme available.') ?>
                                <?php } ?>
                            </div>
                            <?php if ($activeTheme && $activeTheme->getThemeID()) { ?>
                                <input type="hidden" name="themeID" id="flexThemeID" value="<?= h($activeTheme->getThemeID()) ?>">
                            <?php } ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="flexName"><?= t('Container Name') ?></label>
                            <input type="text" name="name" id="flexName" class="form-control" value="" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="flexHandle"><?= t('Handle / PHP filename') ?></label>
                            <input type="text" name="handle" id="flexHandle" class="form-control" value="">
                            <div class="form-text"><?= t('File:') ?> <strong><span id="flexFilePreview"><?= t('Enter a container name') ?></span></strong></div>
                            <div class="form-text d-none" id="cmEditingStatus"></div>
                        </div>
                    </fieldset>

                    <fieldset class="mt-3">
                        <legend><?= t('CSS Grid Settings') ?></legend>
                        <div class="row">
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexGap"><?= t('Gap') ?></label><input name="gap" id="flexGap" class="form-control" value="1rem"></div>
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexRowGap"><?= t('Row gap') ?></label><input id="flexRowGap" class="form-control" value="" placeholder="<?= h(t('Same as gap')) ?>"></div>
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexColumnGap"><?= t('Column gap') ?></label><input id="flexColumnGap" class="form-control" value="" placeholder="<?= h(t('Same as gap')) ?>"></div>
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexMinTrack"><?= t('Min track width') ?></label><input id="flexMinTrack" class="form-control" value="0" placeholder="0"><div class="form-text"><?= t('Wraps each track as minmax(min, track). Use 0 or a length like 200px.') ?></div></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Padding</label><input name="padding" id="flexPadding" class="form-control" value="2rem 0"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Inner wrapper</label><select name="inner" id="flexInner" class="form-select"><option value="container">container</option><option value="container-fluid">container-fluid</option><option value="">none</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexJustifyItems"><?= t('Justify items') ?></label><select id="flexJustifyItems" class="form-select"><option value="stretch">stretch</option><option value="start">start</option><option value="center">center</option><option value="end">end</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexAlignItems"><?= t('Align items') ?></label><select id="flexAlignItems" class="form-select"><option value="stretch">stretch</option><option value="start">start</option><option value="center">center</option><option value="end">end</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label" for="flexAutoFlow"><?= t('Auto flow') ?></label><select id="flexAutoFlow" class="form-select"><option value="row">row</option><option value="column">column</option><option value="row dense">row dense</option><option value="column dense">column dense</option></select></div>
                        </div>
                    </fieldset>

                    <div class="mt-3 d-flex gap-2 flex-wrap">
                        <button type="button" id="cmAddArea" class="btn btn-outline-primary"><?= t('Add Area') ?></button>
                        <button type="button" id="cmUndo" class="btn btn-outline-secondary"><?= t('Undo') ?></button>
                        <button type="button" id="cmRedo" class="btn btn-outline-secondary"><?= t('Redo') ?></button>
                        <button type="button" id="cmRestoreDeleted" class="btn btn-outline-warning"><?= t('Restore Deleted') ?></button>
                        <button type="button" id="cmNewContainer" class="btn btn-outline-secondary d-none"><?= t('New Container') ?></button>
                    </div>
                    <hr>
                    <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="register" id="flexRegister" value="1" checked><label class="form-check-label" for="flexRegister"><?= t('Auto-register container') ?></label></div>
                    <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="overwrite" id="flexOverwrite" value="1"><label class="form-check-label" for="flexOverwrite"><?= t('Overwrite existing PHP file') ?></label></div>
                    <button type="submit" class="btn btn-primary" id="cmSaveContainerButton"><?= t('Save Container PHP') ?></button>
                </div>

                <div class="col-xl-8">
                    <h3 class="mb-2"><?= t('Visual Canvas') ?></h3>
                    <p class="text-muted" id="cmCanvasHelp"></p>
                    <div id="cmPreviewShell" class="cm-preview-shell"><div id="cmPreviewCanvas" class="cm-preview-canvas" data-breakpoint="desktop"></div></div>
                    <div class="row g-3 mt-2" id="cmViewportPreviews">
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Desktop</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasDesktop" data-breakpoint="desktop"></div></div></div>
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Tablet</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasTablet" data-breakpoint="tablet"></div></div></div>
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Mobile</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasMobile" data-breakpoint="mobile"></div></div></div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <h4><?= t('Area Settings') ?></h4>
                            <div id="cmAreaInspector" class="cm-area-inspector"></div>
                        </div>
                    </div>

                    <div class="card mt-3">
                        <div class="card-header"><?= t('Presets / Import / Export') ?></div>
                        <div class="card-body d-flex gap-2 flex-wrap align-items-center">
                            <input id="cmPresetName" class="form-control" style="max-width:260px" placeholder="<?= h(t('Preset name')) ?>">
                            <button type="button" id="cmSavePreset" class="btn btn-outline-primary"><?= t('Save as Preset') ?></button>
                            <button type="button" id="cmExportPreset" class="btn btn-outline-secondary"><?= t('Export JSON') ?></button>
                            <label class="btn btn-outline-secondary mb-0"><?= t('Import JSON') ?><input type="file" id="cmImportPreset" accept="application/json" hidden></label>
                            <select id="cmPresetSelect" class="form-select" style="max-width:260px"><option value=""><?= t('Load saved preset…') ?></option></select>
                            <button type="button" id="cmLoadPreset" class="btn btn-outline-secondary"><?= t('Load') ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="tab-pane fade" id="cm-library">
        <div class="row mb-3"><div class="col-md-6"><input type="search" id="cmLibrarySearch" class="form-control" placeholder="<?= h(t('Search containers by name, handle, category, or version…')) ?>"></div></div>
        <div id="cmLibraryList" class="row g-3"></div>
    </div>

    <div class="tab-pane fade" id="cm-presets">
        <form method="post" action="<?= $view->action('generate') ?>">
            <?php $token->output('tallacmans_container_maker_generate'); ?>
            <div class="mb-3"><label class="form-label"><?= t('Active Theme') ?></label><div class="form-control-plaintext border rounded px-3 py-2"><?php if ($activeTheme && $activeTheme->getThemeID()) { ?><strong><?= h($activeTheme->getThemeName()) ?></strong> — <?= h($activeTheme->getThemeHandle()) ?><?php } else { ?><?= t('No active theme available.') ?><?php } ?></div></div>
            <div class="row">
                <?php foreach ($presets as $handle => $preset) { ?>
                    <div class="col-md-6 col-lg-3 mb-3"><label class="card h-100"><div class="card-body"><input type="checkbox" name="presets[]" value="<?= h($handle) ?>"> <strong><?= h($preset['name']) ?></strong><p class="text-muted mb-0"><?= h($preset['description']) ?></p></div></label></div>
                <?php } ?>
            </div>
            <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="register" value="1" checked id="cmPresetRegister"><label class="form-check-label" for="cmPresetRegister"><?= t('Auto-register created containers') ?></label></div>
            <button class="btn btn-primary" type="submit"><?= t('Install Selected Presets') ?></button>
        </form>
    </div>

    <div class="tab-pane fade" id="cm-manage">
        <div class="mb-3"><label class="form-label"><?= t('Active Theme') ?></label><div class="form-control-plaintext border rounded px-3 py-2"><?php if ($activeTheme && $activeTheme->getThemeID()) { ?><strong><?= h($activeTheme->getThemeName()) ?></strong> — <?= h($activeTheme->getThemeHandle()) ?><?php } else { ?><?= t('No active theme available.') ?><?php } ?></div></div>
        <?php if (empty($registeredContainers)) { ?><div class="alert alert-warning"><?= t('No registered containers were found for this theme.') ?></div><?php } else { ?>
            <div class="table-responsive"><table class="table table-striped"><thead><tr><th><?= t('Name') ?></th><th><?= t('Handle') ?></th><th><?= t('Template File') ?></th><th><?= t('Action') ?></th></tr></thead><tbody>
            <?php foreach ($registeredContainers as $container) { ?>
                <tr><td><?= h($container['name'] ?? '') ?></td><td><code><?= h($container['handle'] ?? '') ?></code></td><td><?= !empty($container['has_template']) ? '<span class="badge bg-success">' . t('Exists') . '</span>' : '<span class="badge bg-warning text-dark">' . t('Missing') . '</span>' ?></td><td><div class="d-flex gap-2 flex-wrap"><?php if (!empty($container['editor_data'])) { ?><button type="button" class="btn btn-sm btn-outline-primary" data-edit-container="<?= h(json_encode($container['editor_data'])) ?>"><?= t('Edit') ?></button><?php } ?><form method="post" action="<?= $view->action('uninstall') ?>" onsubmit="return confirm('<?= h(t('Uninstall this container registration?')) ?>');"><?php $token->output('tallacmans_container_maker_uninstall'); ?><input type="hidden" name="themeID" value="<?= h($selectedThemeID) ?>"><input type="hidden" name="containerHandle" value="<?= h($container['handle'] ?? '') ?>"><input type="hidden" name="confirm" value="1"><button class="btn btn-sm btn-danger" type="submit"><?= t('Uninstall') ?></button></form></div></td></tr>
            <?php } ?>
            </tbody></table></div>
        <?php } ?>
    </div>
</div>

<style>
.cm-preview-shell{border:1px solid #ddd;background:#f8f9fa;min-height:280px;overflow:auto;padding:1rem;max-width:100%;position:relative;}
.cm-viewport-card{border:1px solid #ddd;background:#f8f9fa;padding:.75rem;height:100%;}
.cm-viewport-title{font-weight:700;margin-bottom:.5rem;}
.cm-preview-canvas{background:#fff;border:1px solid #ccc;margin:auto;padding:24px;display:grid;gap:1rem;align-items:stretch;min-height:220px;max-width:100%;overflow:hidden;position:relative;user-select:none;}
.cm-preview-canvas-small{padding:12px;min-height:160px;width:100%;overflow:hidden;}
.cm-area-tile{border:2px dashed #777;background:#eef3ff;min-height:74px;padding:.75rem;position:relative;cursor:grab;overflow:visible;touch-action:none;}
.cm-area-tile.cm-pointer-dragging{z-index:10;box-shadow:0 .5rem 1rem rgba(0,0,0,.15);cursor:grabbing;}
.cm-area-tile.active{outline:3px solid rgba(13,110,253,.35)}
.cm-area-title{font-weight:700}.cm-area-meta{font-size:12px;opacity:.75}
.cm-area-resize-handle{position:absolute;top:0;right:0;width:12px;height:100%;cursor:ew-resize;background:linear-gradient(90deg,transparent,rgba(13,110,253,.25));touch-action:none}
.cm-area-resize-hint{font-size:11px;opacity:.65;margin-top:.35rem}
.cm-row-drag-handle{cursor:grab;user-select:none}.cm-area-row input,.cm-area-row button,.cm-area-row label,.cm-area-row select{user-select:auto}.cm-area-row{border:1px solid #ddd;border-radius:.25rem;padding:.75rem;margin-bottom:.5rem;background:#fff}.cm-area-row.dragging{opacity:.5}.cm-library-card .card-body{min-height:150px}
.cm-track-panel{border:1px solid #eee;border-radius:.25rem;padding:.5rem;margin-top:.5rem;background:#fafafa}
.cm-area-row-active{border-color:#0d6efd;box-shadow:0 0 0 1px rgba(13,110,253,.15)}
.cm-track-value-hint{font-size:11px;color:#6c757d;margin-top:.25rem}
</style>

<script>
(function(){
    const BP = ['desktop','tablet','mobile'];
    const TRACK_MODES = [
        ['fr', 'fr — flexible share of free space'],
        ['length', 'Fixed length (px, rem, %, vw)'],
        ['minmax', 'minmax(min, max)'],
        ['clamp', 'clamp(min, preferred, max)'],
        ['auto', 'auto — content-based width'],
        ['fit-content', 'fit-content(max)'],
    ];
    const defaultTrack = () => ({ mode: 'fr', value: '1fr' });
    const defaultArea = (name) => ({ name, tracks: { desktop: defaultTrack(), tablet: defaultTrack(), mobile: defaultTrack() }, full: false, nested: true, category: 'General', version: '1.0.0' });
    const state = { selected: 0, history: [], future: [], areas: [defaultArea('Main')] };
    const $ = id => document.getElementById(id);
    const gridInputs = ['flexGap','flexRowGap','flexColumnGap','flexMinTrack','flexPadding','flexInner','flexJustifyItems','flexAlignItems','flexAutoFlow'];
    const canvasIds = ['cmPreviewCanvas','cmPreviewCanvasDesktop','cmPreviewCanvasTablet','cmPreviewCanvasMobile'];
    let handleTouched = false;
    const editHistoryPushed = new WeakSet();

    function ensureTrackToken(str, fallback) {
        str = String(str == null ? '' : str).trim();
        if (!str) return fallback || '1fr';
        if (/^\d+(\.\d+)?$/.test(str)) {
            if (fallback && /px$/i.test(fallback)) return str + 'px';
            if (fallback && /%$/i.test(fallback)) return str + '%';
            if (fallback && /rem$/i.test(fallback)) return str + 'rem';
            return str + 'fr';
        }
        return str;
    }
    function parseCssTrackString(value) {
        const trimmed = String(value || '').trim();
        if (!trimmed) return defaultTrack();
        if (/^auto$/i.test(trimmed)) return { mode: 'auto' };
        if (/^fit-content\(/i.test(trimmed)) {
            const max = trimmed.replace(/^fit-content\(\s*|\s*\)$/gi, '');
            return { mode: 'fit-content', max: max || '100%' };
        }
        if (/^minmax\(/i.test(trimmed)) {
            const inner = trimmed.replace(/^minmax\(\s*|\s*\)$/gi, '');
            const parts = inner.split(',').map(s => s.trim());
            return { mode: 'minmax', min: parts[0] || '0px', max: parts[1] || '1fr' };
        }
        if (/^clamp\(/i.test(trimmed)) {
            const inner = trimmed.replace(/^clamp\(\s*|\s*\)$/gi, '');
            const parts = inner.split(',').map(s => s.trim());
            return { mode: 'clamp', min: parts[0] || '0px', preferred: parts[1] || '1fr', max: parts[2] || '100%' };
        }
        if (/fr$/i.test(trimmed)) return { mode: 'fr', value: trimmed };
        if (/^(?:\d+(\.\d+)?)(px|rem|em|%|vw|vh|ch|ex)$/i.test(trimmed)) return { mode: 'length', value: trimmed };
        return { mode: 'length', value: trimmed };
    }
    function normalizeTrack(value) {
        if (value && typeof value === 'object' && value.mode) {
            const t = Object.assign({}, value);
            if (t.mode === 'fr') {
                t.value = ensureTrackToken(t.value != null ? t.value : t.fr, '1fr');
            }
            if (t.mode === 'clamp' && !t.preferred && t.value) t.preferred = t.value;
            if (t.mode === 'custom') return parseCssTrackString(t.custom || t.value || '1fr');
            return t;
        }
        if (typeof value === 'string') return parseCssTrackString(value);
        const n = parseInt(value, 10);
        if (!isNaN(n) && n > 0) return { mode: 'fr', value: n + 'fr' };
        return defaultTrack();
    }
    function normalizeArea(area) {
        const next = Object.assign({}, area);
        next.tracks = next.tracks || {};
        BP.forEach(bp => {
            if (next.tracks[bp]) next.tracks[bp] = normalizeTrack(next.tracks[bp]);
            else next.tracks[bp] = normalizeTrack(next[bp]);
        });
        return next;
    }
    function trackToCss(track) {
        const t = normalizeTrack(track);
        let css;
        switch (t.mode) {
            case 'length':
                css = ensureTrackToken(t.value, '200px');
                break;
            case 'minmax':
                css = 'minmax(' + ensureTrackToken(t.min, '0px') + ', ' + ensureTrackToken(t.max, '1fr') + ')';
                break;
            case 'clamp':
                css = 'clamp(' + ensureTrackToken(t.min, '0px') + ', ' + ensureTrackToken(t.preferred || t.value, '1fr') + ', ' + ensureTrackToken(t.max, '100%') + ')';
                break;
            case 'auto':
                css = 'auto';
                break;
            case 'fit-content':
                css = 'fit-content(' + ensureTrackToken(t.max, '100%') + ')';
                break;
            case 'fr':
            default:
                css = ensureTrackToken(t.value != null ? t.value : t.fr, '1fr');
        }
        const min = ($('flexMinTrack')?.value || '0').trim();
        if (min && min !== '0') return 'minmax(' + min + ', ' + css + ')';
        return css;
    }
    function trackLabel(track) {
        return trackToCss(track).replace(/^minmax\([^,]+,\s*([^)]+)\)$/, '$1');
    }
    function gridSettingsSnapshot() {
        return {
            rowGap: $('flexRowGap').value.trim(),
            columnGap: $('flexColumnGap').value.trim(),
            minTrack: $('flexMinTrack').value.trim() || '0',
            justifyItems: $('flexJustifyItems').value,
            alignItems: $('flexAlignItems').value,
            autoFlow: $('flexAutoFlow').value,
        };
    }
    function applyGridSettings(data) {
        const g = data && data.grid ? data.grid : (data || {});
        $('flexRowGap').value = g.rowGap || '';
        $('flexColumnGap').value = g.columnGap || '';
        $('flexMinTrack').value = g.minTrack || '0';
        $('flexJustifyItems').value = g.justifyItems || 'stretch';
        $('flexAlignItems').value = g.alignItems || 'stretch';
        $('flexAutoFlow').value = g.autoFlow || 'row';
    }
    function beginInspectorEdit(el) {
        if (el && !editHistoryPushed.has(el)) {
            pushHistory();
            editHistoryPushed.add(el);
        }
    }
    function syncGeneratedFields() {
        $('flexAreas').value = state.areas.map(a => a.name).join('\n');
        $('flexAreaGridColumns').value = state.areas.map(a => a.name + '::' + trackLabel(a.tracks.desktop)).join('\n');
        $('flexAreaFullRows').value = state.areas.filter(a => a.full).map(a => a.name).join('\n');
        $('flexNestedAreas').value = state.areas.filter(a => a.nested).map(a => a.name).join('\n');
        $('flexResponsiveColumns').value = state.areas.map(a => a.name + '::' + BP.map(bp => trackLabel(a.tracks[bp])).join('|')).join('\n');
        $('flexAreaWidths').value = state.areas.map(a => a.name + '::' + (a.full ? '100%' : trackLabel(a.tracks.desktop))).join('\n');
        $('flexGridSettings').value = JSON.stringify(gridSettingsSnapshot());
    }
    function renderPreview() {
        syncGeneratedFields();
        canvasIds.forEach(id => renderCanvas(id));
    }
    function renderAll() {
        syncGeneratedFields();
        canvasIds.forEach(id => renderCanvas(id));
        updateCanvasHelp();
        renderInspector();
        renderLibrary();
    }
    function setSelectedArea(index) {
        state.selected = index;
        document.querySelectorAll('.cm-area-tile').forEach(el => {
            el.classList.toggle('active', parseInt(el.dataset.index, 10) === index);
        });
        document.querySelectorAll('.cm-area-row').forEach(row => {
            row.classList.toggle('cm-area-row-active', parseInt(row.dataset.index, 10) === index);
        });
    }
    function updateInspectorLabels(i) {
        const row = document.querySelector('.cm-area-row[data-index="' + i + '"]');
        if (!row || !state.areas[i]) return;
        const title = row.querySelector('.cm-area-row-title');
        if (title) title.textContent = (i + 1) + '. ' + state.areas[i].name;
        BP.forEach(bp => {
            const label = row.querySelector('[data-track-preview="' + i + '-' + bp + '"]');
            if (label) label.textContent = trackLabel(state.areas[i].tracks[bp]);
        });
        canvasIds.forEach(id => {
            const canvas = $(id);
            if (!canvas) return;
            const tile = canvas.querySelector('.cm-area-tile[data-index="' + i + '"]');
            if (!tile) return;
            const bp = canvas.dataset.breakpoint || 'desktop';
            const a = state.areas[i];
            const meta = bp.charAt(0).toUpperCase() + bp.slice(1) + ': ' + trackLabel(a.tracks[bp]) + (a.full ? ' · full row' : '') + (a.nested ? ' · nested' : '');
            const titleEl = tile.querySelector('.cm-area-title');
            const metaEl = tile.querySelector('.cm-area-meta');
            if (titleEl) titleEl.textContent = a.name;
            if (metaEl) metaEl.textContent = meta;
        });
    }

    function activateTabFromHash() {
        if (!window.bootstrap || !window.location.hash) return;
        const trigger = document.querySelector('[data-bs-toggle="tab"][data-bs-target="' + window.location.hash + '"]');
        if (trigger) bootstrap.Tab.getOrCreateInstance(trigger).show();
    }
    document.querySelectorAll('[data-bs-toggle="tab"][data-bs-target]').forEach(tab => {
        tab.addEventListener('shown.bs.tab', e => {
            const target = e.target.getAttribute('data-bs-target');
            if (target && window.history.replaceState) window.history.replaceState(null, '', target);
        });
    });
    function slug(s, fallback) { return (s || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '') || (fallback || ''); }
    function updateFilePreview() {
        const handle = slug($('flexHandle').value);
        $('flexFilePreview').textContent = handle ? handle + '.php' : <?= json_encode(t('Enter a container name')) ?>;
    }
    function setEditingMode(data) {
        const editing = !!(data && data.handle);
        $('cmEditingHandle').value = editing ? data.handle : '';
        $('flexHandle').readOnly = editing;
        $('flexOverwrite').checked = editing;
        $('cmNewContainer').classList.toggle('d-none', !editing);
        $('cmEditingStatus').classList.toggle('d-none', !editing);
        $('cmSaveContainerButton').textContent = editing ? <?= json_encode(t('Save Changes')) ?> : <?= json_encode(t('Save Container PHP')) ?>;
        if (editing) { $('cmEditingStatus').textContent = <?= json_encode(t('Editing existing container:')) ?> + ' ' + data.handle + '.php'; }
        else { $('cmEditingStatus').textContent = ''; }
    }
    function loadContainerData(data) {
        if (!data) return;
        handleTouched = true;
        $('flexName').value = data.name || '';
        $('flexHandle').value = data.handle || slug(data.name);
        $('flexLayoutMode').value = 'css_grid';
        $('flexInner').value = data.inner !== undefined ? data.inner : 'container';
        applyGridSettings(data);
        state.areas = (data.areas && data.areas.length) ? data.areas.map(normalizeArea) : state.areas;
        state.selected = 0; state.history = []; state.future = [];
        setEditingMode(data); updateFilePreview(); activateTab('#cm-builder'); renderAll();
    }
    function resetBuilder() {
        handleTouched = false;
        $('flexName').value = ''; $('flexHandle').value = ''; $('flexLayoutMode').value = 'css_grid'; $('flexInner').value = 'container';
        applyGridSettings({});
        state.areas = [defaultArea('Main')];
        state.selected = 0; state.history = []; state.future = [];
        setEditingMode(null); updateFilePreview(); renderAll();
    }
    function activateTab(target) {
        if (!window.bootstrap) return;
        const trigger = document.querySelector('[data-bs-toggle="tab"][data-bs-target="' + target + '"]');
        if (trigger) bootstrap.Tab.getOrCreateInstance(trigger).show();
    }
    function pushHistory() { state.history.push(JSON.stringify(state.areas)); if (state.history.length > 50) state.history.shift(); state.future = []; }
    function updateCanvasHelp() {
        $('cmCanvasHelp').textContent = 'Drag areas to reorder them. Drag the blue edge handle to adjust fr width. Track sizes use native CSS Grid values: fr, px, rem, %, minmax(), clamp(), auto, and fit-content().';
    }
    function applyCanvasLayout(canvas) {
        const bp = canvas.dataset.breakpoint || 'desktop';
        const gap = $('flexGap').value || '1rem';
        const rowGap = $('flexRowGap').value.trim();
        const columnGap = $('flexColumnGap').value.trim();
        canvas.className = 'cm-preview-canvas' + (canvas.classList.contains('cm-preview-canvas-small') || canvas.id !== 'cmPreviewCanvas' ? ' cm-preview-canvas-small' : '');
        canvas.style.gap = gap;
        canvas.style.rowGap = rowGap || gap;
        canvas.style.columnGap = columnGap || gap;
        canvas.style.padding = canvas.id === 'cmPreviewCanvas' ? ($('flexPadding').value || '24px') : '12px';
        canvas.style.justifyItems = $('flexJustifyItems').value || 'stretch';
        canvas.style.alignItems = $('flexAlignItems').value || 'stretch';
        canvas.style.gridAutoFlow = $('flexAutoFlow').value || 'row';
        canvas.style.gridTemplateColumns = state.areas.map(a => trackToCss(a.tracks[bp])).join(' ');
    }
    function renderCanvas(id) {
        const canvas = $(id); if (!canvas) return;
        const bp = canvas.dataset.breakpoint || 'desktop';
        applyCanvasLayout(canvas);
        canvas.innerHTML = '';
        state.areas.forEach((a, i) => {
            const tile = document.createElement('div');
            tile.className = 'cm-area-tile' + (i === state.selected ? ' active' : '');
            tile.draggable = false;
            tile.dataset.index = i;
            tile.style.gridColumn = a.full ? '1 / -1' : 'auto';
            const meta = bp.charAt(0).toUpperCase() + bp.slice(1) + ': ' + trackLabel(a.tracks[bp]) + (a.full ? ' · full row' : '') + (a.nested ? ' · nested' : '');
            tile.innerHTML = '<div class="cm-area-title">' + esc(a.name) + '</div><div class="cm-area-meta">' + esc(meta) + '</div><div class="cm-area-resize-hint">drag tile to reorder · edge to resize fr</div><div class="cm-area-resize-handle" data-resize-index="' + i + '" title="Resize track"></div>';
            canvas.appendChild(tile);
        });
    }
    function esc(s) { return (s + '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m])); }
    function trackValueInput(label, attr, i, bp, value, placeholder) {
        return '<label class="form-label mb-1">' + label + '</label>' +
            '<input type="text" class="form-control form-control-sm" ' + attr + ' data-track-index="' + i + '" data-track-bp="' + bp + '" value="' + esc(value) + '" placeholder="' + esc(placeholder) + '">';
    }
    function trackPanelHtml(a, i, bp) {
        const t = normalizeTrack(a.tracks[bp]);
        const mode = t.mode || 'fr';
        const modeOptions = TRACK_MODES.map(([id, label]) => '<option value="' + id + '"' + (mode === id ? ' selected' : '') + '>' + esc(label) + '</option>').join('');
        const hint = '<div class="cm-track-value-hint">Use CSS track sizes: 1fr, 20fr, 200px, 50%, 2rem, auto</div>';
        const single = trackValueInput('Track size', 'data-track-value', i, bp, t.value || (t.fr ? t.fr + 'fr' : '1fr'), '1fr, 20fr, 200px, 50%') + hint;
        const minmax = trackValueInput('Minimum', 'data-track-min', i, bp, t.min || '200px', '200px, 0px, 1fr') +
            trackValueInput('Maximum', 'data-track-max', i, bp, t.max || '1fr', '1fr, 20fr, 100%, 480px') + hint;
        const clamp = trackValueInput('Minimum', 'data-track-min', i, bp, t.min || '200px', '200px, 0px') +
            trackValueInput('Preferred', 'data-track-preferred', i, bp, t.preferred || t.value || '1fr', '1fr, 20fr, 50%') +
            trackValueInput('Maximum', 'data-track-max', i, bp, t.max || '100%', '100%, 20fr, 480px') + hint;
        const fit = trackValueInput('Maximum size', 'data-track-fit-max', i, bp, t.max || '100%', '300px, 100%, 20rem') + hint;
        return '<div class="cm-track-panel" data-track-panel="' + i + '-' + bp + '">' +
            '<div class="d-flex justify-content-between align-items-center mb-1"><label class="form-label mb-0">' + bp.charAt(0).toUpperCase() + bp.slice(1) + '</label><small class="text-muted" data-track-preview="' + i + '-' + bp + '">' + esc(trackLabel(t)) + '</small></div>' +
            '<select class="form-select form-select-sm mb-2" data-track-mode="' + i + '" data-track-bp="' + bp + '">' + modeOptions + '</select>' +
            '<div data-track-fields="' + i + '-' + bp + '-fr"' + (mode === 'fr' ? '' : ' class="d-none"') + '>' + single + '</div>' +
            '<div data-track-fields="' + i + '-' + bp + '-length"' + (mode === 'length' ? '' : ' class="d-none"') + '>' + single + '</div>' +
            '<div data-track-fields="' + i + '-' + bp + '-minmax"' + (mode === 'minmax' ? '' : ' class="d-none"') + '>' + minmax + '</div>' +
            '<div data-track-fields="' + i + '-' + bp + '-clamp"' + (mode === 'clamp' ? '' : ' class="d-none"') + '>' + clamp + '</div>' +
            '<div data-track-fields="' + i + '-' + bp + '-auto"' + (mode === 'auto' ? '' : ' class="d-none"') + '><div class="cm-track-value-hint">Uses content width. Good for sidebars or shrink-to-fit columns.</div></div>' +
            '<div data-track-fields="' + i + '-' + bp + '-fit-content"' + (mode === 'fit-content' ? '' : ' class="d-none"') + '>' + fit + '</div>' +
            '</div>';
    }
    function renderInspector() {
        let html = '';
        state.areas.forEach((a, i) => {
            html += '<div class="cm-area-row' + (i === state.selected ? ' cm-area-row-active' : '') + '" data-index="' + i + '">' +
                '<div class="d-flex justify-content-between align-items-center"><span class="cm-row-drag-handle btn btn-sm btn-outline-secondary" draggable="true" data-drag-index="' + i + '">↕ drag</span>' +
                '<strong class="cm-area-row-title">' + (i + 1) + '. ' + esc(a.name) + '</strong>' +
                '<button type="button" class="btn btn-sm btn-outline-danger" data-del="' + i + '">Delete</button></div>' +
                '<label class="form-label mt-2">Name</label><input class="form-control form-control-sm" data-name="' + i + '" value="' + esc(a.name) + '">' +
                '<div class="row g-2 mt-2">' + BP.map(bp => '<div class="col-12 col-xl-4">' + trackPanelHtml(a, i, bp) + '</div>').join('') + '</div>' +
                '<div class="form-check form-check-inline mt-2"><input class="form-check-input" type="checkbox" id="cmFull' + i + '" data-full="' + i + '" ' + (a.full ? 'checked' : '') + '><label class="form-check-label" for="cmFull' + i + '">Full row</label></div>' +
                '<div class="form-check form-check-inline mt-2"><input class="form-check-input" type="checkbox" id="cmNested' + i + '" data-nested="' + i + '" ' + (a.nested ? 'checked' : '') + '><label class="form-check-label" for="cmNested' + i + '">Nested-friendly</label></div></div>';
        });
        $('cmAreaInspector').innerHTML = html;
    }
    function renderLibrary() {
        const q = ($('cmLibrarySearch')?.value || '').toLowerCase();
        const list = JSON.parse(localStorage.getItem('cm_container_presets') || '[]');
        let html = '';
        list.filter(p => JSON.stringify(p).toLowerCase().includes(q)).forEach((p, i) => {
            html += '<div class="col-md-6 col-xl-4"><div class="card cm-library-card"><div class="card-body"><h5>' + esc(p.name || 'Preset') + '</h5><p class="text-muted mb-1"><code>' + esc(p.handle || '') + '</code></p><p class="mb-2">' + (p.areas ? p.areas.length : 0) + ' areas · CSS Grid</p><button class="btn btn-sm btn-outline-primary" data-load-lib="' + i + '">Load</button> <button class="btn btn-sm btn-outline-secondary" data-dup-lib="' + i + '">Duplicate</button> <button class="btn btn-sm btn-outline-danger" data-del-lib="' + i + '">Delete</button></div></div></div>';
        });
        $('cmLibraryList').innerHTML = html || '<div class="col"><div class="alert alert-light">No saved presets yet.</div></div>';
        refreshPresetSelect(list);
    }
    function refreshPresetSelect(list) {
        const sel = $('cmPresetSelect'), val = sel.value;
        sel.innerHTML = '<option value="">Load saved preset…</option>' + list.map((p, i) => '<option value="' + i + '">' + esc(p.name || 'Preset') + '</option>').join('');
        sel.value = val;
    }
    function snapshot() {
        return { name: $('flexName').value, handle: $('flexHandle').value, mode: 'css_grid', inner: $('flexInner').value, grid: gridSettingsSnapshot(), areas: state.areas };
    }
    function loadSnap(snap) {
        if (!snap) return;
        $('flexName').value = snap.name || 'Imported Container';
        $('flexHandle').value = snap.handle || slug($('flexName').value);
        $('flexLayoutMode').value = 'css_grid';
        if (snap.inner !== undefined) $('flexInner').value = snap.inner;
        applyGridSettings(snap);
        state.areas = (snap.areas && snap.areas.length) ? snap.areas.map(normalizeArea) : state.areas;
        setEditingMode(null); updateFilePreview(); renderAll();
    }
    function readTrackField(i, bp, attr) {
        const modeEl = document.querySelector('[data-track-mode="' + i + '"][data-track-bp="' + bp + '"]');
        const mode = modeEl ? modeEl.value : 'fr';
        const panel = document.querySelector('[data-track-fields="' + i + '-' + bp + '-' + mode + '"]');
        if (!panel) return '';
        const el = panel.querySelector('[' + attr + '][data-track-index="' + i + '"][data-track-bp="' + bp + '"]');
        return el ? el.value : '';
    }
    function updateTrackFromInputs(i, bp) {
        const modeEl = document.querySelector('[data-track-mode="' + i + '"][data-track-bp="' + bp + '"]');
        if (!modeEl) return;
        const mode = modeEl.value;
        if (mode === 'fr' || mode === 'length') {
            state.areas[i].tracks[bp] = { mode: mode, value: ensureTrackToken(readTrackField(i, bp, 'data-track-value'), mode === 'length' ? '200px' : '1fr') };
        } else if (mode === 'minmax') {
            state.areas[i].tracks[bp] = {
                mode: 'minmax',
                min: ensureTrackToken(readTrackField(i, bp, 'data-track-min'), '200px'),
                max: ensureTrackToken(readTrackField(i, bp, 'data-track-max'), '1fr'),
            };
        } else if (mode === 'clamp') {
            state.areas[i].tracks[bp] = {
                mode: 'clamp',
                min: ensureTrackToken(readTrackField(i, bp, 'data-track-min'), '200px'),
                preferred: ensureTrackToken(readTrackField(i, bp, 'data-track-preferred'), '1fr'),
                max: ensureTrackToken(readTrackField(i, bp, 'data-track-max'), '100%'),
            };
        } else if (mode === 'fit-content') {
            state.areas[i].tracks[bp] = { mode: 'fit-content', max: ensureTrackToken(readTrackField(i, bp, 'data-track-fit-max'), '100%') };
        } else if (mode === 'auto') {
            state.areas[i].tracks[bp] = { mode: 'auto' };
        }
    }
    function toggleTrackFields(i, bp, mode) {
        ['fr', 'length', 'minmax', 'clamp', 'auto', 'fit-content'].forEach(kind => {
            const el = document.querySelector('[data-track-fields="' + i + '-' + bp + '-' + kind + '"]');
            if (el) el.classList.toggle('d-none', kind !== mode);
        });
    }
    function handleInspectorFieldInput(t) {
        if (t.dataset.name !== undefined) {
            const i = parseInt(t.dataset.name, 10);
            state.areas[i].name = t.value;
            setSelectedArea(i);
            renderPreview();
            updateInspectorLabels(i);
            return true;
        }
        if (t.dataset.trackIndex !== undefined && t.dataset.trackBp) {
            const i = parseInt(t.dataset.trackIndex, 10);
            const bp = t.dataset.trackBp;
            updateTrackFromInputs(i, bp);
            setSelectedArea(i);
            renderPreview();
            updateInspectorLabels(i);
            return true;
        }
        return false;
    }

    document.addEventListener('focusin', e => {
        if (e.target.closest('#cmAreaInspector input, #cmAreaInspector select')) beginInspectorEdit(e.target);
    });
    document.addEventListener('input', e => {
        const t = e.target;
        if (t.id === 'flexName' && !handleTouched) { $('flexHandle').value = slug(t.value); updateFilePreview(); }
        if (t.id === 'flexHandle') { handleTouched = true; $('flexHandle').value = slug(t.value); updateFilePreview(); }
        if (handleInspectorFieldInput(t)) return;
        if (gridInputs.includes(t.id) || t.id === 'cmLibrarySearch') renderAll();
    });
    document.addEventListener('change', e => {
        const t = e.target;
        if (t.dataset.trackMode !== undefined) {
            beginInspectorEdit(t);
            const i = parseInt(t.dataset.trackMode, 10);
            const bp = t.dataset.trackBp;
            toggleTrackFields(i, bp, t.value);
            updateTrackFromInputs(i, bp);
            setSelectedArea(i);
            renderPreview();
            updateInspectorLabels(i);
            return;
        }
        ['full', 'nested'].forEach(k => {
            const i = t.dataset[k];
            if (i !== undefined) { pushHistory(); state.areas[i][k] = t.checked; renderAll(); }
        });
    });
    document.addEventListener('click', e => {
        const t = e.target;
        if (t.id === 'cmAddArea') { pushHistory(); state.areas.push(defaultArea('Area ' + (state.areas.length + 1))); state.selected = state.areas.length - 1; renderAll(); }
        if (t.dataset.del !== undefined) {
            const i = parseInt(t.dataset.del, 10);
            if (confirm('Delete this area from the designer? You can restore the last deleted area.')) {
                pushHistory(); localStorage.setItem('cm_last_deleted_area', JSON.stringify(state.areas[i])); state.areas.splice(i, 1); state.selected = 0; renderAll();
            }
        }
        if (t.id === 'cmRestoreDeleted') {
            const saved = localStorage.getItem('cm_last_deleted_area');
            if (saved) { pushHistory(); state.areas.push(normalizeArea(JSON.parse(saved))); state.selected = state.areas.length - 1; localStorage.removeItem('cm_last_deleted_area'); renderAll(); }
            else alert('No recently deleted area to restore.');
        }
        if (t.id === 'cmUndo' && state.history.length) { state.future.push(JSON.stringify(state.areas)); state.areas = JSON.parse(state.history.pop()).map(normalizeArea); renderAll(); }
        if (t.id === 'cmRedo' && state.future.length) { state.history.push(JSON.stringify(state.areas)); state.areas = JSON.parse(state.future.pop()).map(normalizeArea); renderAll(); }
        if (t.id === 'cmSavePreset') { const list = JSON.parse(localStorage.getItem('cm_container_presets') || '[]'); const s = snapshot(); s.name = $('cmPresetName').value || s.name; list.push(s); localStorage.setItem('cm_container_presets', JSON.stringify(list)); renderLibrary(); }
        if (t.id === 'cmExportPreset') { const blob = new Blob([JSON.stringify(snapshot(), null, 2)], { type: 'application/json' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = slug($('flexName').value, 'container') + '_container_preset.json'; a.click(); }
        if (t.id === 'cmLoadPreset') { const list = JSON.parse(localStorage.getItem('cm_container_presets') || '[]'); loadSnap(list[parseInt($('cmPresetSelect').value, 10)]); }
        if (t.id === 'cmNewContainer') resetBuilder();
        if (t.dataset.editContainer !== undefined) { try { loadContainerData(JSON.parse(t.dataset.editContainer)); } catch (err) { alert('Could not load this container into the designer.'); } }
        ['loadLib', 'dupLib', 'delLib'].forEach(k => {
            const attr = 'data-' + k.replace(/[A-Z]/g, m => '-' + m.toLowerCase());
            if (t.hasAttribute(attr)) {
                const list = JSON.parse(localStorage.getItem('cm_container_presets') || '[]'), i = parseInt(t.getAttribute(attr), 10);
                if (k === 'loadLib') loadSnap(list[i]);
                if (k === 'dupLib') { const cp = JSON.parse(JSON.stringify(list[i])); cp.name = (cp.name || 'Preset') + ' Copy'; list.push(cp); localStorage.setItem('cm_container_presets', JSON.stringify(list)); renderLibrary(); }
                if (k === 'delLib') { list.splice(i, 1); localStorage.setItem('cm_container_presets', JSON.stringify(list)); renderLibrary(); }
            }
        });
        const tile = t.closest('.cm-area-tile[data-index]');
        if (tile && !t.closest('.cm-area-resize-handle')) {
            setSelectedArea(parseInt(tile.dataset.index, 10));
        }
    });

    let nativeDragFrom = null;
    document.addEventListener('dragstart', e => {
        const handle = e.target.closest('.cm-row-drag-handle[data-drag-index]');
        if (handle) { nativeDragFrom = parseInt(handle.dataset.dragIndex, 10); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', handle.dataset.dragIndex); }
        else nativeDragFrom = null;
    });
    document.addEventListener('dragover', e => { if (nativeDragFrom !== null && e.target.closest('.cm-area-row[data-index]')) e.preventDefault(); });
    document.addEventListener('drop', e => {
        const row = e.target.closest('.cm-area-row[data-index]');
        if (nativeDragFrom !== null && row) {
            e.preventDefault();
            const from = nativeDragFrom, to = parseInt(row.dataset.index, 10);
            nativeDragFrom = null;
            if (from !== to) { pushHistory(); const item = state.areas.splice(from, 1)[0]; state.areas.splice(to, 0, item); renderAll(); }
        }
    });
    document.addEventListener('dragend', () => { nativeDragFrom = null; });

    let pointerDrag = null;
    let resizeDrag = null;
    function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
    function canvasFromTarget(el) { return el.closest('.cm-preview-canvas'); }
    function beginCanvasDrag(e) {
        if (e.target.closest('.cm-area-resize-handle')) return;
        if (e.target.closest('input,button,select,textarea,label,a')) return;
        const tile = e.target.closest('.cm-area-tile[data-index]');
        const canvas = canvasFromTarget(tile);
        if (!tile || !canvas) return;
        e.preventDefault();
        const canvasRect = canvas.getBoundingClientRect(), tileRect = tile.getBoundingClientRect();
        pointerDrag = { tile, canvas, index: parseInt(tile.dataset.index, 10), startX: e.clientX, startY: e.clientY, dx: 0, dy: 0, canvasRect, tileRect };
        tile.classList.add('cm-pointer-dragging');
        tile.setPointerCapture?.(e.pointerId);
    }
    function beginResizeDrag(e) {
        const handle = e.target.closest('.cm-area-resize-handle[data-resize-index]');
        const canvas = canvasFromTarget(handle);
        if (!handle || !canvas) return;
        e.preventDefault(); e.stopPropagation();
        const index = parseInt(handle.dataset.resizeIndex, 10);
        const bp = canvas.dataset.breakpoint || 'desktop';
        const track = normalizeTrack(state.areas[index].tracks[bp]);
        const frMatch = String(track.value || track.fr || '1fr').match(/^(\d+(\.\d+)?)/);
        resizeDrag = { index, bp, canvas, startX: e.clientX, startFr: frMatch ? parseFloat(frMatch[1]) : 1 };
        pushHistory();
        handle.setPointerCapture?.(e.pointerId);
    }
    function moveCanvasDrag(e) {
        if (resizeDrag) {
            e.preventDefault();
            const delta = (e.clientX - resizeDrag.startX) / 40;
            const nextFr = clamp(resizeDrag.startFr + delta, 0.25, 48);
            state.areas[resizeDrag.index].tracks[resizeDrag.bp] = { mode: 'fr', value: (Math.round(nextFr * 4) / 4) + 'fr' };
            renderPreview();
            updateInspectorLabels(resizeDrag.index);
            return;
        }
        if (!pointerDrag) return;
        e.preventDefault();
        const maxX = Math.max(0, pointerDrag.canvasRect.width - pointerDrag.tileRect.width);
        const maxY = Math.max(0, pointerDrag.canvasRect.height - pointerDrag.tileRect.height);
        const originalX = pointerDrag.tileRect.left - pointerDrag.canvasRect.left;
        const originalY = pointerDrag.tileRect.top - pointerDrag.canvasRect.top;
        const nextX = clamp(originalX + (e.clientX - pointerDrag.startX), 0, maxX);
        const nextY = clamp(originalY + (e.clientY - pointerDrag.startY), 0, maxY);
        pointerDrag.dx = nextX - originalX; pointerDrag.dy = nextY - originalY;
        pointerDrag.tile.style.transform = 'translate(' + pointerDrag.dx + 'px,' + pointerDrag.dy + 'px)';
    }
    function endCanvasDrag(e) {
        if (resizeDrag) {
            updateInspectorLabels(resizeDrag.index);
            resizeDrag = null;
            return;
        }
        if (!pointerDrag) return;
        const drag = pointerDrag; pointerDrag = null;
        drag.tile.classList.remove('cm-pointer-dragging');
        drag.tile.style.transform = '';
        const canvas = drag.canvas;
        const tiles = [...canvas.querySelectorAll('.cm-area-tile[data-index]')];
        const centerX = drag.tileRect.left + drag.dx + drag.tileRect.width / 2;
        const centerY = drag.tileRect.top + drag.dy + drag.tileRect.height / 2;
        let to = drag.index, best = Infinity;
        tiles.forEach(el => {
            const idx = parseInt(el.dataset.index, 10); if (idx === drag.index) return;
            const r = el.getBoundingClientRect();
            const d = Math.hypot(centerX - (r.left + r.width / 2), centerY - (r.top + r.height / 2));
            if (d < best) { best = d; to = idx; }
        });
        if (to !== drag.index) { pushHistory(); const item = state.areas.splice(drag.index, 1)[0]; state.areas.splice(to, 0, item); state.selected = to; }
        else setSelectedArea(drag.index);
        renderAll();
    }
    canvasIds.forEach(id => {
        const c = $(id);
        if (!c) return;
        c.addEventListener('pointerdown', e => {
            if (e.target.closest('.cm-area-resize-handle')) beginResizeDrag(e);
            else beginCanvasDrag(e);
        });
    });
    document.addEventListener('pointermove', moveCanvasDrag);
    document.addEventListener('pointerup', endCanvasDrag);
    document.addEventListener('pointercancel', endCanvasDrag);

    $('cmImportPreset').addEventListener('change', e => {
        const f = e.target.files[0]; if (!f) return;
        const r = new FileReader();
        r.onload = () => { try { loadSnap(JSON.parse(r.result)); } catch (err) { alert('Invalid JSON preset.'); } };
        r.readAsText(f);
    });
    updateFilePreview(); activateTabFromHash(); renderAll();
})();
</script>
