# Container Maker for Concrete CMS

Version: 0.9.1

Container Maker adds a dashboard tool at **Dashboard → Pages & Themes → Container Maker** for generating Concrete CMS container PHP files for the site's active theme.

## New in 0.9.1

- Generated container PHP is now plain, hand-written-looking markup: no inline styles or CSS custom properties on any element. 12-column mode emits real Bootstrap classes (e.g. `col-md-6`), CSS Grid/Flexbox modes emit a small class + nth-child `<style>` block, and each area is a literal `ContainerArea` block (not a loop) — matching how containers are normally hand-authored. The live Code Preview panel mirrors this exactly.
- Fixed a bug where clicking (not dragging) an area tile in the Visual Canvas would reorder it with its neighbor — every click on a 2-area canvas swapped them. Plain clicks now only select the area; reordering only triggers once you actually drag past a few pixels.
- Clicking an area tile now scrolls the Area Settings panel to that area's row and briefly highlights it.
- Added a per-area **Padding** field (independent of the container's own padding), working in every layout mode.
- Hardened active-theme detection with a raw-SQL fallback and an on-page diagnostic line, for cases where Concrete's cached "current site" object is stale.

## New in 0.9.0

- The tool now always operates on the site's currently active theme — no theme picker, since containers only ever apply to that theme.
- Container Name and Handle start blank instead of prefilled with placeholder text.
- Removed the Preview Breakpoint dropdown — the desktop/tablet/mobile canvases already show every breakpoint at once.
- Layout Mode picks a sensible default based on the theme's detected grid system (Bootstrap/Foundation → 12-column grid, Tailwind → CSS Grid).
- The Settings panel now hides flexbox-only controls (direction, wrap, align, justify) unless Flexbox mode is selected.
- Code Preview lines wrap instead of requiring horizontal scrolling.
- Removed the Preset Installer tab, the Container Library tab, and the Export/Import JSON buttons — this release is focused on directly designing and managing your own containers.
- **Manage Installed Containers** lists every registered container for the active theme (fixed a bug where the “Exists/Missing” badge always showed Missing) and adds a **Modify** action that reloads a container into the Visual Designer — with its handle locked — so it re-saves over the original file under its original name.
- Fixed the Area Settings **Name** field kicking focus out of the box after every keystroke.
- Fixed Area Settings sliders (Desktop/Tablet/Mobile spans) feeling janky/dimmed while dragging.

## Install

1. Unzip this package.
2. Put the `container_maker` folder into your Concrete CMS `packages/` directory.
3. Go to **Dashboard → Extend Concrete**.
4. Install **Container Maker**.
5. Open **Dashboard → Pages & Themes → Container Maker**.

## Upgrade

Replace the older `packages/container_maker` folder with this one, then visit **Dashboard → Extend Concrete** if Concrete offers an update.

## Important notes

- Generated container PHP files are written into the active theme's `elements/containers/` directory.
- Existing files are not overwritten unless **Overwrite existing PHP file** is checked (this is checked automatically when you use **Modify** from Manage Installed Containers).
- Auto-registration is defensive because Concrete CMS container internals vary by version. If registration fails, the PHP file is still created and you can register it manually.
- Uninstalling a container removes its registration only. It does not delete the PHP template file.
- Containers created by the Visual Designer embed their design settings in a hidden PHP comment in the generated file, which is how **Modify** can reload them for editing later. Hand-edited or externally-created container files won't have this and can't be reloaded for editing (you'll see a message if you try).

## Suggested workflow

1. Name the container.
2. Choose layout mode: 12-column, CSS Grid, Flexbox, or Plain.
3. Add areas on the canvas.
4. Set each area's desktop/tablet/mobile span.
5. Preview the wrap behavior by dragging the preview width.
6. Check the code preview.
7. Save the container PHP file.
8. To change it later, use **Modify** from Manage Installed Containers.
