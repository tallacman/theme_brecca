<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>

<div class="alert alert-info">
    <?= t('Container Maker v0.9.1 generates clean markup with no inline styles, fixes a bug where clicking an area swapped it with its neighbor, and adds per-area padding.') ?>
</div>

<div class="mb-3">
    <?php if (is_object($theme) && $theme->getThemeID()) { ?>
        <span class="badge bg-secondary"><?= t('Active theme:') ?> <?= h($theme->getThemeName()) ?> — <?= h($theme->getThemeHandle()) ?></span>
        <span class="badge bg-light text-dark border"><?= t('Detected grid system:') ?> <strong id="cmDetectedFramework"><?= h($themeFramework ?? 'custom') ?></strong></span>
    <?php } else { ?>
        <div class="alert alert-warning mb-0">
            <?= t('No active theme was found for this site. Activate a theme before creating containers.') ?>
            <?php if (!empty($themeDebug)) { ?><div class="small text-muted mt-1"><?= h($themeDebug) ?></div><?php } ?>
        </div>
    <?php } ?>
</div>

<ul class="nav nav-tabs mb-3" id="cmContainerMakerTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#cm-builder" type="button"><?= t('Visual Designer') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-manage" type="button"><?= t('Manage Installed Containers') ?></button></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade show active" id="cm-builder">
        <form method="post" action="<?= $view->action('build_flex') ?>" id="cmBuilderForm">
            <?php $token->output('container_maker_build_flex'); ?>
            <input type="hidden" name="areas" id="flexAreas" value="Main">
            <input type="hidden" name="area_widths" id="flexAreaWidths" value="">
            <input type="hidden" name="area_grid_columns" id="flexAreaGridColumns" value="">
            <input type="hidden" name="area_full_rows" id="flexAreaFullRows" value="">
            <input type="hidden" name="responsive_columns" id="flexResponsiveColumns" value="">
            <input type="hidden" name="nested_areas" id="flexNestedAreas" value="">
            <input type="hidden" name="area_padding" id="flexAreaPadding" value="">

            <div class="row">
                <div class="col-xl-4">
                    <fieldset>
                        <legend><?= t('Container') ?></legend>
                        <div class="mb-3">
                            <label class="form-label" for="flexName"><?= t('Container Name') ?></label>
                            <input type="text" name="name" id="flexName" class="form-control" value="" placeholder="<?= h(t('e.g. Two Column Section')) ?>" required <?= $editingContainer ? '' : 'autofocus' ?>>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="flexHandle"><?= t('Handle / PHP filename') ?></label>
                            <input type="text" name="handle" id="flexHandle" class="form-control" value="" placeholder="<?= h(t('auto-generated from name')) ?>" <?= $editingContainer ? 'readonly' : '' ?>>
                            <div class="form-text"><?= t('File:') ?> <strong><span id="flexFilePreview">—</span></strong><?php if ($editingContainer) { ?> · <span class="text-muted"><?= t('Editing an existing container — handle is locked so it re-saves to the same file.') ?></span><?php } ?></div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="flexLayoutMode"><?= t('Layout Mode') ?></label>
                            <select name="layout_mode" id="flexLayoutMode" class="form-select">
                                <option value="grid12" <?= ($defaultLayoutMode === 'grid12') ? 'selected' : '' ?>><?= t('12-column grid') ?></option>
                                <option value="css_grid" <?= ($defaultLayoutMode === 'css_grid') ? 'selected' : '' ?>><?= t('Native CSS Grid') ?></option>
                                <option value="flex"><?= t('Flexbox') ?></option>
                                <option value="plain"><?= t('Plain stacked') ?></option>
                            </select>
                            <div class="form-text"><?= t('Based on the detected grid system, flexbox-only settings below are hidden unless Flexbox is selected.') ?></div>
                        </div>
                    </fieldset>

                    <fieldset class="mt-3">
                        <legend><?= t('Settings') ?></legend>
                        <div class="row">
                            <div class="col-md-6 mb-3"><label class="form-label">Gap</label><input name="gap" id="flexGap" class="form-control" value="1rem"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Padding</label><input name="padding" id="flexPadding" class="form-control" value="2rem 0"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Inner wrapper</label><select name="inner" id="flexInner" class="form-select"><option value="container">container</option><option value="container-fluid">container-fluid</option><option value="">none</option></select></div>
                        </div>
                        <div id="cmFlexOnlySettings" class="row">
                            <div class="col-md-6 mb-3"><label class="form-label">Mobile direction</label><select name="mobile" id="flexMobile" class="form-select"><option value="column">column</option><option value="row">row</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Direction</label><select name="direction" id="flexDirection" class="form-select"><option value="row">row</option><option value="column">column</option><option value="row-reverse">row-reverse</option><option value="column-reverse">column-reverse</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Wrap</label><select name="wrap" id="flexWrap" class="form-select"><option value="wrap">wrap</option><option value="nowrap">nowrap</option><option value="wrap-reverse">wrap-reverse</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Align</label><select name="align" id="flexAlign" class="form-select"><option value="stretch">stretch</option><option value="flex-start">start</option><option value="center">center</option><option value="flex-end">end</option><option value="baseline">baseline</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Justify</label><select name="justify" id="flexJustify" class="form-select"><option value="flex-start">start</option><option value="center">center</option><option value="flex-end">end</option><option value="space-between">space-between</option><option value="space-around">space-around</option><option value="space-evenly">space-evenly</option></select></div>
                            <div class="col-md-6 mb-3 d-flex align-items-end"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="use_flex" id="flexUseFlex" value="1" checked><label class="form-check-label" for="flexUseFlex"><?= t('Use flexbox') ?></label></div></div>
                            <input type="hidden" name="basis" id="flexBasis" value="100%"><input type="hidden" name="grow" id="flexGrow" value="0"><input type="hidden" name="shrink" id="flexShrink" value="0">
                        </div>
                    </fieldset>

                    <div class="mt-3 d-flex gap-2 flex-wrap">
                        <button type="button" id="cmAddArea" class="btn btn-outline-primary"><?= t('Add Area') ?></button>
                        <button type="button" id="cmUndo" class="btn btn-outline-secondary"><?= t('Undo') ?></button>
                        <button type="button" id="cmRedo" class="btn btn-outline-secondary"><?= t('Redo') ?></button>
                        <button type="button" id="cmRestoreDeleted" class="btn btn-outline-warning"><?= t('Restore Deleted') ?></button>
                    </div>
                    <hr>
                    <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="register" id="flexRegister" value="1" checked><label class="form-check-label" for="flexRegister"><?= t('Auto-register container') ?></label></div>
                    <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="overwrite" id="flexOverwrite" value="1" <?= $editingContainer ? 'checked' : '' ?>><label class="form-check-label" for="flexOverwrite"><?= t('Overwrite existing PHP file') ?></label></div>
                    <button type="submit" class="btn btn-primary"><?= t('Save Container PHP') ?></button>
                </div>

                <div class="col-xl-8">
                    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                        <h3 class="mb-0"><?= t('Visual Canvas') ?></h3>
                        <div class="input-group" style="max-width: 320px;"><span class="input-group-text"><?= t('Preview width') ?></span><input type="range" id="cmPreviewWidth" min="320" max="1200" value="900" class="form-range form-control"><span class="input-group-text" id="cmPreviewWidthLabel">900px</span></div>
                    </div>
                    <p class="text-muted"><?= t('Drag areas to reorder them. Resize using the desktop/tablet/mobile span controls. In 12-column and CSS Grid mode, overflow wraps automatically.') ?></p>
                    <div id="cmPreviewShell" class="cm-preview-shell"><div id="cmPreviewCanvas" class="cm-preview-canvas" data-breakpoint="desktop"></div></div>
                    <div class="row g-3 mt-2" id="cmViewportPreviews">
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Desktop</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasDesktop" data-breakpoint="desktop"></div></div></div>
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Tablet</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasTablet" data-breakpoint="tablet"></div></div></div>
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Mobile</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasMobile" data-breakpoint="mobile"></div></div></div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-lg-6">
                            <h4><?= t('Area Settings') ?></h4>
                            <div id="cmAreaInspector" class="cm-area-inspector"></div>
                        </div>
                        <div class="col-lg-6">
                            <h4><?= t('Code Preview') ?></h4>
                            <pre id="cmCodePreview" class="cm-code-preview"></pre>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="tab-pane fade" id="cm-manage">
        <?php if (!is_object($theme) || !$theme->getThemeID()) { ?>
            <div class="alert alert-warning"><?= t('No active theme was found for this site.') ?></div>
        <?php } else { ?>
            <p class="text-muted"><?= t('Showing containers registered for the active theme:') ?> <strong><?= h($theme->getThemeName()) ?></strong></p>
            <?php if (empty($registeredContainers)) { ?><div class="alert alert-warning"><?= t('No registered containers were found.') ?></div><?php } else { ?>
                <div class="table-responsive"><table class="table table-striped"><thead><tr><th><?= t('Name') ?></th><th><?= t('Handle') ?></th><th><?= t('Template File') ?></th><th><?= t('Action') ?></th></tr></thead><tbody>
                <?php foreach ($registeredContainers as $container) { ?>
                    <tr>
                        <td><?= h($container['name'] ?? '') ?></td>
                        <td><code><?= h($container['handle'] ?? '') ?></code></td>
                        <td><?= !empty($container['template_exists']) ? '<span class="badge bg-success">' . t('Exists') . '</span>' : '<span class="badge bg-warning text-dark">' . t('Missing') . '</span>' ?></td>
                        <td class="d-flex gap-2">
                            <?php if (!empty($container['template_exists'])) { ?>
                                <a class="btn btn-sm btn-primary" href="<?= h($view->url('/dashboard/pages/container_maker')) ?>?edit=<?= h(urlencode($container['handle'] ?? '')) ?>"><?= t('Modify') ?></a>
                            <?php } ?>
                            <form method="post" action="<?= $view->action('uninstall') ?>" onsubmit="return confirm('<?= h(t('Uninstall this container registration?')) ?>');">
                                <?php $token->output('container_maker_uninstall'); ?>
                                <input type="hidden" name="containerHandle" value="<?= h($container['handle'] ?? '') ?>">
                                <input type="hidden" name="confirm" value="1">
                                <button class="btn btn-sm btn-danger" type="submit"><?= t('Uninstall') ?></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
                </tbody></table></div>
            <?php } ?>
        <?php } ?>
    </div>
</div>

<style>
.cm-preview-shell{border:1px solid #ddd;background:#f8f9fa;min-height:280px;resize:horizontal;overflow:auto;padding:1rem;max-width:100%;position:relative;}
.cm-viewport-card{border:1px solid #ddd;background:#f8f9fa;padding:.75rem;height:100%;}
.cm-viewport-title{font-weight:700;margin-bottom:.5rem;}
.cm-preview-canvas{background:#fff;border:1px solid #ccc;margin:auto;padding:24px;display:flex;flex-wrap:wrap;gap:1rem;align-items:stretch;min-height:220px;max-width:100%;overflow:hidden;position:relative;user-select:none;}
.cm-preview-canvas-small{padding:12px;min-height:160px;width:100%;resize:none;overflow:hidden;}
.cm-preview-canvas.cm-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));}
.cm-preview-canvas.cm-plain{display:block;}
.cm-area-tile{border:2px dashed #777;background:#eef3ff;min-height:74px;padding:.75rem;position:relative;cursor:grab;overflow:hidden;touch-action:none;}
.cm-area-tile-static{cursor:pointer;touch-action:auto;}
.cm-area-tile.cm-pointer-dragging{z-index:10;box-shadow:0 .5rem 1rem rgba(0,0,0,.15);cursor:grabbing;}
.cm-area-tile.active{outline:3px solid rgba(13,110,253,.35)}
.cm-area-resize-handle{position:absolute;top:0;right:0;width:14px;height:100%;cursor:col-resize;touch-action:none;z-index:6;}
.cm-area-resize-handle::after{content:'';position:absolute;top:50%;right:4px;width:4px;height:28px;transform:translateY(-50%);border-left:2px dotted rgba(0,0,0,.35);border-right:2px dotted rgba(0,0,0,.35);}
.cm-area-resize-handle:hover::after,.cm-area-tile.cm-pointer-dragging .cm-area-resize-handle::after{border-color:rgba(13,110,253,.8);}
.cm-area-title{font-weight:700}.cm-area-meta{font-size:12px;opacity:.75}.cm-area-resize{position:absolute;right:.35rem;bottom:.25rem;font-size:11px;opacity:.65}.cm-row-drag-handle{cursor:grab;user-select:none}.cm-area-row input,.cm-area-row button,.cm-area-row label{user-select:auto}
.cm-code-preview{background:#111;color:#eee;min-height:270px;max-height:420px;overflow:auto;padding:1rem;border-radius:.25rem;font-size:12px;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;}
.cm-area-row{border:1px solid #ddd;border-radius:.25rem;padding:.75rem;margin-bottom:.5rem;background:#fff;transition:box-shadow .2s,border-color .2s;}
.cm-area-row.dragging{opacity:.5}
.cm-area-row.cm-area-row-flash{border-color:#0d6efd;box-shadow:0 0 0 3px rgba(13,110,253,.25);}
#cmFlexOnlySettings.cm-hidden{display:none;}
</style>

<script>
(function(){
    const framework = <?= json_encode($themeFramework ?? 'custom') ?>;
    const EDITING_CONTAINER = <?= $editingContainer ? json_encode($editingContainer) : 'null' ?>;
    const state = {selected:0, history:[], future:[], areas:[{name:'Main',desktop:12,tablet:12,mobile:12,full:false,nested:true,padding:''}]};
    const $ = id => document.getElementById(id);
    const inputs = ['flexName','flexHandle','flexLayoutMode','flexUseFlex','flexGap','flexPadding','flexInner','flexMobile','flexDirection','flexWrap','flexAlign','flexJustify'];
    let handleTouched=false;
    function slug(s){return (s||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'') || 'container';}
    function pushHistory(){state.history.push(JSON.stringify(state.areas)); if(state.history.length>50) state.history.shift(); state.future=[];}
    function esc(s){return (s+'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

    function updateSettingsVisibility(){
        $('cmFlexOnlySettings').classList.toggle('cm-hidden', $('flexLayoutMode').value !== 'flex');
    }

    function spanFor(a,bp){return parseInt(a.full?12:(a[bp]||12),10);}
    function applyCanvasLayout(canvas){
        const mode=$('flexLayoutMode').value;
        canvas.className='cm-preview-canvas '+(canvas.classList.contains('cm-preview-canvas-small')?'cm-preview-canvas-small ':'')+(mode==='css_grid'?'cm-grid':(mode==='plain'?'cm-plain':''));
        canvas.style.gap=$('flexGap').value; canvas.style.padding=canvas.classList.contains('cm-preview-canvas-small')?'12px':$('flexPadding').value;
        canvas.style.flexDirection=$('flexDirection').value; canvas.style.flexWrap=$('flexWrap').value; canvas.style.alignItems=$('flexAlign').value; canvas.style.justifyContent=$('flexJustify').value;
    }
    function renderCanvas(id){
        const canvas=$(id); if(!canvas) return;
        const mode=$('flexLayoutMode').value, bp=canvas.dataset.breakpoint;
        applyCanvasLayout(canvas); canvas.innerHTML='';
        const isMainCanvas = id==='cmPreviewCanvas';
        const canResizeWidth = isMainCanvas && mode!=='plain';
        state.areas.forEach((a,i)=>{const tile=document.createElement('div'); tile.className='cm-area-tile'+(isMainCanvas?'':' cm-area-tile-static')+(i===state.selected?' active':''); tile.draggable=false; tile.dataset.index=i; const span=spanFor(a,bp); if(mode==='css_grid'){tile.style.gridColumn='span '+span;} else if(mode==='plain'){tile.style.display='block'; tile.style.marginBottom='1rem';} else {tile.style.flex='0 0 '+(span/12*100)+'%'; tile.style.maxWidth=(span/12*100)+'%';} tile.style.padding=a.padding||''; tile.innerHTML='<div class="cm-area-title">'+esc(a.name)+'</div><div class="cm-area-meta">'+bp.toUpperCase()+': '+span+'/12 '+(a.full?'· full row ':'')+(a.nested?'· nested ':'')+'</div><div class="cm-area-resize">'+(isMainCanvas?('drag to reorder'+(canResizeWidth?' · drag edge to resize':'')):'live viewport')+'</div>'+(canResizeWidth?'<div class="cm-area-resize-handle" data-resize-index="'+i+'" title="Drag to resize width"></div>':''); canvas.appendChild(tile);});
    }
    function renderCanvases(){
        ['cmPreviewCanvas','cmPreviewCanvasDesktop','cmPreviewCanvasTablet','cmPreviewCanvasMobile'].forEach(id=>renderCanvas(id));
    }

    function renderInspector(){
        let html='';
        state.areas.forEach((a,i)=>{
            html+='<div class="cm-area-row" data-index="'+i+'"><div class="d-flex justify-content-between align-items-center"><span class="cm-row-drag-handle btn btn-sm btn-outline-secondary" draggable="true" data-drag-index="'+i+'">↕ drag</span><strong class="cm-area-row-label">'+(i+1)+'. '+esc(a.name)+'</strong><button type="button" class="btn btn-sm btn-outline-danger" data-del="'+i+'">Delete</button></div>'
                +'<label class="form-label mt-2">Name</label><input class="form-control form-control-sm" data-name="'+i+'" value="'+esc(a.name)+'">'
                +'<div class="row mt-2"><div class="col"><label class="form-label">Desktop</label><input type="range" min="1" max="12" data-desktop="'+i+'" value="'+a.desktop+'" class="form-range"><small data-desktop-value>'+a.desktop+'/12</small></div>'
                +'<div class="col"><label class="form-label">Tablet</label><input type="range" min="1" max="12" data-tablet="'+i+'" value="'+a.tablet+'" class="form-range"><small data-tablet-value>'+a.tablet+'/12</small></div>'
                +'<div class="col"><label class="form-label">Mobile</label><input type="range" min="1" max="12" data-mobile="'+i+'" value="'+a.mobile+'" class="form-range"><small data-mobile-value>'+a.mobile+'/12</small></div></div>'
                +'<label class="form-label mt-2">Padding <span class="text-muted">(this area only — blank means no extra padding)</span></label><input class="form-control form-control-sm" data-padding="'+i+'" value="'+esc(a.padding||'')+'" placeholder="e.g. 1rem or 16px 24px">'
                +'<div class="form-check form-check-inline mt-2"><input class="form-check-input" type="checkbox" id="cmFull'+i+'" data-full="'+i+'" '+(a.full?'checked':'')+'><label class="form-check-label" for="cmFull'+i+'">Full row</label></div>'
                +'<div class="form-check form-check-inline mt-2"><input class="form-check-input" type="checkbox" id="cmNested'+i+'" data-nested="'+i+'" '+(a.nested?'checked':'')+'><label class="form-check-label" for="cmNested'+i+'">Nested-friendly</label></div></div>';
        });
        $('cmAreaInspector').innerHTML=html;
    }
    // Updates a single row's derived labels in place, without rebuilding the DOM,
    // so a slider or text field being actively dragged/typed into is never replaced.
    function updateRowLabels(i){
        const row = document.querySelector('.cm-area-row[data-index="'+i+'"]');
        if(!row) return;
        const a = state.areas[i];
        const label = row.querySelector('.cm-area-row-label');
        if(label) label.textContent = (i+1)+'. '+a.name;
        ['desktop','tablet','mobile'].forEach(k=>{
            const small = row.querySelector('[data-'+k+'-value]');
            if(small) small.textContent = a[k]+'/12';
            // Keep the slider itself in sync when the change came from somewhere
            // else (e.g. dragging the canvas resize handle), but never overwrite
            // a slider the user currently has their hands on.
            const slider = row.querySelector('[data-'+k+'="'+i+'"]');
            if(slider && document.activeElement !== slider) slider.value = a[k];
        });
    }

    // Clicking a blue area tile selects it (see renderCanvas's 'active' outline)
    // and jumps the Area Settings panel to that area's row so its column span
    // and padding are immediately visible to edit — same behavior in every
    // layout mode, including CSS Grid, since Area Settings isn't mode-specific.
    function focusAreaRow(i){
        const row = document.querySelector('.cm-area-row[data-index="'+i+'"]');
        if(!row) return;
        row.scrollIntoView({behavior:'smooth', block:'nearest'});
        row.classList.add('cm-area-row-flash');
        setTimeout(()=>row.classList.remove('cm-area-row-flash'), 900);
    }

    function renderState(){
        $('flexAreas').value = state.areas.map(a=>a.name).join('\n');
        $('flexAreaGridColumns').value = state.areas.map(a=>a.name+'::'+a.desktop).join('\n');
        $('flexAreaFullRows').value = state.areas.filter(a=>a.full).map(a=>a.name).join('\n');
        $('flexNestedAreas').value = state.areas.filter(a=>a.nested).map(a=>a.name).join('\n');
        $('flexResponsiveColumns').value = state.areas.map(a=>a.name+'::'+a.desktop+'|'+a.tablet+'|'+a.mobile).join('\n');
        $('flexAreaWidths').value = state.areas.map(a=>a.name+'::'+(a.full?'100%':'calc('+a.desktop+' / 12 * 100%)')).join('\n');
        $('flexAreaPadding').value = state.areas.filter(a=>a.padding).map(a=>a.name+'::'+a.padding).join('\n');
    }
    // These mirror ContainerGenerator's PHP builders exactly (same structure,
    // same indentation rule: build each level at a 0-column baseline, then
    // indent the whole child block by 4 once per nesting level) so the Code
    // Preview shown here matches what actually gets saved to disk.
    function indentLines(text, spaces){
        let prefix=' '.repeat(spaces);
        return prefix + text.replace(/\n/g, '\n'+prefix);
    }
    function areaBlock(name){
        return "<?php\n$area = new ContainerArea($container, '"+name.replace(/'/g,"\\'")+"');\n$area->display($c);\n?>";
    }
    function wrapInnerJs(inner, content){
        if(!inner) return content;
        return '<div class="'+inner+'">\n'+indentLines(content,4)+'\n</div>';
    }
    function bootstrapColClasses(mobile, tablet, desktop){
        let classes=[];
        if(mobile<12) classes.push('col-'+mobile);
        if(tablet!==mobile) classes.push('col-md-'+tablet);
        if(desktop!==tablet) classes.push('col-lg-'+desktop);
        if(!classes.length) classes.push('col-12');
        return classes.join(' ');
    }
    function columnsToPercentJs(span){
        return (Math.round(span/12*10000)/100).toString();
    }
    function styleBlock(cls, rules, media){
        let lines=rules.slice();
        lines.push('.ccm-edit-mode .'+cls+' .ccm-area { min-height: 48px; outline: 1px dashed rgba(0, 0, 0, .25); outline-offset: -1px; }');
        let css=lines.join('\n');
        if(media) css += '\n'+media.replace(/\n$/,'');
        return '<style>\n'+css+'\n</style>';
    }
    function renderCode(){
        let handle=slug($('flexHandle').value||$('flexName').value);
        let cls='cm-'+handle.replace(/_/g,'-');
        let mode=$('flexLayoutMode').value;
        let inner=$('flexInner').value||'';
        let gap=$('flexGap').value;
        let body, style;

        if(mode==='grid12'){
            let cols=state.areas.map(a=>{
                let colClasses = a.full ? 'col-12' : bootstrapColClasses(a.mobile,a.tablet,a.desktop);
                return '<div class="'+colClasses+'">\n'+indentLines(areaBlock(a.name),4)+'\n</div>';
            }).join('\n');
            let row='<div class="row">\n'+indentLines(cols,4)+'\n</div>';
            let content=indentLines(wrapInnerJs(inner,row),4);
            body='<div class="'+cls+'">\n'+content+'\n</div>';
            let rules=[];
            state.areas.forEach((a,idx)=>{ if(a.padding) rules.push('.'+cls+' .row > *:nth-child('+(idx+1)+') { padding: '+a.padding+'; }'); });
            style=styleBlock(cls, rules);
        } else if(mode==='css_grid' || mode==='flex'){
            let suffix = mode==='css_grid' ? '__grid' : '__flex';
            let items=state.areas.map(a=>'<div class="'+cls+'__item">\n'+indentLines(areaBlock(a.name),4)+'\n</div>').join('\n');
            let wrap='<div class="'+cls+suffix+'">\n'+indentLines(items,4)+'\n</div>';
            let content=indentLines(wrapInnerJs(inner,wrap),4);
            body='<div class="'+cls+'">\n'+content+'\n</div>';

            let rules = mode==='css_grid'
                ? ['.'+cls+suffix+' { display: grid; grid-template-columns: repeat(12, minmax(0, 1fr)); gap: '+gap+'; }']
                : ['.'+cls+suffix+' { display: flex; flex-direction: '+$('flexDirection').value+'; flex-wrap: '+$('flexWrap').value+'; gap: '+gap+'; align-items: '+$('flexAlign').value+'; justify-content: '+$('flexJustify').value+'; }'];
            let tabletRules=[], mobileRules=[];
            state.areas.forEach((a,idx)=>{
                let sel='.'+cls+suffix+' > *:nth-child('+(idx+1)+')';
                if(a.full){
                    rules.push(mode==='css_grid' ? (sel+' { grid-column: 1 / -1; }') : (sel+' { flex: 0 0 100%; max-width: 100%; }'));
                } else if(mode==='css_grid'){
                    rules.push(sel+' { grid-column: span '+a.desktop+'; }');
                    if(a.tablet!==a.desktop) tabletRules.push(sel+' { grid-column: span '+a.tablet+'; }');
                    if(a.mobile!==a.tablet) mobileRules.push(sel+' { grid-column: span '+a.mobile+'; }');
                } else {
                    let dp=columnsToPercentJs(a.desktop), tp=columnsToPercentJs(a.tablet), mp=columnsToPercentJs(a.mobile);
                    rules.push(sel+' { flex: 0 0 '+dp+'%; max-width: '+dp+'%; }');
                    if(a.tablet!==a.desktop) tabletRules.push(sel+' { flex: 0 0 '+tp+'%; max-width: '+tp+'%; }');
                    if(a.mobile!==a.tablet) mobileRules.push(sel+' { flex: 0 0 '+mp+'%; max-width: '+mp+'%; }');
                }
                if(a.padding) rules.push(sel+' { padding: '+a.padding+'; }');
            });
            let media='';
            if(tabletRules.length) media += '@media (max-width: 991px) {\n    '+tabletRules.join('\n    ')+'\n}\n';
            if(mode==='flex') mobileRules.push('.'+cls+suffix+' { flex-direction: '+$('flexMobile').value+'; }');
            if(mobileRules.length) media += '@media (max-width: 767px) {\n    '+mobileRules.join('\n    ')+'\n}\n';
            style=styleBlock(cls, rules, media);
        } else {
            let items=state.areas.map(a=>'<div class="'+cls+'__item">\n'+indentLines(areaBlock(a.name),4)+'\n</div>').join('\n');
            let content=indentLines(wrapInnerJs(inner,items),4);
            body='<div class="'+cls+'">\n'+content+'\n</div>';
            let rules=[];
            if(gap) rules.push('.'+cls+'__item + .'+cls+'__item { margin-top: '+gap+'; }');
            state.areas.forEach((a,idx)=>{ if(a.padding) rules.push('.'+cls+'__item:nth-child('+(idx+1)+') { padding: '+a.padding+'; }'); });
            style=styleBlock(cls, rules);
        }

        $('cmCodePreview').textContent = "<?php\ndefined('C5_EXECUTE') or die('Access Denied.');\n\nuse Concrete\\Core\\Area\\ContainerArea;\n?>\n"+body+"\n"+style+"\n";
    }

    // Full re-render: rebuilds the inspector's DOM. Only call this for structural
    // changes (add/delete/reorder/undo/redo) — never on every keystroke or slider
    // tick, or the input/slider being interacted with gets destroyed mid-gesture.
    function renderAll(){
        renderState();
        renderCanvases();
        renderInspector();
        renderCode();
    }
    // Lightweight re-render for continuous input (typing a name, dragging a
    // span slider): updates state, canvases, and code, but leaves the
    // currently-focused/dragged inspector element alone.
    function renderLive(){
        renderState();
        renderCanvases();
        renderCode();
    }

    function loadEditingState(editing){
        if(!editing) return;
        $('flexName').value = editing.name || '';
        $('flexHandle').value = editing.handle || '';
        handleTouched = true;
        if(editing.layout_mode) $('flexLayoutMode').value = editing.layout_mode;
        const es = editing.settings || {};
        if(es.gap) $('flexGap').value = es.gap;
        if(es.padding) $('flexPadding').value = es.padding;
        if(es.inner !== undefined) $('flexInner').value = es.inner;
        if(es.mobile) $('flexMobile').value = es.mobile;
        if(es.direction) $('flexDirection').value = es.direction;
        if(es.wrap) $('flexWrap').value = es.wrap;
        if(es.align) $('flexAlign').value = es.align;
        if(es.justify) $('flexJustify').value = es.justify;
        $('flexUseFlex').checked = es.use_flex !== false;
        if(editing.areas && editing.areas.length){
            state.areas = editing.areas.map(a=>({name:a.name,desktop:parseInt(a.desktop,10)||12,tablet:parseInt(a.tablet,10)||12,mobile:parseInt(a.mobile,10)||12,full:!!a.full,nested:!!a.nested,padding:a.padding||''}));
        }
    }

    document.addEventListener('input',e=>{
        let t=e.target;
        if(t.id==='flexName'&&!handleTouched){$('flexHandle').value=slug(t.value);$('flexFilePreview').textContent=$('flexHandle').value+'.php';}
        if(t.id==='flexHandle'){handleTouched=true;$('flexFilePreview').textContent=slug(t.value)+'.php';}

        let liveIndex=null;
        ['name','padding','desktop','tablet','mobile'].forEach(k=>{
            let i=t.dataset[k];
            if(i!==undefined){
                pushHistory();
                state.areas[i][k]=(k==='name'||k==='padding')?t.value:parseInt(t.value,10);
                state.selected=parseInt(i,10);
                liveIndex=i;
            }
        });
        if(liveIndex!==null){ updateRowLabels(liveIndex); renderLive(); return; }

        if(t.id==='flexLayoutMode'){ updateSettingsVisibility(); }
        if(inputs.includes(t.id)||t.id==='cmPreviewWidth'){
            if(t.id==='cmPreviewWidth'){$('cmPreviewShell').style.width=t.value+'px';$('cmPreviewWidthLabel').textContent=t.value+'px';}
            renderAll();
        }
    });
    document.addEventListener('change',e=>{
        let t=e.target;
        ['full','nested'].forEach(k=>{
            let i=t.dataset[k];
            if(i!==undefined){pushHistory(); state.areas[i][k]=t.checked; if(k==='full'&&t.checked){state.areas[i].desktop=12;$('flexWrap').value='wrap';} renderAll();}
        });
    });
    document.addEventListener('click',e=>{
        let t=e.target;
        if(t.id==='cmAddArea'){pushHistory();state.areas.push({name:'Area '+(state.areas.length+1),desktop:6,tablet:12,mobile:12,full:false,nested:true,padding:''});state.selected=state.areas.length-1;renderAll();}
        if(t.dataset.del!==undefined){let i=parseInt(t.dataset.del,10); if(confirm('Delete this area from the designer? You can restore the last deleted area.')){pushHistory(); localStorage.setItem('cm_last_deleted_area', JSON.stringify(state.areas[i])); state.areas.splice(i,1);state.selected=0;renderAll();}}
        if(t.id==='cmRestoreDeleted'){let saved=localStorage.getItem('cm_last_deleted_area'); if(saved){pushHistory(); state.areas.push(JSON.parse(saved)); state.selected=state.areas.length-1; localStorage.removeItem('cm_last_deleted_area'); renderAll();} else {alert('No recently deleted area to restore.');}}
        if(t.id==='cmUndo'&&state.history.length){state.future.push(JSON.stringify(state.areas));state.areas=JSON.parse(state.history.pop());renderAll();}
        if(t.id==='cmRedo'&&state.future.length){state.history.push(JSON.stringify(state.areas));state.areas=JSON.parse(state.future.pop());renderAll();}
    });

    let nativeDragFrom = null;
    document.addEventListener('dragstart',e=>{
        let handle=e.target.closest('.cm-row-drag-handle[data-drag-index]');
        if(handle){nativeDragFrom=parseInt(handle.dataset.dragIndex,10);e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',handle.dataset.dragIndex);} else {nativeDragFrom=null;}
    });
    document.addEventListener('dragover',e=>{if(nativeDragFrom!==null && e.target.closest('.cm-area-row[data-index]')) e.preventDefault();});
    document.addEventListener('drop',e=>{let row=e.target.closest('.cm-area-row[data-index]'); if(nativeDragFrom!==null && row){e.preventDefault();let from=nativeDragFrom,to=parseInt(row.dataset.index,10); nativeDragFrom=null; if(from!==to){pushHistory();let item=state.areas.splice(from,1)[0];state.areas.splice(to,0,item);renderAll();}}});
    document.addEventListener('dragend',()=>{nativeDragFrom=null;});

    let pointerDrag = null;
    function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
    function beginCanvasDrag(e){
        if(e.target.closest('input,button,select,textarea,label,a,.cm-area-resize-handle')) return;
        const tile=e.target.closest('#cmPreviewCanvas .cm-area-tile[data-index]');
        if(!tile) return;
        e.preventDefault();
        const canvas=$('cmPreviewCanvas'), canvasRect=canvas.getBoundingClientRect(), tileRect=tile.getBoundingClientRect();
        pointerDrag={tile,index:parseInt(tile.dataset.index,10),startX:e.clientX,startY:e.clientY,dx:0,dy:0,canvasRect,tileRect};
        tile.classList.add('cm-pointer-dragging');
        tile.setPointerCapture?.(e.pointerId);
    }
    function moveCanvasDrag(e){
        if(!pointerDrag) return;
        e.preventDefault();
        const maxX=Math.max(0,pointerDrag.canvasRect.width-pointerDrag.tileRect.width);
        const maxY=Math.max(0,pointerDrag.canvasRect.height-pointerDrag.tileRect.height);
        const originalX=pointerDrag.tileRect.left-pointerDrag.canvasRect.left;
        const originalY=pointerDrag.tileRect.top-pointerDrag.canvasRect.top;
        const nextX=clamp(originalX+(e.clientX-pointerDrag.startX),0,maxX);
        const nextY=clamp(originalY+(e.clientY-pointerDrag.startY),0,maxY);
        pointerDrag.dx=nextX-originalX; pointerDrag.dy=nextY-originalY;
        pointerDrag.tile.style.transform='translate('+pointerDrag.dx+'px,'+pointerDrag.dy+'px)';
    }
    function endCanvasDrag(e){
        if(!pointerDrag) return;
        const drag=pointerDrag; pointerDrag=null;
        drag.tile.classList.remove('cm-pointer-dragging');
        drag.tile.style.transform='';
        // A plain click (no real movement) must never reorder: the nearest-tile
        // search below always finds *some* other tile as "closest" once the
        // dragged tile itself is excluded, even at zero distance moved — so
        // without this guard, every click on a 2-area canvas swapped them.
        if(Math.hypot(drag.dx,drag.dy) < 4){
            state.selected=drag.index; renderAll(); focusAreaRow(drag.index);
            return;
        }
        const canvas=$('cmPreviewCanvas');
        const tiles=[...canvas.querySelectorAll('.cm-area-tile[data-index]')];
        const centerX=drag.tileRect.left+drag.dx+drag.tileRect.width/2;
        const centerY=drag.tileRect.top+drag.dy+drag.tileRect.height/2;
        let to=drag.index, best=Infinity;
        tiles.forEach(el=>{
            const idx=parseInt(el.dataset.index,10); if(idx===drag.index) return;
            const r=el.getBoundingClientRect();
            const d=Math.hypot(centerX-(r.left+r.width/2), centerY-(r.top+r.height/2));
            if(d<best){best=d;to=idx;}
        });
        if(to!==drag.index){pushHistory();let item=state.areas.splice(drag.index,1)[0];state.areas.splice(to,0,item);state.selected=to;renderAll();focusAreaRow(to);}
        else {state.selected=drag.index;renderAll();focusAreaRow(drag.index);}
    }
    $('cmPreviewCanvas').addEventListener('pointerdown',beginCanvasDrag);
    ['cmPreviewCanvasDesktop','cmPreviewCanvasTablet','cmPreviewCanvasMobile'].forEach(id=>{let c=$(id); if(c){c.addEventListener('click',e=>{let tile=e.target.closest('.cm-area-tile[data-index]'); if(tile){state.selected=parseInt(tile.dataset.index,10); renderAll(); focusAreaRow(state.selected);}});}});
    document.addEventListener('pointermove',moveCanvasDrag);
    document.addEventListener('pointerup',endCanvasDrag);
    document.addEventListener('pointercancel',endCanvasDrag);

    // Drag-to-resize: a handle on the right edge of each main-canvas tile lets
    // you change its Desktop column span directly, instead of only via the
    // Area Settings slider. Works the same regardless of layout mode/grid
    // system, since every mode stores width as a 1-12 column span internally.
    let resizeDrag = null;
    function applyLiveSpan(tile,mode,span){
        if(mode==='css_grid'){ tile.style.gridColumn='span '+span; }
        else if(mode!=='plain'){ tile.style.flex='0 0 '+(span/12*100)+'%'; tile.style.maxWidth=(span/12*100)+'%'; }
        const meta=tile.querySelector('.cm-area-meta');
        if(meta){
            const a=state.areas[resizeDrag.index];
            meta.textContent='DESKTOP: '+span+'/12 '+(a.full?'· full row ':'')+(a.nested?'· nested ':'');
        }
    }
    function beginResizeDrag(e){
        const handle=e.target.closest('.cm-area-resize-handle');
        if(!handle) return;
        e.preventDefault();
        const tile=handle.closest('.cm-area-tile[data-index]');
        const canvas=$('cmPreviewCanvas');
        const i=parseInt(handle.dataset.resizeIndex,10);
        pushHistory();
        resizeDrag={index:i,tile,startX:e.clientX,colWidth:canvas.getBoundingClientRect().width/12,startSpan:state.areas[i].desktop,mode:$('flexLayoutMode').value};
        tile.classList.add('cm-pointer-dragging');
        handle.setPointerCapture?.(e.pointerId);
    }
    function moveResizeDrag(e){
        if(!resizeDrag) return;
        e.preventDefault();
        const deltaCols=Math.round((e.clientX-resizeDrag.startX)/resizeDrag.colWidth);
        const next=clamp(resizeDrag.startSpan+deltaCols,1,12);
        if(next!==state.areas[resizeDrag.index].desktop){
            state.areas[resizeDrag.index].desktop=next;
            if(state.areas[resizeDrag.index].full && next<12){ state.areas[resizeDrag.index].full=false; }
            applyLiveSpan(resizeDrag.tile,resizeDrag.mode,next);
            updateRowLabels(resizeDrag.index);
            renderCanvas('cmPreviewCanvasDesktop');
            renderCode();
        }
    }
    function endResizeDrag(){
        if(!resizeDrag) return;
        resizeDrag.tile.classList.remove('cm-pointer-dragging');
        resizeDrag=null;
        renderAll();
    }
    document.addEventListener('pointerdown',beginResizeDrag);
    document.addEventListener('pointermove',moveResizeDrag);
    document.addEventListener('pointerup',endResizeDrag);
    document.addEventListener('pointercancel',endResizeDrag);

    loadEditingState(EDITING_CONTAINER);
    $('cmPreviewShell').style.width='900px';
    $('cmDetectedFramework') && ($('cmDetectedFramework').textContent=framework);
    $('flexFilePreview').textContent = $('flexHandle').value ? (slug($('flexHandle').value)+'.php') : '—';
    updateSettingsVisibility();
    renderAll();
})();
</script>
