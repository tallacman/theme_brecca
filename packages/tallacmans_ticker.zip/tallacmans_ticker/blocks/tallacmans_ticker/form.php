<?php defined('C5_EXECUTE') or exit('Access Denied.');
$color = $app->make('helper/form/color');
?>

<div class="form-group">
    <?php
    echo $form->label($view->field('items'), t('Ticker Items'));
echo "<p class='small muted'>";
echo t('Enter a return after each item to display a space between items.');
echo '</p>';
echo $form->textarea($view->field('items'), $items, [
    'rows' => 8,
]);
?>
</div>
<div class="row">
  <div class="col-xs-12 col-sm-12">
    <?php
  echo "<span class='small muted'>";
echo t('Pixels: Start at 16 pixels, 1 em or 1 rem. Font face is inherited from your site.');
echo '</span>';
echo '<br>';
echo "<span class='small muted'>";
echo t('Speed: Time for one complete cycle in seconds. Needs to be a positive number greater than 0 (zero).');
echo '</span>';
echo '<hr>';
?>
  </div>
</div>

<div class="row">
  <div class="col-xs-12 col-sm-4">
    <div class="form-group">
      <?php
  echo $form->label($view->field('sizeUnit'), t('Font Units'));
echo $form->select($view->field('sizeUnit'), $sizeUnit_options, $sizeUnit, []);
?>
    </div>
  </div>

  <div class="col-xs-12 col-sm-2">
    <div class="form-group">
      <?php
echo $form->label($view->field('fontSize'), t('Font Size'));
echo $form->text($view->field('fontSize'), $fontSize, []);
?>

    </div>
  </div>

  <div class="col-xs-12 col-sm-3">
    <div class="form-group">
      <?php
echo $form->label($view->field('speed'), t('Scoll Speed'));
echo $form->text($view->field('speed'), $speed, []);
?>
    </div>
  </div>

  <div class="col-xs-12 col-sm-4">
    <div class="form-group">
      <?php
echo $form->label($view->field('fontStyle'), t('Font Style'));
echo $form->select($view->field('fontStyle'), $fontStyle_options, $fontStyle, []);
?>
    </div>
  </div>

</div> <!--   end row  -->

<div class="row">

  <div class="col-xs-12 col-sm-6">
    <div class="form-group">
      <?php
  echo $form->label('colorBack', t('Background Color'));
echo '&nbsp;';
echo $color->output('colorBack', $colorBack, ['showAlpha' => 'false', 'showPalette' => 'true']);
?>
    </div>
  </div>
  <div class="col-xs-12 col-sm-6">
    <div class="form-group">
      <?php
echo $form->label('colorText', t('Text Color'));
echo '&nbsp;';
echo $color->output('colorText', $colorText, ['showAlpha' => 'false', 'showPalette' => 'true']);
?>
    </div>
  </div>

</div>
