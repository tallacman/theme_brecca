<?php defined('C5_EXECUTE') or exit('Access Denied.');
$c = Page::getCurrentPage();

?>
<!--   from https://codepen.io/lewismcarey/pen/GJZVoG  -->
<?php if (isset($items_options) && ! empty($items_options)) { ?>

  <div class="ticker-wrap" style="background-color:<?php echo $colorBack; ?>">
    <div class="ticker" style="animation-duration:<?php echo $speed; ?>s;">

      <?php foreach ($items_options as $items_option) { ?>
        <div class="ticker-item" style="color:<?php echo $colorText; ?>; font-size:<?php echo $fontSize; ?><?php echo $sizeUnit; ?>; font-weight: <?php echo $fontStyle; ?>; ">
          <?php echo $items_option; ?>
        </div>
      <?php
      } ?>
    </div>
  </div>
<?php } ?>
<?php if (empty($items_options) && ($c->isEditMode())) { ?>

  <div class="empty-ticker">
    <?php echo t('Your ticker contains no items to display.'); ?>
  </div>

<?php } ?>
