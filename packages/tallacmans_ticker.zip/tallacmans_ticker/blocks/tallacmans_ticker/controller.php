<?php

namespace Concrete\Package\TallacmansTicker\Block\TallacmansTicker;

defined('C5_EXECUTE') or exit('Access Denied.');

use Concrete\Core\Block\BlockController;

class Controller extends BlockController
{
    public $btFieldsRequired = [];

    protected $btTable = 'btTallacmansTicker';

    protected $btInterfaceWidth = 600;

    protected $btInterfaceHeight = 800;

    protected $btIgnorePageThemeGridFrameworkContainer = true;

    protected $btDefaultSet = 'multimedia';

    public function getBlockTypeDescription()
    {
        return t('Srolling text on your page.');
    }

    public function getBlockTypeName()
    {
        return t('Tallacmans Ticker');
    }

    public function on_start()
    {
        $this->set('app', $this->app);
    }

    public function view()
    {
        $this->set('items_options', trim($this->items) != '' ? explode("\n", $this->items) : []);
    }

    public function add()
    {

        $this->set('colorBack', 'rgb(0,0,0)');
        $this->set('colorText', 'rgb(255,255,255)');
        $this->set('speed', 30);
        $this->set('fontSize', 16);
        $this->set('items', '');
        $this->set('sizeUnit', '');
        $this->set('fontStyle', '');

        $this->addEdit();
    }

    public function edit()
    {
        if (trim($this->speed) == 0) {
            $this->set('speed', 30);
        }
        $this->addEdit();
    }

    protected function addEdit()
    {
        $this->set('fontStyle_options', [
            'inherit' => t('Normal'),
            'bold' => t('Bold'),
        ]
        );
        $this->set('sizeUnit_options', [
            'px' => t('pixels'),
            'em' => t('Em\'s'),
            'rem' => t('Relative Em\'s'),
        ]
        );
    }

    public function validate($data)
    {
        $e = $this->app->make('error');

        // cannot be blank or "0"
        if (empty($data['speed'])) {
            $e->add(t('Speed cannot be blank. Please enter a number.'));
        }

        // cannot be non numeric
        if (! is_numeric($data['speed'])) {
            $e->add(t('Speed must be a number.'));
        }

        // cannot be a negative number
        if (($data['speed']) < 0) {
            $e->add(t('Speed must be a POSITIVE number.'));
        }

        if (($data['speed']) > 3600) {
            $e->add(t("Speed must be smaller than 3600 seconds. That's only once per hour."));
        }

        if (mb_strlen($data['fontSize']) > 12) {
            $e->add(t('Font size must be less than 12 digits.'));
        }

        if (($data['fontSize']) <= 0) {
            $e->add(t('Font size must be a POSITIVE number between 1 and 12 digits long.'));
        }

        return $e;
    }
}
