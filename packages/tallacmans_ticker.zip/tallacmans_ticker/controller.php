<?php

namespace Concrete\Package\TallacmansTicker;

use Concrete\Core\Block\BlockType\BlockType;
use Concrete\Core\Package\Package;
use Concrete\Core\Support\Facade\Database;

defined('C5_EXECUTE') or exit('Access Denied.');

class Controller extends Package
{
    protected $pkgHandle = 'tallacmans_ticker';

    protected $appVersionRequired = '8.0.0';

    protected $pkgVersion = '1.0.0';

    public function getPackageName()
    {
        return t('Tallacmans Ticker');
    }

    public function getPackageDescription()
    {
        return t('Scroll text on your site with ease.');
    }

    public function install()
    {
        $pkg = parent::install();
        $btHandles = [
            'tallacmans_ticker',
        ];
        foreach ($btHandles as $btHandle) {
            if (! BlockType::getByHandle($btHandle)) {
                BlockType::installBlockType($btHandle, $pkg);
            }
        }
    }

    public function uninstall()
    {
        // needs use Concrete\Core\Support\Facade\Database;
        // cleanup package on uninstall
        $pkg = parent::uninstall();

        // drop database table
        $db = Database::connection();
        $db->executeQuery('drop table if exists btTallacmansTicker');
    }
}
