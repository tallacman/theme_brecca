<?php
namespace Concrete\Package\ContainerMaker\Service;

use Concrete\Core\Page\Theme\Theme;

class ContainerGenerator
{
    /**
     * Read the designer state that was embedded in a container PHP file when it was
     * generated, so it can be reloaded into the Visual Designer for editing.
     *
     * @return array|null
     */
    public function readDesignerState($filePath)
    {
        if (!$filePath || !is_file($filePath)) {
            return null;
        }
        $contents = @file_get_contents($filePath);
        if ($contents === false) {
            return null;
        }
        if (!preg_match('/CM_DESIGNER_STATE\s+([A-Za-z0-9+\/=]+)\s+CM_DESIGNER_STATE_END/', $contents, $m)) {
            return null;
        }
        $json = base64_decode($m[1], true);
        if ($json === false) {
            return null;
        }
        $data = json_decode($json, true);
        return is_array($data) ? $data : null;
    }

    public function generateFlex(Theme $theme, array $data)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $themePath = $this->getThemePath($theme);
        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $name = trim((string) ($data['name'] ?? ''));
        $handle = $this->sanitizeHandle((string) ($data['handle'] ?? ''));
        if ($name === '') {
            $name = t('Custom Flex Container');
        }
        if ($handle === '') {
            $handle = $this->sanitizeHandle($name);
        }
        if ($handle === '') {
            $result['errors'][] = t('Please enter a valid container handle.');
            return $result;
        }

        $areas = $this->parseAreaNames((string) ($data['areas'] ?? 'Main'));
        if (empty($areas)) {
            $result['errors'][] = t('Please enter at least one editable area.');
            return $result;
        }

        $areaWidths = $this->parseAreaWidths((string) ($data['area_widths'] ?? ''), $areas);
        $areaGridColumns = $this->parseAreaGridColumns((string) ($data['area_grid_columns'] ?? ''), $areas);
        $areaFullRows = $this->parseAreaFullRows((string) ($data['area_full_rows'] ?? ''), $areas);
        $settings = $this->normalizeFlexSettings($data);
        if ($settings['layout_mode'] === 'grid12') {
            foreach ($areas as $areaName) {
                $span = $areaGridColumns[$areaName] ?? null;
                if ($span !== null) {
                    $areaWidths[$areaName] = 'calc(' . $span . ' / 12 * 100%)';
                }
            }
            $settings['use_flex'] = true;
            $settings['direction'] = 'row';
            $settings['wrap'] = 'wrap';
            $settings['grow'] = '0';
            $settings['shrink'] = '0';
            $settings['basis'] = '100%';
        }

        $responsiveColumns = $this->parseResponsiveColumns((string) ($data['responsive_columns'] ?? ''), $areas);
        $nestedAreas = $this->parseAreaFullRows((string) ($data['nested_areas'] ?? ''), $areas);
        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
        $overwrite = !empty($data['overwrite']);
        if (file_exists($file) && !$overwrite) {
            $result['skipped'][] = $file;
        } else {
            $php = $this->buildFlexContainerPhp($handle, $name, $areas, $settings, $areaWidths, $areaFullRows, $responsiveColumns ?? [], $nestedAreas ?? []);
            if (@file_put_contents($file, $php) === false) {
                $result['errors'][] = t('Could not write file: %s', $file);
                return $result;
            }
            $result['created'][] = $file;
        }

        if (!empty($data['register'])) {
            $registered = $this->tryRegisterContainer($handle, $name);
            if ($registered === true) {
                $result['registered'][] = $name . ' (' . $handle . ')';
            } elseif (is_string($registered)) {
                $result['errors'][] = $registered;
            }
        }

        return $result;
    }

    /**
     * Build the container's PHP source. Output is plain, idiomatic markup with
     * no inline styles or CSS custom properties on the elements themselves —
     * matching hand-written container templates. Anything that needs custom
     * CSS (per-area spans/padding, gap) is emitted as normal class/nth-child
     * rules in a single trailing <style> block, kept as small as possible.
     */
    protected function buildFlexContainerPhp($handle, $name, array $areas, array $settings, array $areaWidths = [], array $areaFullRows = [], array $responsiveColumns = [], array $nestedAreas = [])
    {
        $class = 'cm-' . str_replace('_', '-', $handle);
        $inner = $settings['inner'];

        $designerState = base64_encode(json_encode([
            'name' => $name,
            'handle' => $handle,
            'layout_mode' => $settings['layout_mode'],
            'settings' => [
                'gap' => $settings['gap'],
                'padding' => $settings['padding'],
                'inner' => $settings['inner'],
                'mobile' => $settings['mobile'],
                'direction' => $settings['direction'],
                'wrap' => $settings['wrap'],
                'align' => $settings['align'],
                'justify' => $settings['justify'],
                'use_flex' => !empty($settings['use_flex']),
            ],
            'areas' => array_map(static function ($areaName) use ($responsiveColumns, $areaFullRows, $nestedAreas) {
                return [
                    'name' => $areaName,
                    'desktop' => (int) ($responsiveColumns[$areaName]['desktop'] ?? 12),
                    'tablet' => (int) ($responsiveColumns[$areaName]['tablet'] ?? 12),
                    'mobile' => (int) ($responsiveColumns[$areaName]['mobile'] ?? 12),
                    'full' => in_array($areaName, $areaFullRows, true),
                    'nested' => in_array($areaName, $nestedAreas, true),
                ];
            }, $areas),
        ]));

        switch ($settings['layout_mode']) {
            case 'grid12':
                [$body, $style] = $this->buildGrid12Markup($class, $inner, $areas, $areaFullRows, $responsiveColumns);
                break;
            case 'css_grid':
                [$body, $style] = $this->buildCssGridMarkup($class, $inner, $areas, $areaFullRows, $responsiveColumns, $settings);
                break;
            case 'plain':
                [$body, $style] = $this->buildPlainMarkup($class, $inner, $areas, $settings);
                break;
            case 'flex':
            default:
                [$body, $style] = $this->buildFlexMarkup($class, $inner, $areas, $areaFullRows, $responsiveColumns, $settings);
                break;
        }

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

/* CM_DESIGNER_STATE {$designerState} CM_DESIGNER_STATE_END */

use Concrete\Core\Area\ContainerArea;
?>
{$body}
{$style}

PHP;
    }

    /**
     * Literal (unrolled) PHP block that declares and displays one named area —
     * deliberately not a foreach loop, so each area reads like a normal,
     * hand-written Concrete container area. Assumes a 0-column baseline; callers
     * indent the whole block with indentLines() as they nest it.
     */
    protected function areaPhpBlock($areaName)
    {
        $escapedName = addslashes($areaName);

        return "<?php\n"
            . '$area = new ContainerArea($container, \'' . $escapedName . "');\n"
            . "\$area->display(\$c);\n"
            . '?>';
    }

    /**
     * Indent every line of a block of markup by $spaces. Every builder below
     * assembles markup assuming a 0-column baseline and nests children by
     * indenting the whole child block exactly once per level — so indentation
     * always lines up regardless of how deep the structure is.
     */
    protected function indentLines($text, $spaces)
    {
        $prefix = str_repeat(' ', $spaces);

        return $prefix . str_replace("\n", "\n" . $prefix, rtrim((string) $text));
    }

    /**
     * Wrap $content in the user's chosen inner wrapper (container/container-fluid),
     * or return it unchanged if they chose no wrapper. $content is assumed to be
     * at a 0-column baseline either way.
     */
    protected function wrapInner($inner, $content)
    {
        if ($inner === '') {
            return $content;
        }

        return '<div class="' . $inner . "\">\n" . $this->indentLines($content, 4) . "\n</div>";
    }

    protected function wrapStyle($class, array $rules, $mediaExtra = '')
    {
        $lines = $rules;
        $lines[] = '.ccm-edit-mode .' . $class . ' .ccm-area { min-height: 48px; outline: 1px dashed rgba(0, 0, 0, .25); outline-offset: -1px; }';
        $css = implode("\n", $lines);
        if ($mediaExtra !== '') {
            $css .= "\n" . rtrim($mediaExtra);
        }

        return "<style>\n{$css}\n</style>";
    }

    /**
     * Bootstrap-style column classes (col-{mobile} col-md-{tablet} col-lg-{desktop}),
     * only including a tier's class when it actually differs from the previous
     * tier — matches how this is normally hand-written (e.g. just "col-md-6").
     */
    protected function buildBootstrapColClasses($mobile, $tablet, $desktop)
    {
        $classes = [];
        if ($mobile < 12) {
            $classes[] = 'col-' . $mobile;
        }
        if ($tablet !== $mobile) {
            $classes[] = 'col-md-' . $tablet;
        }
        if ($desktop !== $tablet) {
            $classes[] = 'col-lg-' . $desktop;
        }
        if (empty($classes)) {
            $classes[] = 'col-12';
        }

        return implode(' ', $classes);
    }

    protected function buildGrid12Markup($class, $inner, array $areas, array $areaFullRows, array $responsiveColumns)
    {
        $cols = [];
        foreach ($areas as $areaName) {
            $isFull = in_array($areaName, $areaFullRows, true);
            $colClasses = $isFull ? 'col-12' : $this->buildBootstrapColClasses(
                (int) ($responsiveColumns[$areaName]['mobile'] ?? 12),
                (int) ($responsiveColumns[$areaName]['tablet'] ?? 12),
                (int) ($responsiveColumns[$areaName]['desktop'] ?? 12)
            );
            $cols[] = '<div class="' . $colClasses . "\">\n" . $this->indentLines($this->areaPhpBlock($areaName), 4) . "\n</div>";
        }
        $colsHtml = $this->indentLines(implode("\n", $cols), 4);
        $row = "<div class=\"row\">\n{$colsHtml}\n</div>";

        $content = $this->indentLines($this->wrapInner($inner, $row), 4);
        $body = '<div class="' . $class . "\">\n{$content}\n</div>";
        $style = $this->wrapStyle($class, []);

        return [$body, $style];
    }

    protected function buildCssGridMarkup($class, $inner, array $areas, array $areaFullRows, array $responsiveColumns, array $settings)
    {
        $items = [];
        $desktopRules = [];
        $tabletRules = [];
        $mobileRules = [];
        $i = 0;
        foreach ($areas as $areaName) {
            $i++;
            $items[] = '<div class="' . $class . "__item\">\n" . $this->indentLines($this->areaPhpBlock($areaName), 4) . "\n</div>";
            $selector = '.' . $class . '__grid > *:nth-child(' . $i . ')';
            if (in_array($areaName, $areaFullRows, true)) {
                $desktopRules[] = $selector . ' { grid-column: 1 / -1; }';
            } else {
                $desktop = (int) ($responsiveColumns[$areaName]['desktop'] ?? 12);
                $tablet = (int) ($responsiveColumns[$areaName]['tablet'] ?? 12);
                $mobile = (int) ($responsiveColumns[$areaName]['mobile'] ?? 12);
                $desktopRules[] = $selector . ' { grid-column: span ' . $desktop . '; }';
                if ($tablet !== $desktop) {
                    $tabletRules[] = $selector . ' { grid-column: span ' . $tablet . '; }';
                }
                if ($mobile !== $tablet) {
                    $mobileRules[] = $selector . ' { grid-column: span ' . $mobile . '; }';
                }
            }
        }
        $itemsHtml = $this->indentLines(implode("\n", $items), 4);
        $grid = '<div class="' . $class . "__grid\">\n{$itemsHtml}\n</div>";

        $content = $this->indentLines($this->wrapInner($inner, $grid), 4);
        $body = '<div class="' . $class . "\">\n{$content}\n</div>";

        $rules = array_merge(
            ['.' . $class . '__grid { display: grid; grid-template-columns: repeat(12, minmax(0, 1fr)); gap: ' . $settings['gap'] . '; }'],
            $desktopRules
        );
        $media = '';
        if (!empty($tabletRules)) {
            $media .= "@media (max-width: 991px) {\n    " . implode("\n    ", $tabletRules) . "\n}\n";
        }
        if (!empty($mobileRules)) {
            $media .= "@media (max-width: 767px) {\n    " . implode("\n    ", $mobileRules) . "\n}\n";
        }
        $style = $this->wrapStyle($class, $rules, $media);

        return [$body, $style];
    }

    protected function buildFlexMarkup($class, $inner, array $areas, array $areaFullRows, array $responsiveColumns, array $settings)
    {
        $items = [];
        $desktopRules = [];
        $tabletRules = [];
        $mobileRules = [];
        $i = 0;
        foreach ($areas as $areaName) {
            $i++;
            $items[] = '<div class="' . $class . "__item\">\n" . $this->indentLines($this->areaPhpBlock($areaName), 4) . "\n</div>";
            $selector = '.' . $class . '__flex > *:nth-child(' . $i . ')';
            if (in_array($areaName, $areaFullRows, true)) {
                $desktopRules[] = $selector . ' { flex: 0 0 100%; max-width: 100%; }';
            } else {
                $desktop = (int) ($responsiveColumns[$areaName]['desktop'] ?? 12);
                $tablet = (int) ($responsiveColumns[$areaName]['tablet'] ?? 12);
                $mobile = (int) ($responsiveColumns[$areaName]['mobile'] ?? 12);
                $desktopPct = $this->columnsToPercent($desktop);
                $tabletPct = $this->columnsToPercent($tablet);
                $mobilePct = $this->columnsToPercent($mobile);
                $desktopRules[] = $selector . ' { flex: 0 0 ' . $desktopPct . '%; max-width: ' . $desktopPct . '%; }';
                if ($tablet !== $desktop) {
                    $tabletRules[] = $selector . ' { flex: 0 0 ' . $tabletPct . '%; max-width: ' . $tabletPct . '%; }';
                }
                if ($mobile !== $tablet) {
                    $mobileRules[] = $selector . ' { flex: 0 0 ' . $mobilePct . '%; max-width: ' . $mobilePct . '%; }';
                }
            }
        }
        $itemsHtml = $this->indentLines(implode("\n", $items), 4);
        $flex = '<div class="' . $class . "__flex\">\n{$itemsHtml}\n</div>";

        $content = $this->indentLines($this->wrapInner($inner, $flex), 4);
        $body = '<div class="' . $class . "\">\n{$content}\n</div>";

        $rules = array_merge(
            ['.' . $class . '__flex { display: flex; flex-direction: ' . $settings['direction'] . '; flex-wrap: ' . $settings['wrap'] . '; gap: ' . $settings['gap'] . '; align-items: ' . $settings['align'] . '; justify-content: ' . $settings['justify'] . '; }'],
            $desktopRules
        );
        $media = '';
        if (!empty($tabletRules)) {
            $media .= "@media (max-width: 991px) {\n    " . implode("\n    ", $tabletRules) . "\n}\n";
        }
        $mobileBlock = $mobileRules;
        $mobileBlock[] = '.' . $class . '__flex { flex-direction: ' . $settings['mobile'] . '; }';
        $media .= "@media (max-width: 767px) {\n    " . implode("\n    ", $mobileBlock) . "\n}\n";
        $style = $this->wrapStyle($class, $rules, $media);

        return [$body, $style];
    }

    protected function buildPlainMarkup($class, $inner, array $areas, array $settings)
    {
        $items = [];
        foreach ($areas as $areaName) {
            $items[] = '<div class="' . $class . "__item\">\n" . $this->indentLines($this->areaPhpBlock($areaName), 4) . "\n</div>";
        }
        $stack = implode("\n", $items);

        $content = $this->indentLines($this->wrapInner($inner, $stack), 4);
        $body = '<div class="' . $class . "\">\n{$content}\n</div>";

        $rules = [];
        if ($settings['gap'] !== '') {
            $rules[] = '.' . $class . '__item + .' . $class . '__item { margin-top: ' . $settings['gap'] . '; }';
        }
        $style = $this->wrapStyle($class, $rules);

        return [$body, $style];
    }

    protected function columnsToPercent($span)
    {
        $percent = round($span / 12 * 10000) / 100;

        return rtrim(rtrim(number_format($percent, 2, '.', ''), '0'), '.');
    }

    protected function parseAreaNames($input)
    {
        $parts = preg_split('/[\r\n,]+/', $input);
        $areas = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $areas[] = $part;
            }
        }
        return array_values(array_unique($areas));
    }

    protected function parseAreaWidths($input, array $areas)
    {
        $widths = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $width] = array_map('trim', explode('::', $line, 2));
            if ($area !== '' && in_array($area, $areas, true)) {
                $widths[$area] = $this->safeCssLength($width, '0');
            }
        }
        return $widths;
    }


    protected function parseAreaGridColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $span] = array_map('trim', explode('::', $line, 2));
            $span = (int) $span;
            if ($area !== '' && in_array($area, $areas, true) && $span >= 1 && $span <= 12) {
                $columns[$area] = $span;
            }
        }
        return $columns;
    }



    protected function parseResponsiveColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_map('intval', array_pad(explode('|', $value), 3, 12));
            $columns[$area] = [
                'desktop' => max(1, min(12, $parts[0])),
                'tablet' => max(1, min(12, $parts[1])),
                'mobile' => max(1, min(12, $parts[2])),
            ];
        }
        return $columns;
    }

    protected function parseAreaFullRows($input, array $areas)
    {
        $fullRows = [];
        $lines = preg_split('/[\r\n,]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && in_array($line, $areas, true)) {
                $fullRows[] = $line;
            }
        }
        return array_values(array_unique($fullRows));
    }

    protected function normalizeFlexSettings(array $data)
    {
        return [
            'layout_mode' => $this->inList($data['layout_mode'] ?? 'flex', ['flex', 'grid12', 'css_grid', 'plain'], 'flex'),
            'use_flex' => !empty($data['use_flex']) || (($data['layout_mode'] ?? '') === 'grid12'),
            'direction' => $this->inList($data['direction'] ?? 'row', ['row', 'row-reverse', 'column', 'column-reverse'], 'row'),
            'wrap' => $this->inList($data['wrap'] ?? 'wrap', ['nowrap', 'wrap', 'wrap-reverse'], 'wrap'),
            'align' => $this->inList($data['align'] ?? 'stretch', ['stretch', 'flex-start', 'center', 'flex-end', 'baseline'], 'stretch'),
            'justify' => $this->inList($data['justify'] ?? 'flex-start', ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], 'flex-start'),
            'inner' => $this->inList($data['inner'] ?? 'container', ['container', 'container-fluid', ''], 'container'),
            'mobile' => $this->inList($data['mobile'] ?? 'column', ['column', 'row'], 'column'),
            'gap' => $this->safeCssLength($data['gap'] ?? '1rem', '1rem'),
            'padding' => $this->safeCssLengthList($data['padding'] ?? '2rem 0', '2rem 0'),
            'basis' => $this->safeCssLength($data['basis'] ?? '0', '0'),
            'grow' => preg_match('/^[0-9]+(\.[0-9]+)?$/', (string) ($data['grow'] ?? '1')) ? (string) $data['grow'] : '1',
            'shrink' => preg_match('/^[0-9]+(\.[0-9]+)?$/', (string) ($data['shrink'] ?? '1')) ? (string) $data['shrink'] : '1',
        ];
    }

    protected function sanitizeHandle($handle)
    {
        $handle = strtolower(trim($handle));
        $handle = preg_replace('/[^a-z0-9]+/', '_', $handle);
        return trim($handle, '_');
    }

    protected function inList($value, array $allowed, $default)
    {
        $value = (string) $value;
        return in_array($value, $allowed, true) ? $value : $default;
    }

    protected function safeCssLength($value, $default)
    {
        $value = trim((string) $value);
        return preg_match('/^[-0-9.]+(px|rem|em|%|vw|vh)?$/', $value) ? $value : $default;
    }

    protected function safeCssLengthList($value, $default)
    {
        $value = trim((string) $value);
        return preg_match('/^[-0-9. ]+(px|rem|em|%|vw|vh)?( [-0-9.]+(px|rem|em|%|vw|vh)?){0,3}$/', $value) ? $value : $default;
    }

    protected function getThemePath(Theme $theme)
    {
        if (method_exists($theme, 'getThemeDirectory')) {
            $dir = $theme->getThemeDirectory();
            if ($dir && is_dir($dir)) {
                return $dir;
            }
        }

        $handle = $theme->getThemeHandle();
        $paths = [
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ];
        foreach ($paths as $path) {
            if (is_dir($path)) {
                return $path;
            }
        }
        return null;
    }

    protected function tryRegisterContainer($handle, $name)
    {
        // Concrete 9 stores containers as Doctrine entities. Class names have varied in some builds,
        // so this method is intentionally defensive. File generation still works if this fails.
        $classes = [
            '\\Concrete\\Core\\Entity\\Page\\Container',
            '\\Concrete\\Core\\Entity\\Page\\ContainerTemplate',
        ];

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                continue;
            }
            try {
                $app = \Core::make('app');
                $em = $app->make('database/orm')->entityManager();
                $repo = $em->getRepository($class);
                $existing = method_exists($repo, 'findOneBy') ? $repo->findOneBy(['containerHandle' => $handle]) : null;
                if ($existing) {
                    return true;
                }
                $entity = new $class();
                if (method_exists($entity, 'setContainerName')) {
                    $entity->setContainerName($name);
                }
                if (method_exists($entity, 'setContainerHandle')) {
                    $entity->setContainerHandle($handle);
                }
                $em->persist($entity);
                $em->flush();
                return true;
            } catch (\Throwable $e) {
                return t('Created file for %s, but automatic registration failed: %s', $handle, $e->getMessage());
            }
        }

        return t('Created file for %s, but automatic registration is not available on this Concrete install. Add it manually in Dashboard → Pages & Themes → Containers.', $handle);
    }
}
