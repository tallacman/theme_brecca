<?php
namespace Concrete\Package\TallacmansContainerMaker\Service;

use Concrete\Core\Entity\Page\Container;
use Concrete\Core\Page\Theme\Theme;

class ContainerManager
{
    /**
     * Return every registered Concrete container, plus whether a matching PHP template
     * exists in the selected theme, application override, or core.
     */
    public function getRegisteredContainersForTheme(Theme $theme)
    {
        $rows = [];
        $containers = $this->getRegisteredContainers();
        $themePath = $this->getThemePath($theme);

        foreach ($containers as $container) {
            $handle = $this->read($container, 'getContainerHandle', 'containerHandle');
            if (!$handle) {
                continue;
            }

            $paths = $this->getTemplateCandidates($handle, $theme, $themePath);
            $found = null;
            foreach ($paths as $path) {
                if (is_file($path)) {
                    $found = $path;
                    break;
                }
            }

            $package = null;
            if (method_exists($container, 'getPackage')) {
                $pkg = $container->getPackage();
                if (is_object($pkg) && method_exists($pkg, 'getPackageHandle')) {
                    $package = $pkg->getPackageHandle();
                }
            }

            $rows[] = [
                'id' => $this->read($container, 'getContainerID', 'containerID'),
                'name' => $this->read($container, 'getContainerName', 'containerName') ?: $handle,
                'handle' => $handle,
                'icon' => $this->read($container, 'getContainerIcon', 'containerIcon'),
                'package' => $package,
                'has_template' => (bool) $found,
                'template_path' => $found,
                'searched_paths' => $paths,
                'is_core_or_package' => $package !== null,
                'editor_data' => $found ? $this->getEditorData($found, $handle, $this->read($container, 'getContainerName', 'containerName') ?: $handle) : null,
            ];
        }

        usort($rows, static function ($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });

        return $rows;
    }

    public function uninstallByHandle($handle)
    {
        $handle = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $handle);
        if ($handle === '') {
            return t('Invalid container handle.');
        }

        $em = $this->entityManager();
        $repo = $em->getRepository(Container::class);
        $container = method_exists($repo, 'findOneByContainerHandle')
            ? $repo->findOneByContainerHandle($handle)
            : $repo->findOneBy(['containerHandle' => $handle]);

        if (!$container) {
            return t('Container %s is not registered.', $handle);
        }

        // Prefer Concrete's command layer when it is available.
        if (class_exists('\\Concrete\\Core\\Page\\Container\\Command\\DeleteContainerCommand')) {
            try {
                $commandClass = '\\Concrete\\Core\\Page\\Container\\Command\\DeleteContainerCommand';
                $command = new $commandClass($container);
                $app = \Core::make('app');
                if (method_exists($app, 'executeCommand')) {
                    $app->executeCommand($command);
                    return true;
                }
            } catch (\Throwable $e) {
                // Fall through to entity removal below.
            }
        }

        try {
            $em->remove($container);
            $em->flush();
            return true;
        } catch (\Throwable $e) {
            return t('Could not uninstall %s: %s', $handle, $e->getMessage());
        }
    }

    protected function getEditorData($path, $handle, $name)
    {
        $php = @file_get_contents($path);
        if (!is_string($php) || $php === '') {
            return null;
        }

        $areas = $this->extractArrayAssignment($php, 'areas');
        if (empty($areas) || !is_array($areas)) {
            $areas = $this->extractContainerAreaNames($php);
        }
        if (empty($areas)) {
            return null;
        }

        $responsiveColumns = $this->extractArrayAssignment($php, 'responsiveColumns');
        $fullRows = $this->extractArrayAssignment($php, 'areaFullRows');
        $nestedAreas = $this->extractArrayAssignment($php, 'nestedAreas');
        $areaClasses = $this->extractArrayAssignment($php, 'areaClasses');
        if (!is_array($areaClasses)) {
            $areaClasses = $this->extractExplicitAreaClasses($php);
        }
        $mode = is_array($areaClasses) ? 'grid12' : $this->detectLayoutMode($php);
        $inner = $this->detectInnerWrapper($php);
        $designerAreas = [];

        foreach (array_values($areas) as $areaName) {
            $areaName = (string) $areaName;
            $columns = is_array($responsiveColumns) && isset($responsiveColumns[$areaName]) && is_array($responsiveColumns[$areaName])
                ? $responsiveColumns[$areaName]
                : [];
            if (is_array($areaClasses) && isset($areaClasses[$areaName])) {
                $columns = is_array($areaClasses[$areaName])
                    ? $areaClasses[$areaName]
                    : $this->columnsFromLayoutClasses((string) $areaClasses[$areaName]);
            }

            $designerAreas[] = [
                'name' => $areaName,
                'desktop' => max(1, min(12, (int) ($columns['desktop'] ?? 12))),
                'tablet' => max(1, min(12, (int) ($columns['tablet'] ?? 12))),
                'mobile' => max(1, min(12, (int) ($columns['mobile'] ?? 12))),
                'full' => is_array($fullRows) && in_array($areaName, $fullRows, true),
                'nested' => !is_array($nestedAreas) || in_array($areaName, $nestedAreas, true),
                'category' => 'General',
                'version' => '1.0.0',
            ];
        }

        return [
            'name' => $name,
            'handle' => $handle,
            'mode' => $mode,
            'inner' => $inner,
            'areas' => $designerAreas,
        ];
    }

    protected function extractArrayAssignment($php, $variable)
    {
        if (!preg_match('/\\$' . preg_quote($variable, '/') . '\\s*=\\s*(array\\s*\\(.*?^\\);)/ms', $php, $match)) {
            return null;
        }

        try {
            $value = eval('return ' . $match[1]);
            return is_array($value) ? $value : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function extractContainerAreaNames($php)
    {
        preg_match_all('/new\\s+ContainerArea\\s*\\(\\s*\\$container\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/i', $php, $matches);
        return array_values(array_unique($matches[1] ?? []));
    }

    protected function extractExplicitAreaClasses($php)
    {
        $classes = [];
        preg_match_all('/<div\\s+class="([^"]*(?:\\bcol(?:-[a-z]+)?-\\d{1,2}|\\b(?:md:|lg:)?col-span-\\d{1,2}|\\b(?:small|medium|large)-\\d{1,2})[^"]*)"\\s*>\\s*<\\?php\\s*\\$area\\s*=\\s*new\\s+ContainerArea\\s*\\(\\s*\\$container\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/is', $php, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $classes[$match[2]] = $match[1];
        }
        return $classes;
    }

    protected function columnsFromLayoutClasses($classes)
    {
        if (strpos($classes, 'col-span-') !== false) {
            return $this->columnsFromTailwindClasses($classes);
        }
        if (preg_match('/(?:^|\\s)(?:small|medium|large)-\\d{1,2}(?:\\s|$)/', $classes)) {
            return $this->columnsFromFoundationClasses($classes);
        }
        return $this->columnsFromBootstrapClasses($classes);
    }

    protected function columnsFromBootstrapClasses($classes)
    {
        $mobile = $this->matchColumnClass($classes, 'col') ?: 12;
        $tablet = $this->matchColumnClass($classes, 'col-md') ?: $mobile;
        $desktop = $this->matchColumnClass($classes, 'col-lg') ?: $tablet;

        return [
            'desktop' => $desktop,
            'tablet' => $tablet,
            'mobile' => $mobile,
        ];
    }

    protected function columnsFromTailwindClasses($classes)
    {
        $mobile = $this->matchColumnClass($classes, 'col-span') ?: 12;
        $tablet = $this->matchColumnClass($classes, 'md:col-span') ?: $mobile;
        $desktop = $this->matchColumnClass($classes, 'lg:col-span') ?: $tablet;

        return [
            'desktop' => $desktop,
            'tablet' => $tablet,
            'mobile' => $mobile,
        ];
    }

    protected function columnsFromFoundationClasses($classes)
    {
        $mobile = $this->matchColumnClass($classes, 'small') ?: 12;
        $tablet = $this->matchColumnClass($classes, 'medium') ?: $mobile;
        $desktop = $this->matchColumnClass($classes, 'large') ?: $tablet;

        return [
            'desktop' => $desktop,
            'tablet' => $tablet,
            'mobile' => $mobile,
        ];
    }

    protected function matchColumnClass($classes, $prefix)
    {
        return preg_match('/(?:^|\\s)' . preg_quote($prefix, '/') . '-(\\d{1,2})(?:\\s|$)/', $classes, $match)
            ? max(1, min(12, (int) $match[1]))
            : null;
    }

    protected function detectLayoutMode($php)
    {
        if (strpos($php, '--cm-container-display: grid') !== false) {
            return 'css_grid';
        }
        if (strpos($php, '--cm-container-display: block') !== false) {
            return 'plain';
        }
        return 'flex';
    }

    protected function detectInnerWrapper($php)
    {
        if (preg_match('/<div\\s+class="(container(?:-fluid)?)"/', $php, $match)) {
            return $match[1];
        }
        return 'container';
    }

    protected function getRegisteredContainers()
    {
        if (!class_exists(Container::class)) {
            return [];
        }
        return $this->entityManager()->getRepository(Container::class)->findAll();
    }

    protected function entityManager()
    {
        $app = \Core::make('app');
        if ($app->bound('database/orm')) {
            return $app->make('database/orm')->entityManager();
        }
        return \Database::connection()->getEntityManager();
    }

    protected function getTemplateCandidates($handle, Theme $theme, $themePath = null)
    {
        $paths = [];
        $file = 'elements' . DIRECTORY_SEPARATOR . 'containers' . DIRECTORY_SEPARATOR . $handle . '.php';

        if ($themePath) {
            $paths[] = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $file;
        }

        $themeHandle = $theme->getThemeHandle();
        $paths[] = DIR_BASE . '/application/themes/' . $themeHandle . '/' . str_replace(DIRECTORY_SEPARATOR, '/', $file);
        $paths[] = DIR_BASE . '/themes/' . $themeHandle . '/' . str_replace(DIRECTORY_SEPARATOR, '/', $file);
        $paths[] = DIR_BASE_CORE . '/themes/' . $themeHandle . '/' . str_replace(DIRECTORY_SEPARATOR, '/', $file);
        $paths[] = DIR_BASE . '/application/elements/containers/' . $handle . '.php';
        $paths[] = DIR_BASE_CORE . '/elements/containers/' . $handle . '.php';

        return array_values(array_unique($paths));
    }

    protected function getThemePath(Theme $theme)
    {
        if (method_exists($theme, 'getThemeDirectory')) {
            $dir = $theme->getThemeDirectory();
            if ($dir && is_dir($dir)) {
                return $dir;
            }
        }

        $handle = $theme->getThemeHandle();
        foreach ([
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ] as $path) {
            if (is_dir($path)) {
                return $path;
            }
        }
        return null;
    }

    protected function read($object, $method, $property)
    {
        if (is_object($object) && method_exists($object, $method)) {
            return $object->{$method}();
        }
        if (is_object($object) && property_exists($object, $property)) {
            return $object->{$property};
        }
        return null;
    }
}
