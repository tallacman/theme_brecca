<?php
namespace Concrete\Package\TallacmansContainerMaker;

use Concrete\Core\Package\Package;
use Concrete\Core\Page\Single as SinglePage;

class Controller extends Package
{
    protected $pkgHandle = 'tallacmans_container_maker';
    protected $appVersionRequired = '9.0.0';
    protected $pkgVersion = '0.8.5';
    protected $pkgAutoloaderRegistries = [
        'src/Service' => '\\Concrete\\Package\\TallacmansContainerMaker\\Service',
    ];

    public function getPackageName()
    {
        return t('Tallacmans Container Maker');
    }

    public function getPackageDescription()
    {
        return t('Generate and manage Concrete CMS container template files for installed themes, including a visual responsive CSS Grid container designer with presets, import/export, responsive breakpoints, and library-management helpers.');
    }

    public function install()
    {
        $pkg = parent::install();
        $this->installSinglePage($pkg, '/dashboard/pages/tallacmans_container_maker', t('Tallacmans Container Maker'));
        return $pkg;
    }

    protected function installSinglePage($pkg, $path, $name)
    {
        $page = SinglePage::add($path, $pkg);
        if (is_object($page) && !$page->isError()) {
            $page->update(['cName' => $name]);
        }
    }
}
