# Tallacmans Container Maker for Concrete CMS

Version: 0.8.5

Tallacmans Container Maker adds a dashboard tool at **Dashboard → Pages & Themes → Tallacmans Container Maker** for generating Concrete CMS container PHP files for installed themes.

## New in 0.8.5

- The visual designer now focuses on browser-native CSS Grid output only.
- Removed Flexbox, plain stacked, and framework-specific 12-column output choices from the builder UI.
- Generated containers are self-contained CSS Grid templates that do not depend on Bootstrap, Tailwind, Foundation, or theme framework classes.

## New in 0.8.4

- New containers start with a blank name and inherit the PHP filename handle from the typed container name.
- Parseable installed containers can be loaded into the visual designer, edited, and re-saved to their original PHP filename.
- The visual canvas help text now reflects the selected layout mode, and the old code preview panel has been removed.

See [CHANGELOG.md](CHANGELOG.md) for the full release history.

## New in 0.8.3

- 12-column grid mode now generates Atomic-style Bootstrap markup with `.container`, `.row`, and responsive `col-*` classes.
- Installed container management now correctly reports whether the matching PHP template file exists.
- Removing an installed container registration now returns to the Manage Installed Containers tab.

## New in 0.8.0

- Visual designer canvas
- Drag/drop area ordering
- Resizable preview width
- Responsive breakpoints: desktop, tablet, mobile
- Native CSS Grid output
- Per-area desktop/tablet/mobile spans
- Full-row areas
- Nested-friendly areas
- Live generated PHP/CSS code preview
- Save as browser preset
- Import/export JSON presets
- Local container library manager with search, load, duplicate, and delete

## Install

1. Unzip this package.
2. Put the `tallacmans_container_maker` folder into your Concrete CMS `packages/` directory.
3. Go to **Dashboard → Extend Concrete**.
4. Install **Tallacmans Container Maker**.
5. Open **Dashboard → Pages & Themes → Tallacmans Container Maker**.

## Upgrade

Replace the older `packages/tallacmans_container_maker` folder with this one, then visit **Dashboard → Extend Concrete** if Concrete offers an update.

## Important notes

- The visual library/preset manager stores presets in the browser using `localStorage`.
- Export JSON if you want to move presets between browsers or projects.
- Generated container PHP files are written into the selected theme’s `elements/containers/` directory.
- Existing files are not overwritten unless **Overwrite existing PHP file** is checked.
- Auto-registration is defensive because Concrete CMS container internals vary by version. If registration fails, the PHP file is still created and you can register it manually.
- Uninstalling a container removes its registration only. It does not delete the PHP template file.

## Suggested workflow

1. Pick your installed theme.
2. Name the container.
3. Add areas on the canvas.
4. Set each area’s desktop/tablet/mobile span.
5. Preview the wrap behavior by dragging the preview width.
6. Save as a preset if you want to reuse it.
7. Save the container PHP file.
