<?php
namespace Concrete\Package\TallacmansContainerMaker\Controller\SinglePage\Dashboard\Pages;

use Concrete\Core\Page\Controller\DashboardPageController;
use Concrete\Core\Page\Theme\Theme as PageTheme;
use Concrete\Package\TallacmansContainerMaker\Service\ContainerGenerator;
use Concrete\Package\TallacmansContainerMaker\Service\ContainerManager;

class TallacmansContainerMaker extends DashboardPageController
{
    public function view()
    {
        $themes = $this->getInstalledThemes();
        $activeTheme = $this->getActiveTheme();
        $selectedThemeID = $activeTheme ? (int) $activeTheme->getThemeID() : 0;

        $selectedTheme = $selectedThemeID ? PageTheme::getByID($selectedThemeID) : null;
        $registeredContainers = [];
        if (is_object($selectedTheme) && $selectedTheme->getThemeID()) {
            $manager = $this->app->make(ContainerManager::class);
            $registeredContainers = $manager->getRegisteredContainersForTheme($selectedTheme);
        }

        $this->set('themes', $themes);
        $this->set('activeTheme', $activeTheme);
        $this->set('selectedThemeID', $selectedThemeID);
        $this->set('registeredContainers', $registeredContainers);
        $this->set('presets', ContainerGenerator::getPresets());
    }

    public function generate()
    {
        if (!$this->token->validate('tallacmans_container_maker_generate')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $theme = $this->getActiveTheme();
        if (!is_object($theme) || !$theme->getThemeID()) {
            $this->error->add(t('No active theme is available for container generation.'));
            return $this->view();
        }

        $presetHandles = (array) $this->request->request->all('presets');
        $register = (bool) $this->request->request->get('register');
        if (empty($presetHandles)) {
            $this->error->add(t('Please choose at least one container preset.'));
            return $this->view();
        }

        $generator = $this->app->make(ContainerGenerator::class);
        $result = $generator->generate($theme, $presetHandles, $register);

        foreach ($result['created'] as $item) {
            $this->flash('success', t('Created %s', $item));
        }
        foreach ($result['registered'] as $item) {
            $this->flash('success', t('Registered %s', $item));
        }
        foreach ($result['skipped'] as $item) {
            $this->flash('info', t('Skipped existing file %s', $item));
        }
        foreach ($result['errors'] as $item) {
            $this->error->add($item);
        }

        return $this->redirect('/dashboard/pages/tallacmans_container_maker');
    }


    public function build_flex()
    {
        if (!$this->token->validate('tallacmans_container_maker_build_flex')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $theme = $this->getActiveTheme();
        if (!is_object($theme) || !$theme->getThemeID()) {
            $this->error->add(t('No active theme is available for container generation.'));
            return $this->view();
        }

        $data = $this->request->request->all();
        $editingHandle = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) ($data['editing_handle'] ?? ''));
        if ($editingHandle !== '') {
            $data['handle'] = $editingHandle;
            $data['overwrite'] = 1;
        }
        $generator = $this->app->make(ContainerGenerator::class);
        $result = $generator->generateFlex($theme, $data);

        foreach ($result['created'] as $item) {
            $this->flash('success', t('Created CSS Grid container file: %s', $item));
        }
        foreach ($result['registered'] as $item) {
            $this->flash('success', t('Registered %s', $item));
        }
        foreach ($result['skipped'] as $item) {
            $this->flash('info', t('Skipped existing file %s. Check overwrite if you want to replace it.', $item));
        }
        foreach ($result['errors'] as $item) {
            $this->error->add($item);
        }

        return $this->buildRedirect('/dashboard/pages/tallacmans_container_maker?themeID=' . ($theme ? $theme->getThemeID() : 0));
    }


    public function uninstall()
    {
        if (!$this->token->validate('tallacmans_container_maker_uninstall')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $theme = $this->getActiveTheme();
        $handle = (string) $this->request->request->get('containerHandle');
        $confirm = (bool) $this->request->request->get('confirm');

        if (!$confirm) {
            $this->error->add(t('Please check the confirmation box before uninstalling a container.'));
            return $this->buildRedirect($this->getManageRedirectPath($theme));
        }

        $manager = $this->app->make(ContainerManager::class);
        $result = $manager->uninstallByHandle($handle);
        if ($result === true) {
            $this->flash('success', t('Uninstalled container registration: %s', $handle));
        } else {
            $this->error->add($result);
        }

        return $this->buildRedirect($this->getManageRedirectPath($theme));
    }

    protected function getManageRedirectPath($theme)
    {
        return '/dashboard/pages/tallacmans_container_maker?themeID=' . ($theme ? $theme->getThemeID() : 0) . '#cm-manage';
    }


    protected function getActiveTheme()
    {
        $theme = PageTheme::getSiteTheme();
        if (is_object($theme) && $theme->getThemeID()) {
            return $theme;
        }

        $themes = $this->getInstalledThemes();
        return isset($themes[0]) ? $themes[0] : null;
    }

    protected function getInstalledThemes()
    {
        $themes = [];
        foreach (PageTheme::getList() as $theme) {
            if (is_object($theme) && $theme->getThemeID()) {
                $themes[] = $theme;
            }
        }
        return $themes;
    }
}
