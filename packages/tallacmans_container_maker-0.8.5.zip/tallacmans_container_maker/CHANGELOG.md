# Changelog

## 0.8.5

- Focused the visual designer on browser-native CSS Grid output only.
- Removed Flexbox, plain stacked, and framework-specific 12-column output choices from the builder UI.
- Generated containers now use self-contained CSS Grid templates instead of Bootstrap, Tailwind, Foundation, or Flexbox layout output.

## 0.8.4

- New containers now start with a blank name and inherit the PHP filename handle from the typed container name.
- Added editing support for parseable existing container templates from Manage Installed Containers.
- Updated the visual canvas help text for each layout mode and removed the code preview panel.

## 0.8.3

- Changed 12-column grid container generation to use Atomic-style Bootstrap markup with `.container`, `.row`, and responsive `col-*` classes.
- Fixed installed container template status so existing template files show as `Exists` instead of `Missing`.
- Kept the dashboard on the Manage Installed Containers tab after uninstalling a container registration.

## 0.8.2

- Fixed preview canvas dragging so areas are clamped inside the preview instead of pulling outside the viewport.
- Preview tiles use pointer-based dragging; inspector rows still use simple drag/drop ordering.
- Added safer canvas overflow handling for the resizable preview.
- Area Settings controls no longer drag the whole settings card.
- Drag ordering now uses a dedicated drag handle.
- Delete asks for confirmation and has Restore Deleted recovery.
- Added desktop, tablet, and mobile live canvas previews.

## 0.8.0

- Added a visual designer canvas.
- Added drag/drop area ordering.
- Added resizable preview width.
- Added responsive breakpoints for desktop, tablet, and mobile.
- Added 12-column grid mode with automatic wrapping.
- Added native CSS Grid mode.
- Added Flexbox mode and plain stacked mode.
- Added per-area desktop/tablet/mobile spans.
- Added full-row areas.
- Added nested-friendly areas.
- Added live generated PHP/CSS code preview.
- Added browser preset saving.
- Added JSON preset import/export.
- Added local container library manager with search, load, duplicate, and delete.
- Added basic theme framework detection for Bootstrap, Tailwind, Foundation, or custom themes.
