<?php
namespace Concrete\Package\ContainerMaker\Service;

use Concrete\Core\Page\Theme\Theme;

class ContainerGenerator
{
    public function readDesignerState($filePath)
    {
        if (!$filePath || !is_file($filePath)) {
            return null;
        }
        $contents = @file_get_contents($filePath);
        if ($contents === false) {
            return null;
        }
        if (!preg_match('/CM_DESIGNER_STATE\s+([A-Za-z0-9+\/=]+)\s+CM_DESIGNER_STATE_END/', $contents, $m)) {
            return null;
        }
        $json = base64_decode($m[1], true);
        if ($json === false) {
            return null;
        }
        $data = json_decode($json, true);
        return is_array($data) ? $data : null;
    }

    /** @deprecated Use generate() */
    public function generateFlex(Theme $theme, array $data)
    {
        return $this->generate($theme, $data);
    }

    public function generate(Theme $theme, array $data)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $themePath = $this->getThemePath($theme);
        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $name = trim((string) ($data['name'] ?? ''));
        $handle = $this->sanitizeHandle((string) ($data['handle'] ?? ''));
        if ($name === '') {
            $name = t('Grid Container');
        }
        if ($handle === '') {
            $handle = $this->sanitizeHandle($name);
        }
        if ($handle === '') {
            $result['errors'][] = t('Please enter a valid container handle.');
            return $result;
        }

        $areas = $this->parseAreaNames((string) ($data['areas'] ?? 'Main'));
        if (empty($areas)) {
            $result['errors'][] = t('Please add at least one area.');
            return $result;
        }

        $responsiveColumns = $this->parseResponsiveColumns((string) ($data['responsive_columns'] ?? ''), $areas);
        $areaResponsive = $this->parseAreaResponsive((string) ($data['area_responsive'] ?? ''), $areas);
        $areaPlacement = $this->parseAreaPlacement((string) ($data['area_placement'] ?? ''), $areas);
        $areaFullRows = $this->parseAreaFullRows((string) ($data['area_full_rows'] ?? ''), $areas);
        $nestedAreas = $this->parseAreaFullRows((string) ($data['nested_areas'] ?? ''), $areas);
        $areaPadding = $this->parseAreaPadding((string) ($data['area_padding'] ?? ''), $areas);
        $settings = $this->normalizeSettings($data);

        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
        $overwrite = !empty($data['overwrite']);
        if (file_exists($file) && !$overwrite) {
            $result['skipped'][] = $file;
        } else {
            $php = $this->buildContainerPhp($handle, $name, $areas, $settings, $areaFullRows, $responsiveColumns, $nestedAreas, $areaPadding, $areaPlacement, $areaResponsive);
            if (@file_put_contents($file, $php) === false) {
                $result['errors'][] = t('Could not write file: %s', $file);
                return $result;
            }
            $result['created'][] = $file;
        }

        if (!empty($data['register'])) {
            $registered = $this->tryRegisterContainer($handle, $name);
            if ($registered === true) {
                $result['registered'][] = $name . ' (' . $handle . ')';
            } elseif (is_string($registered)) {
                $result['errors'][] = $registered;
            }
        }

        return $result;
    }

    protected function buildContainerPhp($handle, $name, array $areas, array $settings, array $areaFullRows, array $responsiveColumns, array $nestedAreas, array $areaPadding, array $areaPlacement = [], array $areaResponsive = [])
    {
        $class = 'cm-' . str_replace('_', '-', $handle);
        $inner = $settings['inner'];

        $designerState = base64_encode(json_encode([
            'name' => $name,
            'handle' => $handle,
            'layout_mode' => 'css_grid',
            'theme_id' => (int) ($settings['theme_id'] ?? 0),
            'settings' => [
                'gap' => $settings['gap'],
                'inner' => $settings['inner'],
                'grid_columns' => $settings['grid_columns'],
                'grid_rows' => $settings['grid_rows'],
                'grid_tracks' => $settings['grid_tracks'],
                'row_size' => $settings['row_size'],
                'tablet_columns' => $settings['tablet_columns'],
                'mobile_columns' => $settings['mobile_columns'],
            ],
            'areas' => array_map(static function ($areaName) use ($responsiveColumns, $areaFullRows, $areaPadding, $areaPlacement, $nestedAreas, $areaResponsive) {
                $placement = $areaPlacement[$areaName] ?? [];
                $responsiveMeta = $areaResponsive[$areaName] ?? [];
                return [
                    'name' => $areaName,
                    'col' => (int) ($placement['col'] ?? 1),
                    'row' => (int) ($placement['row'] ?? 1),
                    'row_span' => (int) ($placement['row_span'] ?? 1),
                    'grid_column' => $placement['grid_column'] ?? '',
                    'grid_row' => $placement['grid_row'] ?? '',
                    'min_height' => $placement['min_height'] ?? '',
                    'desktop' => (int) ($responsiveColumns[$areaName]['desktop'] ?? ($placement['span'] ?? 12)),
                    'tablet' => (int) ($responsiveColumns[$areaName]['tablet'] ?? ($placement['span'] ?? 12)),
                    'mobile' => (int) ($responsiveColumns[$areaName]['mobile'] ?? ($placement['span'] ?? 12)),
                    'tablet_span' => $responsiveMeta['tablet_span'] ?? null,
                    'mobile_span' => $responsiveMeta['mobile_span'] ?? null,
                    'mobile_stack' => $responsiveMeta['mobile_stack'] ?? true,
                    'tablet_col' => $responsiveMeta['tablet_col'] ?? null,
                    'mobile_col' => $responsiveMeta['mobile_col'] ?? null,
                    'tablet_row' => $responsiveMeta['tablet_row'] ?? null,
                    'mobile_row' => $responsiveMeta['mobile_row'] ?? null,
                    'full' => in_array($areaName, $areaFullRows, true),
                    'nested' => in_array($areaName, $nestedAreas, true),
                    'padding' => $areaPadding[$areaName] ?? '',
                ];
            }, $areas),
        ]));

        [$body, $css] = $this->buildCssGridMarkup($class, $inner, $areas, $areaFullRows, $responsiveColumns, $settings, $areaPadding, $areaPlacement, $areaResponsive);
        $headerPhp = $this->buildHeaderStyleInjection($class, $css);

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

/* CM_DESIGNER_STATE {$designerState} CM_DESIGNER_STATE_END */

use Concrete\Core\Area\ContainerArea;
{$headerPhp}?>
{$body}

PHP;
    }

    protected function buildHeaderStyleInjection($class, $css)
    {
        $classExport = var_export($class, true);
        $cssExport = var_export($css, true);

        return <<<PHP

\$cmContainerClass = {$classExport};
\$cmContainerCss = {$cssExport};
if (!isset(\$GLOBALS['cm_container_styles_added'])) {
    \$GLOBALS['cm_container_styles_added'] = [];
}
if (!in_array(\$cmContainerClass, \$GLOBALS['cm_container_styles_added'], true)) {
    \\Concrete\\Core\\View\\View::getInstance()->addHeaderItem('<style>' . \$cmContainerCss . '</style>');
    \$GLOBALS['cm_container_styles_added'][] = \$cmContainerClass;
}

PHP;

    }

    protected function areaPhpBlock($areaName)
    {
        $escapedName = addslashes($areaName);

        return "<?php\n"
            . '$area = new ContainerArea($container, \'' . $escapedName . "');\n"
            . "\$area->display(\$c);\n"
            . '?>';
    }

    protected function indentLines($text, $spaces)
    {
        $prefix = str_repeat(' ', $spaces);

        return $prefix . str_replace("\n", "\n" . $prefix, rtrim((string) $text));
    }

    protected function wrapInner($inner, $content)
    {
        if ($inner === '') {
            return $content;
        }

        return '<div class="' . $inner . "\">\n" . $this->indentLines($content, 4) . "\n</div>";
    }

    protected function buildCssRules($class, array $rules, $mediaExtra = '')
    {
        $lines = $rules;
        $lines[] = '.ccm-edit-mode .' . $class . ' .ccm-area { min-height: 48px; outline: 1px dashed rgba(0, 0, 0, .25); outline-offset: -1px; }';
        $css = implode("\n", $lines);
        if ($mediaExtra !== '') {
            $css .= "\n" . rtrim($mediaExtra);
        }

        return $css;
    }

    protected function buildCssGridMarkup($class, $inner, array $areas, array $areaFullRows, array $responsiveColumns, array $settings, array $areaPadding = [], array $areaPlacement = [], array $areaResponsive = [])
    {
        $items = [];
        $desktopRules = [];
        $tabletRules = [];
        $mobileRules = [];
        $maxRow = 1;
        $trackCount = !empty($settings['grid_tracks']) ? count($settings['grid_tracks']) : max(1, substr_count($settings['grid_columns'], ' ') + 1);
        $i = 0;
        foreach ($areas as $areaName) {
            $i++;
            $placement = $areaPlacement[$areaName] ?? ['col' => 1, 'span' => 12, 'row' => 1];
            $row = max(1, (int) ($placement['row'] ?? 1));
            $maxRow = max($maxRow, $row);
            $items[] = '<div class="' . $class . "__item\">\n" . $this->indentLines($this->areaPhpBlock($areaName), 4) . "\n</div>";
            $selector = '.' . $class . '__grid > *:nth-child(' . $i . ')';
            $ruleParts = $this->buildAreaPlacementCss($areaName, $placement, $areaFullRows, $responsiveColumns);
            if (!in_array($areaName, $areaFullRows, true) && empty($placement['grid_column'])) {
                $col = max(1, (int) ($placement['col'] ?? 1));
                $desktop = (int) ($responsiveColumns[$areaName]['desktop'] ?? ($placement['span'] ?? 12));
                $tablet = (int) ($responsiveColumns[$areaName]['tablet'] ?? $desktop);
                $mobile = (int) ($responsiveColumns[$areaName]['mobile'] ?? $tablet);
                $desktop = max(1, $desktop);
                $meta = $areaResponsive[$areaName] ?? [];
                $mobileStack = !isset($meta['mobile_stack']) || $meta['mobile_stack'];
                $tabletCol = !empty($meta['tablet_col']) ? max(1, (int) $meta['tablet_col']) : $col;
                $mobileCol = !empty($meta['mobile_col']) ? max(1, (int) $meta['mobile_col']) : 1;
                $row = max(1, (int) ($placement['row'] ?? 1));
                $rowSpan = max(1, (int) ($placement['row_span'] ?? 1));
                $tabletRow = !empty($meta['tablet_row']) ? max(1, (int) $meta['tablet_row']) : $row;
                $mobileRow = !empty($meta['mobile_row']) ? max(1, (int) $meta['mobile_row']) : $row;
                if ($tablet !== $desktop || $tabletCol !== $col || $tabletRow !== $row) {
                    $rule = $tablet >= $trackCount
                        ? $selector . ' { grid-column: 1 / -1;'
                        : $selector . ' { grid-column: ' . $tabletCol . ' / span ' . max(1, $tablet) . ';';
                    if ($tabletRow !== $row || $rowSpan > 1) {
                        $rule .= ' grid-row: ' . $this->viewportRowCss($tabletRow, $rowSpan) . ';';
                    }
                    $tabletRules[] = $rule . ' }';
                }
                if ($mobile !== $tablet || $mobile !== $desktop || $mobileStack || $mobileCol !== 1 || $mobileRow !== $row) {
                    if ($mobileStack && empty($meta['mobile_span'])) {
                        $mobileRules[] = $selector . ' { grid-column: 1 / -1; grid-row: ' . $this->viewportRowCss($mobileRow, $rowSpan) . '; }';
                    } elseif ($mobile >= $trackCount) {
                        $mobileRules[] = $selector . ' { grid-column: 1 / -1; grid-row: ' . $this->viewportRowCss($mobileRow, $rowSpan) . '; }';
                    } else {
                        $rule = $selector . ' { grid-column: ' . $mobileCol . ' / span ' . max(1, $mobile) . ';';
                        if ($mobileRow !== $row || $rowSpan > 1) {
                            $rule .= ' grid-row: ' . $this->viewportRowCss($mobileRow, $rowSpan) . ';';
                        }
                        $mobileRules[] = $rule . ' }';
                    }
                }
            }
            if (!empty($areaPadding[$areaName])) {
                $ruleParts[] = 'padding: ' . $areaPadding[$areaName];
            }
            $desktopRules[] = $selector . ' { ' . implode('; ', $ruleParts) . '; }';
        }
        $itemsHtml = $this->indentLines(implode("\n", $items), 4);
        $grid = '<div class="' . $class . "__grid\">\n{$itemsHtml}\n</div>";

        $content = $this->indentLines($this->wrapInner($inner, $grid), 4);
        $body = '<div class="' . $class . "\">\n{$content}\n</div>";

        $rules = array_merge(
            [
                '.' . $class . '__grid { display: grid; grid-template-columns: ' . $settings['grid_columns'] . '; grid-auto-rows: ' . $settings['grid_rows'] . '; gap: ' . $settings['gap'] . '; }',
            ],
            $desktopRules
        );
        $tabletColumns = trim((string) ($settings['tablet_columns'] ?? ''));
        $mobileColumns = trim((string) ($settings['mobile_columns'] ?? ''));
        $media = '';
        if (!empty($tabletRules) || $tabletColumns !== '') {
            $tabletBlock = [];
            if ($tabletColumns !== '') {
                $tabletBlock[] = '.' . $class . '__grid { grid-template-columns: ' . $tabletColumns . '; }';
            }
            $tabletBlock = array_merge($tabletBlock, $tabletRules);
            $media .= "@media (max-width: 991px) {\n    " . implode("\n    ", $tabletBlock) . "\n}\n";
        }
        if (!empty($mobileRules) || $mobileColumns !== '') {
            $mobileBlock = [];
            if ($mobileColumns !== '') {
                $mobileBlock[] = '.' . $class . '__grid { grid-template-columns: ' . $mobileColumns . '; }';
            }
            $mobileBlock = array_merge($mobileBlock, $mobileRules);
            $media .= "@media (max-width: 767px) {\n    " . implode("\n    ", $mobileBlock) . "\n}\n";
        }
        $css = $this->buildCssRules($class, $rules, $media);

        return [$body, $css];
    }

    protected function parseAreaNames($input)
    {
        $parts = preg_split('/[\r\n,]+/', $input);
        $areas = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $areas[] = $part;
            }
        }
        return array_values(array_unique($areas));
    }

    protected function buildAreaPlacementCss($areaName, array $placement, array $areaFullRows, array $responsiveColumns)
    {
        $rules = [];
        if (in_array($areaName, $areaFullRows, true)) {
            $rules[] = 'grid-column: 1 / -1';
        } elseif (!empty($placement['grid_column'])) {
            $rules[] = 'grid-column: ' . $placement['grid_column'];
        } else {
            $col = max(1, (int) ($placement['col'] ?? 1));
            $span = max(1, (int) ($placement['span'] ?? ($responsiveColumns[$areaName]['desktop'] ?? 12)));
            $rules[] = 'grid-column: ' . $col . ' / span ' . $span;
        }

        if (!empty($placement['grid_row'])) {
            $rules[] = 'grid-row: ' . $placement['grid_row'];
        } else {
            $row = max(1, (int) ($placement['row'] ?? 1));
            $rowSpan = max(1, (int) ($placement['row_span'] ?? 1));
            $rules[] = $rowSpan > 1 ? ('grid-row: ' . $row . ' / span ' . $rowSpan) : ('grid-row: ' . $row);
        }

        if (!empty($placement['min_height'])) {
            $rules[] = 'min-height: ' . $placement['min_height'];
        }

        return $rules;
    }

    protected function parseAreaPlacement($input, array $areas)
    {
        $placement = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_pad(explode('|', $value), 7, '');
            $placement[$area] = [
                'col' => max(1, (int) $parts[0]),
                'span' => max(1, (int) $parts[1]),
                'row' => max(1, (int) $parts[2]),
                'row_span' => max(1, (int) ($parts[3] !== '' ? $parts[3] : 1)),
                'grid_column' => $this->safeGridPlacement($parts[4] ?? ''),
                'grid_row' => $this->safeGridPlacement($parts[5] ?? ''),
                'min_height' => $this->safeCssSize($parts[6] ?? ''),
            ];
        }

        return $placement;
    }

    protected function parseResponsiveColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_map('intval', array_pad(explode('|', $value), 3, 12));
            $columns[$area] = [
                'desktop' => max(1, $parts[0]),
                'tablet' => max(1, $parts[1]),
                'mobile' => max(1, $parts[2]),
            ];
        }
        return $columns;
    }

    protected function parseAreaResponsive($input, array $areas)
    {
        $responsive = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_pad(explode('|', $value), 7, '');
            $responsive[$area] = [
                'tablet_span' => $parts[0] !== '' ? max(1, (int) $parts[0]) : null,
                'mobile_span' => $parts[1] !== '' ? max(1, (int) $parts[1]) : null,
                'mobile_stack' => ($parts[2] ?? '1') !== '0',
                'tablet_col' => $parts[3] !== '' ? max(1, (int) $parts[3]) : null,
                'mobile_col' => $parts[4] !== '' ? max(1, (int) $parts[4]) : null,
                'tablet_row' => $parts[5] !== '' ? max(1, (int) $parts[5]) : null,
                'mobile_row' => $parts[6] !== '' ? max(1, (int) $parts[6]) : null,
            ];
        }

        return $responsive;
    }

    protected function viewportRowCss($row, $rowSpan)
    {
        $row = max(1, (int) $row);
        $rowSpan = max(1, (int) $rowSpan);

        return $rowSpan > 1 ? ($row . ' / span ' . $rowSpan) : (string) $row;
    }

    protected function parseAreaFullRows($input, array $areas)
    {
        $fullRows = [];
        $lines = preg_split('/[\r\n,]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && in_array($line, $areas, true)) {
                $fullRows[] = $line;
            }
        }
        return array_values(array_unique($fullRows));
    }

    protected function parseAreaPadding($input, array $areas)
    {
        $padding = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area !== '' && in_array($area, $areas, true) && $value !== '') {
                $padding[$area] = $this->safeCssLengthList($value, $value);
            }
        }
        return $padding;
    }

    protected function normalizeSettings(array $data)
    {
        $gridTracks = [];
        if (!empty($data['grid_tracks'])) {
            $decoded = json_decode((string) $data['grid_tracks'], true);
            if (is_array($decoded)) {
                $gridTracks = $decoded;
            }
        }

        $gridColumns = $this->safeGridTemplate($data['grid_columns'] ?? '', 'repeat(12, minmax(0, 1fr))');
        $gridRows = $this->safeGridTemplate($data['grid_rows'] ?? '', 'minmax(64px, auto)');
        $viewportSettings = [];
        if (!empty($data['viewport_settings'])) {
            $decoded = json_decode((string) $data['viewport_settings'], true);
            if (is_array($decoded)) {
                $viewportSettings = $decoded;
            }
        }

        return [
            'inner' => $this->inList($data['inner'] ?? '', ['container', 'container-fluid', ''], ''),
            'gap' => $this->safeCssLength($data['gap'] ?? '1rem', '1rem'),
            'theme_id' => (int) ($data['theme_id'] ?? 0),
            'grid_columns' => $gridColumns,
            'grid_rows' => $gridRows,
            'grid_tracks' => $gridTracks,
            'row_size' => is_array($data['row_size'] ?? null) ? $data['row_size'] : [],
            'tablet_columns' => $this->safeGridTemplate($viewportSettings['tablet_columns'] ?? '', ''),
            'mobile_columns' => $this->safeGridTemplate($viewportSettings['mobile_columns'] ?? '', ''),
        ];
    }

    protected function safeGridTemplate($value, $default)
    {
        $value = trim((string) $value);
        if ($value === '' || strlen($value) > 600) {
            return $default;
        }
        if (preg_match('/[<>{};]/', $value)) {
            return $default;
        }

        return $value;
    }

    protected function safeGridPlacement($value)
    {
        $value = trim((string) $value);
        if ($value === '' || strlen($value) > 160) {
            return '';
        }
        if (!preg_match('/^[a-z0-9\\s\\-\\/%,.+()fr]+$/i', $value)) {
            return '';
        }

        return $value;
    }

    protected function safeCssSize($value)
    {
        $value = trim((string) $value);
        if ($value === '' || strlen($value) > 160) {
            return '';
        }
        if (preg_match('/[<>{};]/', $value)) {
            return '';
        }
        if (preg_match('/^(clamp|minmax|fit-content)\(/i', $value)) {
            return $value;
        }

        return $this->safeCssLength($value, '') ?: '';
    }

    protected function sanitizeHandle($handle)
    {
        $handle = strtolower(trim($handle));
        $handle = preg_replace('/[^a-z0-9]+/', '_', $handle);

        return trim($handle, '_');
    }

    protected function inList($value, array $allowed, $default)
    {
        $value = (string) $value;

        return in_array($value, $allowed, true) ? $value : $default;
    }

    protected function safeCssLength($value, $default)
    {
        $value = trim((string) $value);

        return preg_match('/^[-0-9.]+(px|rem|em|%|vw|vh)?$/', $value) ? $value : $default;
    }

    protected function safeCssLengthList($value, $default)
    {
        $value = trim((string) $value);

        return preg_match('/^[-0-9. ]+(px|rem|em|%|vw|vh)?( [-0-9.]+(px|rem|em|%|vw|vh)?){0,3}$/', $value) ? $value : $default;
    }

    protected function getThemePath(Theme $theme)
    {
        if (method_exists($theme, 'getThemeDirectory')) {
            $dir = $theme->getThemeDirectory();
            if ($dir && is_dir($dir)) {
                return $dir;
            }
        }

        $handle = $theme->getThemeHandle();
        $paths = [
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ];
        foreach ($paths as $path) {
            if (is_dir($path)) {
                return $path;
            }
        }
        return null;
    }

    protected function tryRegisterContainer($handle, $name)
    {
        $classes = [
            '\\Concrete\\Core\\Entity\\Page\\Container',
            '\\Concrete\\Core\\Entity\\Page\\ContainerTemplate',
        ];

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                continue;
            }
            try {
                $app = \Core::make('app');
                $em = $app->make('database/orm')->entityManager();
                $repo = $em->getRepository($class);
                $existing = method_exists($repo, 'findOneBy') ? $repo->findOneBy(['containerHandle' => $handle]) : null;
                if ($existing) {
                    return true;
                }
                $entity = new $class();
                if (method_exists($entity, 'setContainerName')) {
                    $entity->setContainerName($name);
                }
                if (method_exists($entity, 'setContainerHandle')) {
                    $entity->setContainerHandle($handle);
                }
                $em->persist($entity);
                $em->flush();

                return true;
            } catch (\Throwable $e) {
                return t('Created file for %s, but automatic registration failed: %s', $handle, $e->getMessage());
            }
        }

        return t('Created file for %s, but automatic registration is not available. Add it manually in Dashboard → Pages & Themes → Containers.', $handle);
    }
}
