<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>

<div class="alert alert-info">
    <?= t('Container Maker v0.8.2 fixes Area Settings controls, adds delete recovery, and adds desktop/tablet/mobile visual canvases.') ?>
</div>

<ul class="nav nav-tabs mb-3" id="cmContainerMakerTabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#cm-builder" type="button"><?= t('Visual Designer') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-library" type="button"><?= t('Container Library') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-presets" type="button"><?= t('Preset Installer') ?></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cm-manage" type="button"><?= t('Manage Installed Containers') ?></button></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade show active" id="cm-builder">
        <form method="post" action="<?= $view->action('build_flex') ?>" id="cmBuilderForm">
            <?php $token->output('container_maker_build_flex'); ?>
            <input type="hidden" name="areas" id="flexAreas" value="Main">
            <input type="hidden" name="area_widths" id="flexAreaWidths" value="">
            <input type="hidden" name="area_grid_columns" id="flexAreaGridColumns" value="">
            <input type="hidden" name="area_full_rows" id="flexAreaFullRows" value="">
            <input type="hidden" name="responsive_columns" id="flexResponsiveColumns" value="">
            <input type="hidden" name="nested_areas" id="flexNestedAreas" value="">

            <div class="row">
                <div class="col-xl-4">
                    <fieldset>
                        <legend><?= t('Container') ?></legend>
                        <div class="mb-3">
                            <label class="form-label" for="flexThemeID"><?= t('Installed Theme') ?></label>
                            <select name="themeID" id="flexThemeID" class="form-select" required>
                                <?php foreach ($themes as $theme) { ?>
                                    <option value="<?= h($theme->getThemeID()) ?>" <?= ((int) $selectedThemeID === (int) $theme->getThemeID()) ? 'selected' : '' ?>><?= h($theme->getThemeName()) ?> — <?= h($theme->getThemeHandle()) ?></option>
                                <?php } ?>
                            </select>
                            <div class="form-text"><?= t('Detected framework:') ?> <strong id="cmDetectedFramework"><?= h($themeFramework ?? 'custom') ?></strong></div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="flexName"><?= t('Container Name') ?></label>
                            <input type="text" name="name" id="flexName" class="form-control" value="Gunk" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="flexHandle"><?= t('Handle / PHP filename') ?></label>
                            <input type="text" name="handle" id="flexHandle" class="form-control" value="gunk">
                            <div class="form-text"><?= t('File:') ?> <strong><span id="flexFilePreview">gunk.php</span></strong></div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="flexLayoutMode"><?= t('Layout Mode') ?></label>
                                <select name="layout_mode" id="flexLayoutMode" class="form-select">
                                    <option value="grid12"><?= t('12-column grid') ?></option>
                                    <option value="css_grid"><?= t('Native CSS Grid') ?></option>
                                    <option value="flex"><?= t('Flexbox') ?></option>
                                    <option value="plain"><?= t('Plain stacked') ?></option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="cmBreakpoint"><?= t('Preview Breakpoint') ?></label>
                                <select id="cmBreakpoint" class="form-select">
                                    <option value="desktop"><?= t('Desktop') ?></option>
                                    <option value="tablet"><?= t('Tablet') ?></option>
                                    <option value="mobile"><?= t('Mobile') ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" name="use_flex" id="flexUseFlex" value="1" checked>
                            <label class="form-check-label" for="flexUseFlex"><?= t('Use flexbox when in Flexbox mode') ?></label>
                        </div>
                    </fieldset>

                    <fieldset class="mt-3">
                        <legend><?= t('Settings') ?></legend>
                        <div class="row">
                            <div class="col-md-6 mb-3"><label class="form-label">Gap</label><input name="gap" id="flexGap" class="form-control" value="1rem"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Padding</label><input name="padding" id="flexPadding" class="form-control" value="2rem 0"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Inner wrapper</label><select name="inner" id="flexInner" class="form-select"><option value="container">container</option><option value="container-fluid">container-fluid</option><option value="">none</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Mobile direction</label><select name="mobile" id="flexMobile" class="form-select"><option value="column">column</option><option value="row">row</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Direction</label><select name="direction" id="flexDirection" class="form-select"><option value="row">row</option><option value="column">column</option><option value="row-reverse">row-reverse</option><option value="column-reverse">column-reverse</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Wrap</label><select name="wrap" id="flexWrap" class="form-select"><option value="wrap">wrap</option><option value="nowrap">nowrap</option><option value="wrap-reverse">wrap-reverse</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Align</label><select name="align" id="flexAlign" class="form-select"><option value="stretch">stretch</option><option value="flex-start">start</option><option value="center">center</option><option value="flex-end">end</option><option value="baseline">baseline</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Justify</label><select name="justify" id="flexJustify" class="form-select"><option value="flex-start">start</option><option value="center">center</option><option value="flex-end">end</option><option value="space-between">space-between</option><option value="space-around">space-around</option><option value="space-evenly">space-evenly</option></select></div>
                            <input type="hidden" name="basis" id="flexBasis" value="100%"><input type="hidden" name="grow" id="flexGrow" value="0"><input type="hidden" name="shrink" id="flexShrink" value="0">
                        </div>
                    </fieldset>

                    <div class="mt-3 d-flex gap-2 flex-wrap">
                        <button type="button" id="cmAddArea" class="btn btn-outline-primary"><?= t('Add Area') ?></button>
                        <button type="button" id="cmUndo" class="btn btn-outline-secondary"><?= t('Undo') ?></button>
                        <button type="button" id="cmRedo" class="btn btn-outline-secondary"><?= t('Redo') ?></button>
                        <button type="button" id="cmRestoreDeleted" class="btn btn-outline-warning"><?= t('Restore Deleted') ?></button>
                    </div>
                    <hr>
                    <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="register" id="flexRegister" value="1" checked><label class="form-check-label" for="flexRegister"><?= t('Auto-register container') ?></label></div>
                    <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="overwrite" id="flexOverwrite" value="1"><label class="form-check-label" for="flexOverwrite"><?= t('Overwrite existing PHP file') ?></label></div>
                    <button type="submit" class="btn btn-primary"><?= t('Save Container PHP') ?></button>
                </div>

                <div class="col-xl-8">
                    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                        <h3 class="mb-0"><?= t('Visual Canvas') ?></h3>
                        <div class="input-group" style="max-width: 320px;"><span class="input-group-text"><?= t('Preview width') ?></span><input type="range" id="cmPreviewWidth" min="320" max="1200" value="900" class="form-range form-control"><span class="input-group-text" id="cmPreviewWidthLabel">900px</span></div>
                    </div>
                    <p class="text-muted"><?= t('Drag areas to reorder them. Resize using the desktop/tablet/mobile span controls. In 12-column and CSS Grid mode, overflow wraps automatically.') ?></p>
                    <div id="cmPreviewShell" class="cm-preview-shell"><div id="cmPreviewCanvas" class="cm-preview-canvas" data-breakpoint="desktop"></div></div>
                    <div class="row g-3 mt-2" id="cmViewportPreviews">
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Desktop</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasDesktop" data-breakpoint="desktop"></div></div></div>
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Tablet</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasTablet" data-breakpoint="tablet"></div></div></div>
                        <div class="col-xl-4"><div class="cm-viewport-card"><div class="cm-viewport-title">Mobile</div><div class="cm-preview-canvas cm-preview-canvas-small" id="cmPreviewCanvasMobile" data-breakpoint="mobile"></div></div></div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-lg-6">
                            <h4><?= t('Area Settings') ?></h4>
                            <div id="cmAreaInspector" class="cm-area-inspector"></div>
                        </div>
                        <div class="col-lg-6">
                            <h4><?= t('Code Preview') ?></h4>
                            <pre id="cmCodePreview" class="cm-code-preview"></pre>
                        </div>
                    </div>

                    <div class="card mt-3">
                        <div class="card-header"><?= t('Presets / Import / Export') ?></div>
                        <div class="card-body d-flex gap-2 flex-wrap align-items-center">
                            <input id="cmPresetName" class="form-control" style="max-width:260px" placeholder="<?= h(t('Preset name')) ?>">
                            <button type="button" id="cmSavePreset" class="btn btn-outline-primary"><?= t('Save as Preset') ?></button>
                            <button type="button" id="cmExportPreset" class="btn btn-outline-secondary"><?= t('Export JSON') ?></button>
                            <label class="btn btn-outline-secondary mb-0"><?= t('Import JSON') ?><input type="file" id="cmImportPreset" accept="application/json" hidden></label>
                            <select id="cmPresetSelect" class="form-select" style="max-width:260px"><option value=""><?= t('Load saved preset…') ?></option></select>
                            <button type="button" id="cmLoadPreset" class="btn btn-outline-secondary"><?= t('Load') ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="tab-pane fade" id="cm-library">
        <div class="row mb-3"><div class="col-md-6"><input type="search" id="cmLibrarySearch" class="form-control" placeholder="<?= h(t('Search containers by name, handle, category, or version…')) ?>"></div></div>
        <div id="cmLibraryList" class="row g-3"></div>
    </div>

    <div class="tab-pane fade" id="cm-presets">
        <form method="post" action="<?= $view->action('generate') ?>">
            <?php $token->output('container_maker_generate'); ?>
            <div class="mb-3"><label class="form-label"><?= t('Theme') ?></label><select name="themeID" class="form-select"><?php foreach ($themes as $theme) { ?><option value="<?= h($theme->getThemeID()) ?>" <?= ((int) $selectedThemeID === (int) $theme->getThemeID()) ? 'selected' : '' ?>><?= h($theme->getThemeName()) ?> — <?= h($theme->getThemeHandle()) ?></option><?php } ?></select></div>
            <div class="row">
                <?php foreach ($presets as $handle => $preset) { ?>
                    <div class="col-md-6 col-lg-3 mb-3"><label class="card h-100"><div class="card-body"><input type="checkbox" name="presets[]" value="<?= h($handle) ?>"> <strong><?= h($preset['name']) ?></strong><p class="text-muted mb-0"><?= h($preset['description']) ?></p></div></label></div>
                <?php } ?>
            </div>
            <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="register" value="1" checked id="cmPresetRegister"><label class="form-check-label" for="cmPresetRegister"><?= t('Auto-register created containers') ?></label></div>
            <button class="btn btn-primary" type="submit"><?= t('Install Selected Presets') ?></button>
        </form>
    </div>

    <div class="tab-pane fade" id="cm-manage">
        <form method="get" action="<?= h($view->url('/dashboard/pages/container_maker')) ?>" class="mb-3"><label class="form-label"><?= t('Theme') ?></label><select name="themeID" class="form-select" onchange="this.form.submit()"><?php foreach ($themes as $theme) { ?><option value="<?= h($theme->getThemeID()) ?>" <?= ((int) $selectedThemeID === (int) $theme->getThemeID()) ? 'selected' : '' ?>><?= h($theme->getThemeName()) ?> — <?= h($theme->getThemeHandle()) ?></option><?php } ?></select></form>
        <?php if (empty($registeredContainers)) { ?><div class="alert alert-warning"><?= t('No registered containers were found for this theme.') ?></div><?php } else { ?>
            <div class="table-responsive"><table class="table table-striped"><thead><tr><th><?= t('Name') ?></th><th><?= t('Handle') ?></th><th><?= t('Template File') ?></th><th><?= t('Action') ?></th></tr></thead><tbody>
            <?php foreach ($registeredContainers as $container) { ?>
                <tr><td><?= h($container['name'] ?? '') ?></td><td><code><?= h($container['handle'] ?? '') ?></code></td><td><?= !empty($container['template_exists']) ? '<span class="badge bg-success">' . t('Exists') . '</span>' : '<span class="badge bg-warning text-dark">' . t('Missing') . '</span>' ?></td><td><form method="post" action="<?= $view->action('uninstall') ?>" onsubmit="return confirm('<?= h(t('Uninstall this container registration?')) ?>');"><?php $token->output('container_maker_uninstall'); ?><input type="hidden" name="themeID" value="<?= h($selectedThemeID) ?>"><input type="hidden" name="containerHandle" value="<?= h($container['handle'] ?? '') ?>"><input type="hidden" name="confirm" value="1"><button class="btn btn-sm btn-danger" type="submit"><?= t('Uninstall') ?></button></form></td></tr>
            <?php } ?>
            </tbody></table></div>
        <?php } ?>
    </div>
</div>

<style>
.cm-preview-shell{border:1px solid #ddd;background:#f8f9fa;min-height:280px;resize:horizontal;overflow:auto;padding:1rem;max-width:100%;position:relative;}
.cm-viewport-card{border:1px solid #ddd;background:#f8f9fa;padding:.75rem;height:100%;}
.cm-viewport-title{font-weight:700;margin-bottom:.5rem;}
.cm-preview-canvas{background:#fff;border:1px solid #ccc;margin:auto;padding:24px;display:flex;flex-wrap:wrap;gap:1rem;align-items:stretch;min-height:220px;max-width:100%;overflow:hidden;position:relative;user-select:none;}
.cm-preview-canvas-small{padding:12px;min-height:160px;width:100%;resize:none;overflow:hidden;}
.cm-preview-canvas.cm-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));}
.cm-preview-canvas.cm-plain{display:block;}
.cm-area-tile{border:2px dashed #777;background:#eef3ff;min-height:74px;padding:.75rem;position:relative;cursor:grab;overflow:hidden;touch-action:none;}
.cm-area-tile-static{cursor:pointer;touch-action:auto;}
.cm-area-tile.cm-pointer-dragging{z-index:10;box-shadow:0 .5rem 1rem rgba(0,0,0,.15);cursor:grabbing;}
.cm-area-tile.active{outline:3px solid rgba(13,110,253,.35)}
.cm-area-title{font-weight:700}.cm-area-meta{font-size:12px;opacity:.75}.cm-area-resize{position:absolute;right:.35rem;bottom:.25rem;font-size:11px;opacity:.65}.cm-row-drag-handle{cursor:grab;user-select:none}.cm-area-row input,.cm-area-row button,.cm-area-row label{user-select:auto}.cm-code-preview{background:#111;color:#eee;min-height:270px;max-height:420px;overflow:auto;padding:1rem;border-radius:.25rem;font-size:12px}.cm-area-row{border:1px solid #ddd;border-radius:.25rem;padding:.75rem;margin-bottom:.5rem;background:#fff}.cm-area-row.dragging{opacity:.5}.cm-library-card .card-body{min-height:150px}
</style>

<script>
(function(){
    const framework = <?= json_encode($themeFramework ?? 'custom') ?>;
    const state = {selected:0, history:[], future:[], areas:[{name:'Main',desktop:12,tablet:12,mobile:12,full:false,nested:true,category:'General',version:'1.0.0'}]};
    const $ = id => document.getElementById(id);
    const inputs = ['flexName','flexHandle','flexLayoutMode','flexUseFlex','flexGap','flexPadding','flexInner','flexMobile','flexDirection','flexWrap','flexAlign','flexJustify','cmBreakpoint'];
    let handleTouched=false;
    function slug(s){return (s||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'') || 'container';}
    function pushHistory(){state.history.push(JSON.stringify(state.areas)); if(state.history.length>50) state.history.shift(); state.future=[];}
    function currentSpan(a){let bp=$('cmBreakpoint').value; return parseInt(a[bp]||12,10);}
    function render(){
        $('flexAreas').value = state.areas.map(a=>a.name).join('\n');
        $('flexAreaGridColumns').value = state.areas.map(a=>a.name+'::'+a.desktop).join('\n');
        $('flexAreaFullRows').value = state.areas.filter(a=>a.full).map(a=>a.name).join('\n');
        $('flexNestedAreas').value = state.areas.filter(a=>a.nested).map(a=>a.name).join('\n');
        $('flexResponsiveColumns').value = state.areas.map(a=>a.name+'::'+a.desktop+'|'+a.tablet+'|'+a.mobile).join('\n');
        $('flexAreaWidths').value = state.areas.map(a=>a.name+'::'+(a.full?'100%':'calc('+a.desktop+' / 12 * 100%)')).join('\n');
        ['cmPreviewCanvas','cmPreviewCanvasDesktop','cmPreviewCanvasTablet','cmPreviewCanvasMobile'].forEach(id=>renderCanvas(id));
        renderInspector(); renderCode(); renderLibrary();
    }
    function spanFor(a,bp){return parseInt(a.full?12:(a[bp]||12),10);}
    function applyCanvasLayout(canvas){
        const mode=$('flexLayoutMode').value;
        canvas.className='cm-preview-canvas '+(canvas.classList.contains('cm-preview-canvas-small')?'cm-preview-canvas-small ':'')+(mode==='css_grid'?'cm-grid':(mode==='plain'?'cm-plain':''));
        canvas.style.gap=$('flexGap').value; canvas.style.padding=canvas.classList.contains('cm-preview-canvas-small')?'12px':$('flexPadding').value;
        canvas.style.flexDirection=$('flexDirection').value; canvas.style.flexWrap=$('flexWrap').value; canvas.style.alignItems=$('flexAlign').value; canvas.style.justifyContent=$('flexJustify').value;
    }
    function renderCanvas(id){
        const canvas=$(id); if(!canvas) return;
        const mode=$('flexLayoutMode').value, bp=canvas.dataset.breakpoint||$('cmBreakpoint').value;
        applyCanvasLayout(canvas); canvas.innerHTML='';
        state.areas.forEach((a,i)=>{const tile=document.createElement('div'); tile.className='cm-area-tile'+(id==='cmPreviewCanvas'?'':' cm-area-tile-static')+(i===state.selected?' active':''); tile.draggable=false; tile.dataset.index=i; const span=spanFor(a,bp); if(mode==='css_grid'){tile.style.gridColumn='span '+span;} else if(mode==='plain'){tile.style.display='block'; tile.style.marginBottom='1rem';} else {tile.style.flex='0 0 '+(span/12*100)+'%'; tile.style.maxWidth=(span/12*100)+'%';} tile.innerHTML='<div class="cm-area-title">'+esc(a.name)+'</div><div class="cm-area-meta">'+bp.toUpperCase()+': '+span+'/12 '+(a.full?'· full row ':'')+(a.nested?'· nested ':'')+'</div><div class="cm-area-resize">'+(id==='cmPreviewCanvas'?'drag to reorder':'live viewport')+'</div>'; canvas.appendChild(tile);});
    }
    function esc(s){return (s+'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
    function renderInspector(){let html=''; state.areas.forEach((a,i)=>{html+='<div class="cm-area-row" data-index="'+i+'"><div class="d-flex justify-content-between align-items-center"><span class="cm-row-drag-handle btn btn-sm btn-outline-secondary" draggable="true" data-drag-index="'+i+'">↕ drag</span><strong>'+(i+1)+'. '+esc(a.name)+'</strong><button type="button" class="btn btn-sm btn-outline-danger" data-del="'+i+'">Delete</button></div><label class="form-label mt-2">Name</label><input class="form-control form-control-sm" data-name="'+i+'" value="'+esc(a.name)+'"><div class="row mt-2"><div class="col"><label class="form-label">Desktop</label><input type="range" min="1" max="12" data-desktop="'+i+'" value="'+a.desktop+'" class="form-range"><small>'+a.desktop+'/12</small></div><div class="col"><label class="form-label">Tablet</label><input type="range" min="1" max="12" data-tablet="'+i+'" value="'+a.tablet+'" class="form-range"><small>'+a.tablet+'/12</small></div><div class="col"><label class="form-label">Mobile</label><input type="range" min="1" max="12" data-mobile="'+i+'" value="'+a.mobile+'" class="form-range"><small>'+a.mobile+'/12</small></div></div><div class="form-check form-check-inline mt-2"><input class="form-check-input" type="checkbox" id="cmFull'+i+'" data-full="'+i+'" '+(a.full?'checked':'')+'><label class="form-check-label" for="cmFull'+i+'">Full row</label></div><div class="form-check form-check-inline mt-2"><input class="form-check-input" type="checkbox" id="cmNested'+i+'" data-nested="'+i+'" '+(a.nested?'checked':'')+'><label class="form-check-label" for="cmNested'+i+'">Nested-friendly</label></div></div>';}); $('cmAreaInspector').innerHTML=html;}
    function renderCode(){let handle=slug($('flexHandle').value||$('flexName').value), cls='cm-flex-'+handle.replace(/_/g,'-'), mode=$('flexLayoutMode').value; let names=state.areas.map(a=>"    '"+a.name.replace(/'/g,"\\'")+"'").join(',\n'); let css= mode==='css_grid'?'display:grid; grid-template-columns:repeat(12,minmax(0,1fr));':'display:flex; flex-wrap:wrap;'; $('cmCodePreview').textContent="<?php\nuse Concrete\\Core\\Area\\ContainerArea;\n$areas = [\n"+names+"\n];\n?>\n<section class=\""+cls+"\">\n  <div class=\""+($('flexInner').value||'')+"\">\n    <?php foreach ($areas as $areaName) { ?>\n      <?php $area = new ContainerArea($container, $areaName); $area->display($c); ?>\n    <?php } ?>\n  </div>\n</section>\n\n/* CSS idea */\n."+cls+" .cm-visual-container__items { "+css+" gap:"+$('flexGap').value+"; }\n";}
    function renderLibrary(){let q=($('cmLibrarySearch')?.value||'').toLowerCase(); let list=JSON.parse(localStorage.getItem('cm_container_presets')||'[]'); let html=''; list.filter(p=>JSON.stringify(p).toLowerCase().includes(q)).forEach((p,i)=>{html+='<div class="col-md-6 col-xl-4"><div class="card cm-library-card"><div class="card-body"><h5>'+esc(p.name||'Preset')+'</h5><p class="text-muted mb-1"><code>'+esc(p.handle||'')+'</code></p><p class="mb-2">'+(p.areas?p.areas.length:0)+' areas · '+esc(p.mode||'grid12')+'</p><button class="btn btn-sm btn-outline-primary" data-load-lib="'+i+'">Load</button> <button class="btn btn-sm btn-outline-secondary" data-dup-lib="'+i+'">Duplicate</button> <button class="btn btn-sm btn-outline-danger" data-del-lib="'+i+'">Delete</button></div></div></div>';}); $('cmLibraryList').innerHTML=html||'<div class="col"><div class="alert alert-light">No saved presets yet.</div></div>'; refreshPresetSelect(list);}
    function refreshPresetSelect(list){let sel=$('cmPresetSelect'), val=sel.value; sel.innerHTML='<option value="">Load saved preset…</option>'+list.map((p,i)=>'<option value="'+i+'">'+esc(p.name||'Preset')+'</option>').join(''); sel.value=val;}
    function snapshot(){return {name:$('flexName').value,handle:$('flexHandle').value,mode:$('flexLayoutMode').value,areas:state.areas};}
    function loadSnap(snap){if(!snap)return; $('flexName').value=snap.name||'Imported Container'; $('flexHandle').value=snap.handle||slug($('flexName').value); $('flexLayoutMode').value=snap.mode||'grid12'; state.areas=(snap.areas&&snap.areas.length)?snap.areas:state.areas; render();}
    document.addEventListener('input',e=>{let t=e.target;if(t.id==='flexName'&&!handleTouched){$('flexHandle').value=slug(t.value);$('flexFilePreview').textContent=$('flexHandle').value+'.php';} if(t.id==='flexHandle'){handleTouched=true;$('flexFilePreview').textContent=slug(t.value)+'.php';}
        ['name','desktop','tablet','mobile'].forEach(k=>{let i=t.dataset[k]; if(i!==undefined){pushHistory(); state.areas[i][k]=k==='name'?t.value:parseInt(t.value,10); state.selected=parseInt(i,10); render();}}); if(inputs.includes(t.id)||t.id==='cmPreviewWidth'||t.id==='cmLibrarySearch'){if(t.id==='cmPreviewWidth'){$('cmPreviewShell').style.width=t.value+'px';$('cmPreviewWidthLabel').textContent=t.value+'px';} render();}});
    document.addEventListener('change',e=>{let t=e.target; ['full','nested'].forEach(k=>{let i=t.dataset[k]; if(i!==undefined){pushHistory(); state.areas[i][k]=t.checked; if(k==='full'&&t.checked){state.areas[i].desktop=12;$('flexWrap').value='wrap';} render();}});});
    document.addEventListener('click',e=>{let t=e.target;if(t.id==='cmAddArea'){pushHistory();state.areas.push({name:'Area '+(state.areas.length+1),desktop:6,tablet:12,mobile:12,full:false,nested:true,category:'General',version:'1.0.0'});state.selected=state.areas.length-1;render();} if(t.dataset.del!==undefined){let i=parseInt(t.dataset.del,10); if(confirm('Delete this area from the designer? You can restore the last deleted area.')){pushHistory(); localStorage.setItem('cm_last_deleted_area', JSON.stringify(state.areas[i])); state.areas.splice(i,1);state.selected=0;render();}} if(t.id==='cmRestoreDeleted'){let saved=localStorage.getItem('cm_last_deleted_area'); if(saved){pushHistory(); state.areas.push(JSON.parse(saved)); state.selected=state.areas.length-1; localStorage.removeItem('cm_last_deleted_area'); render();} else {alert('No recently deleted area to restore.');}} if(t.id==='cmUndo'&&state.history.length){state.future.push(JSON.stringify(state.areas));state.areas=JSON.parse(state.history.pop());render();} if(t.id==='cmRedo'&&state.future.length){state.history.push(JSON.stringify(state.areas));state.areas=JSON.parse(state.future.pop());render();}
        if(t.id==='cmSavePreset'){let list=JSON.parse(localStorage.getItem('cm_container_presets')||'[]');let s=snapshot();s.name=$('cmPresetName').value||s.name;s.framework=framework;list.push(s);localStorage.setItem('cm_container_presets',JSON.stringify(list));renderLibrary();}
        if(t.id==='cmExportPreset'){let blob=new Blob([JSON.stringify(snapshot(),null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=slug($('flexName').value)+'_container_preset.json';a.click();}
        if(t.id==='cmLoadPreset'){let list=JSON.parse(localStorage.getItem('cm_container_presets')||'[]');loadSnap(list[parseInt($('cmPresetSelect').value,10)]);}
        ['loadLib','dupLib','delLib'].forEach(k=>{let attr='data-'+k.replace(/[A-Z]/g,m=>'-'+m.toLowerCase()); if(t.hasAttribute(attr)){let list=JSON.parse(localStorage.getItem('cm_container_presets')||'[]'),i=parseInt(t.getAttribute(attr),10); if(k==='loadLib')loadSnap(list[i]); if(k==='dupLib'){let cp=JSON.parse(JSON.stringify(list[i]));cp.name=(cp.name||'Preset')+' Copy';list.push(cp);localStorage.setItem('cm_container_presets',JSON.stringify(list));renderLibrary();} if(k==='delLib'){list.splice(i,1);localStorage.setItem('cm_container_presets',JSON.stringify(list));renderLibrary();}}});});
    
    let nativeDragFrom = null;
    document.addEventListener('dragstart',e=>{
        let handle=e.target.closest('.cm-row-drag-handle[data-drag-index]');
        if(handle){nativeDragFrom=parseInt(handle.dataset.dragIndex,10);e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',handle.dataset.dragIndex);} else {nativeDragFrom=null;}
    });
    document.addEventListener('dragover',e=>{if(nativeDragFrom!==null && e.target.closest('.cm-area-row[data-index]')) e.preventDefault();});
    document.addEventListener('drop',e=>{let row=e.target.closest('.cm-area-row[data-index]'); if(nativeDragFrom!==null && row){e.preventDefault();let from=nativeDragFrom,to=parseInt(row.dataset.index,10); nativeDragFrom=null; if(from!==to){pushHistory();let item=state.areas.splice(from,1)[0];state.areas.splice(to,0,item);render();}}});
    document.addEventListener('dragend',()=>{nativeDragFrom=null;});

    let pointerDrag = null;
    function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
    function beginCanvasDrag(e){
        if(e.target.closest('input,button,select,textarea,label,a')) return;
        const tile=e.target.closest('#cmPreviewCanvas .cm-area-tile[data-index]');
        if(!tile) return;
        e.preventDefault();
        const canvas=$('cmPreviewCanvas'), canvasRect=canvas.getBoundingClientRect(), tileRect=tile.getBoundingClientRect();
        pointerDrag={tile,index:parseInt(tile.dataset.index,10),startX:e.clientX,startY:e.clientY,dx:0,dy:0,canvasRect,tileRect};
        tile.classList.add('cm-pointer-dragging');
        tile.setPointerCapture?.(e.pointerId);
    }
    function moveCanvasDrag(e){
        if(!pointerDrag) return;
        e.preventDefault();
        const maxX=Math.max(0,pointerDrag.canvasRect.width-pointerDrag.tileRect.width);
        const maxY=Math.max(0,pointerDrag.canvasRect.height-pointerDrag.tileRect.height);
        const originalX=pointerDrag.tileRect.left-pointerDrag.canvasRect.left;
        const originalY=pointerDrag.tileRect.top-pointerDrag.canvasRect.top;
        const nextX=clamp(originalX+(e.clientX-pointerDrag.startX),0,maxX);
        const nextY=clamp(originalY+(e.clientY-pointerDrag.startY),0,maxY);
        pointerDrag.dx=nextX-originalX; pointerDrag.dy=nextY-originalY;
        pointerDrag.tile.style.transform='translate('+pointerDrag.dx+'px,'+pointerDrag.dy+'px)';
    }
    function endCanvasDrag(e){
        if(!pointerDrag) return;
        const drag=pointerDrag; pointerDrag=null;
        drag.tile.classList.remove('cm-pointer-dragging');
        drag.tile.style.transform='';
        const canvas=$('cmPreviewCanvas');
        const tiles=[...canvas.querySelectorAll('.cm-area-tile[data-index]')];
        const centerX=drag.tileRect.left+drag.dx+drag.tileRect.width/2;
        const centerY=drag.tileRect.top+drag.dy+drag.tileRect.height/2;
        let to=drag.index, best=Infinity;
        tiles.forEach(el=>{
            const idx=parseInt(el.dataset.index,10); if(idx===drag.index) return;
            const r=el.getBoundingClientRect();
            const d=Math.hypot(centerX-(r.left+r.width/2), centerY-(r.top+r.height/2));
            if(d<best){best=d;to=idx;}
        });
        if(to!==drag.index){pushHistory();let item=state.areas.splice(drag.index,1)[0];state.areas.splice(to,0,item);state.selected=to;render();}
        else {state.selected=drag.index;render();}
    }
    $('cmPreviewCanvas').addEventListener('pointerdown',beginCanvasDrag);
    ['cmPreviewCanvasDesktop','cmPreviewCanvasTablet','cmPreviewCanvasMobile'].forEach(id=>{let c=$(id); if(c){c.addEventListener('click',e=>{let tile=e.target.closest('.cm-area-tile[data-index]'); if(tile){state.selected=parseInt(tile.dataset.index,10); render();}});}});
    document.addEventListener('pointermove',moveCanvasDrag);
    document.addEventListener('pointerup',endCanvasDrag);
    document.addEventListener('pointercancel',endCanvasDrag);

    $('cmImportPreset').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{loadSnap(JSON.parse(r.result));}catch(err){alert('Invalid JSON preset.');}};r.readAsText(f);});
    $('cmPreviewShell').style.width='900px'; $('cmDetectedFramework').textContent=framework; render();
})();
</script>
