<?php
namespace Concrete\Package\ContainerMaker\Controller\SinglePage\Dashboard\Pages;

use Concrete\Core\Page\Controller\DashboardPageController;
use Concrete\Core\Page\Theme\Theme as PageTheme;
use Concrete\Package\ContainerMaker\Service\ContainerGenerator;
use Concrete\Package\ContainerMaker\Service\ContainerManager;

class ContainerMaker extends DashboardPageController
{
    public function view()
    {
        $themes = $this->getInstalledThemes();
        $selectedThemeID = (int) ($this->request->query->get('themeID') ?: 0);
        if (!$selectedThemeID && isset($themes[0])) {
            $selectedThemeID = (int) $themes[0]->getThemeID();
        }

        $selectedTheme = $selectedThemeID ? PageTheme::getByID($selectedThemeID) : null;
        $registeredContainers = [];
        if (is_object($selectedTheme) && $selectedTheme->getThemeID()) {
            $manager = $this->app->make(ContainerManager::class);
            $registeredContainers = $manager->getRegisteredContainersForTheme($selectedTheme);
        }

        $this->set('themes', $themes);
        $this->set('selectedThemeID', $selectedThemeID);
        $this->set('registeredContainers', $registeredContainers);
        $this->set('presets', ContainerGenerator::getPresets());
        $this->set('themeFramework', $selectedTheme ? $this->detectThemeFramework($selectedTheme) : 'custom');
    }

    public function generate()
    {
        if (!$this->token->validate('container_maker_generate')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $themeID = (int) $this->request->request->get('themeID');
        $presetHandles = (array) $this->request->request->all('presets');
        $register = (bool) $this->request->request->get('register');

        $theme = PageTheme::getByID($themeID);
        if (!is_object($theme) || !$theme->getThemeID()) {
            $this->error->add(t('Please choose a valid installed theme.'));
            return $this->view();
        }
        if (empty($presetHandles)) {
            $this->error->add(t('Please choose at least one container preset.'));
            return $this->view();
        }

        $generator = $this->app->make(ContainerGenerator::class);
        $result = $generator->generate($theme, $presetHandles, $register);

        foreach ($result['created'] as $item) {
            $this->flash('success', t('Created %s', $item));
        }
        foreach ($result['registered'] as $item) {
            $this->flash('success', t('Registered %s', $item));
        }
        foreach ($result['skipped'] as $item) {
            $this->flash('info', t('Skipped existing file %s', $item));
        }
        foreach ($result['errors'] as $item) {
            $this->error->add($item);
        }

        return $this->redirect('/dashboard/pages/container_maker');
    }


    public function build_flex()
    {
        if (!$this->token->validate('container_maker_build_flex')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $themeID = (int) $this->request->request->get('themeID');
        $theme = PageTheme::getByID($themeID);
        if (!is_object($theme) || !$theme->getThemeID()) {
            $this->error->add(t('Please choose a valid installed theme.'));
            return $this->view();
        }

        $data = $this->request->request->all();
        $generator = $this->app->make(ContainerGenerator::class);
        $result = $generator->generateFlex($theme, $data);

        foreach ($result['created'] as $item) {
            $this->flash('success', t('Created custom flex container file: %s', $item));
        }
        foreach ($result['registered'] as $item) {
            $this->flash('success', t('Registered %s', $item));
        }
        foreach ($result['skipped'] as $item) {
            $this->flash('info', t('Skipped existing file %s. Check overwrite if you want to replace it.', $item));
        }
        foreach ($result['errors'] as $item) {
            $this->error->add($item);
        }

        return $this->buildRedirect('/dashboard/pages/container_maker?themeID=' . $themeID);
    }


    public function uninstall()
    {
        if (!$this->token->validate('container_maker_uninstall')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $themeID = (int) $this->request->request->get('themeID');
        $handle = (string) $this->request->request->get('containerHandle');
        $confirm = (bool) $this->request->request->get('confirm');

        if (!$confirm) {
            $this->error->add(t('Please check the confirmation box before uninstalling a container.'));
            return $this->buildRedirect('/dashboard/pages/container_maker?themeID=' . $themeID);
        }

        $manager = $this->app->make(ContainerManager::class);
        $result = $manager->uninstallByHandle($handle);
        if ($result === true) {
            $this->flash('success', t('Uninstalled container registration: %s', $handle));
        } else {
            $this->error->add($result);
        }

        return $this->buildRedirect('/dashboard/pages/container_maker?themeID=' . $themeID);
    }


    protected function detectThemeFramework(PageTheme $theme)
    {
        $handle = $theme->getThemeHandle();
        $paths = [
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ];
        $haystack = '';
        foreach ($paths as $path) {
            if (!is_dir($path)) {
                continue;
            }
            foreach (['page_theme.php', 'main.css', 'theme.css', 'default.php', 'elements/header.php'] as $file) {
                $candidate = rtrim($path, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $file;
                if (is_file($candidate)) {
                    $haystack .= ' ' . strtolower((string) @file_get_contents($candidate));
                }
            }
        }
        if (strpos($haystack, 'bootstrap') !== false || strpos($haystack, 'container-fluid') !== false) {
            return 'bootstrap';
        }
        if (strpos($haystack, 'tailwind') !== false || strpos($haystack, 'grid-cols-') !== false) {
            return 'tailwind';
        }
        if (strpos($haystack, 'foundation') !== false || strpos($haystack, 'xy-grid') !== false) {
            return 'foundation';
        }
        return 'custom';
    }

    protected function getInstalledThemes()
    {
        $themes = [];
        foreach (PageTheme::getList() as $theme) {
            if (is_object($theme) && $theme->getThemeID()) {
                $themes[] = $theme;
            }
        }
        return $themes;
    }
}
