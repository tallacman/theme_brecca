<?php
namespace Concrete\Package\ContainerMaker\Service;

use Concrete\Core\Page\Theme\Theme;

class ContainerGenerator
{
    public static function getPresets()
    {
        return [
            'hero' => [
                'name' => t('Hero'),
                'description' => t('Large hero section with title and body areas.'),
                'areas' => ['Title', 'Main'],
                'class' => 'cm-hero',
                'inner' => 'container',
            ],
            'two_column' => [
                'name' => t('Two Column'),
                'description' => t('Responsive two-column section.'),
                'areas' => ['Left Column', 'Right Column'],
                'class' => 'cm-two-column',
                'inner' => 'container',
            ],
            'full_width' => [
                'name' => t('Full Width'),
                'description' => t('Full-width editable section.'),
                'areas' => ['Main'],
                'class' => 'cm-full-width',
                'inner' => 'container-fluid',
            ],
            'card_grid' => [
                'name' => t('Card Grid'),
                'description' => t('Section with title and three editable card areas.'),
                'areas' => ['Title', 'Card One', 'Card Two', 'Card Three'],
                'class' => 'cm-card-grid',
                'inner' => 'container',
            ],
        ];
    }

    public function generate(Theme $theme, array $handles, $register = true)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $presets = static::getPresets();
        $themePath = $this->getThemePath($theme);

        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        foreach ($handles as $handle) {
            if (!isset($presets[$handle])) {
                $result['errors'][] = t('Unknown preset: %s', $handle);
                continue;
            }
            $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
            if (file_exists($file)) {
                $result['skipped'][] = $file;
            } else {
                $php = $this->buildContainerPhp($presets[$handle]);
                if (@file_put_contents($file, $php) === false) {
                    $result['errors'][] = t('Could not write file: %s', $file);
                    continue;
                }
                $result['created'][] = $file;
            }

            if ($register) {
                $registered = $this->tryRegisterContainer($handle, $presets[$handle]['name']);
                if ($registered === true) {
                    $result['registered'][] = $presets[$handle]['name'] . ' (' . $handle . ')';
                } elseif (is_string($registered)) {
                    $result['errors'][] = $registered;
                }
            }
        }

        return $result;
    }

    protected function buildContainerPhp(array $preset)
    {
        $areas = var_export($preset['areas'], true);
        $class = addslashes($preset['class']);
        $inner = addslashes($preset['inner']);

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Area\ContainerArea;

\$areas = {$areas};
?>
<section class="{$class}">
    <div class="{$inner}">
        <?php foreach (\$areas as \$areaName) { ?>
            <div class="{$class}__area {$class}__area--<?= h(strtolower(str_replace(' ', '-', \$areaName))) ?>">
                <?php
                \$area = new ContainerArea(\$container, \$areaName);
                if (method_exists(\$area, 'setAreaGridMaximumColumns')) {
                    \$area->setAreaGridMaximumColumns(12);
                }
                if (method_exists(\$area, 'enableGridContainer')) {
                    \$area->enableGridContainer();
                }
                \$area->display(\$c);
                ?>
            </div>
        <?php } ?>
    </div>
</section>
<style>
.ccm-edit-mode .{$class}__area {
    min-height: 72px;
    outline: 1px dashed rgba(0, 0, 0, .25);
    outline-offset: -1px;
    padding: .5rem;
}
.ccm-edit-mode .{$class}__area .ccm-area {
    min-height: 48px;
}
</style>
PHP;
    }


    public function generateFlex(Theme $theme, array $data)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $themePath = $this->getThemePath($theme);
        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $name = trim((string) ($data['name'] ?? ''));
        $handle = $this->sanitizeHandle((string) ($data['handle'] ?? ''));
        if ($name === '') {
            $name = t('Custom Flex Container');
        }
        if ($handle === '') {
            $handle = $this->sanitizeHandle($name);
        }
        if ($handle === '') {
            $result['errors'][] = t('Please enter a valid container handle.');
            return $result;
        }

        $areas = $this->parseAreaNames((string) ($data['areas'] ?? 'Main'));
        if (empty($areas)) {
            $result['errors'][] = t('Please enter at least one editable area.');
            return $result;
        }

        $areaWidths = $this->parseAreaWidths((string) ($data['area_widths'] ?? ''), $areas);
        $areaGridColumns = $this->parseAreaGridColumns((string) ($data['area_grid_columns'] ?? ''), $areas);
        $areaFullRows = $this->parseAreaFullRows((string) ($data['area_full_rows'] ?? ''), $areas);
        $settings = $this->normalizeFlexSettings($data);
        if ($settings['layout_mode'] === 'grid12') {
            foreach ($areas as $areaName) {
                $span = $areaGridColumns[$areaName] ?? null;
                if ($span !== null) {
                    $areaWidths[$areaName] = 'calc(' . $span . ' / 12 * 100%)';
                }
            }
            $settings['use_flex'] = true;
            $settings['direction'] = 'row';
            $settings['wrap'] = 'wrap';
            $settings['grow'] = '0';
            $settings['shrink'] = '0';
            $settings['basis'] = '100%';
        }

        $responsiveColumns = $this->parseResponsiveColumns((string) ($data['responsive_columns'] ?? ''), $areas);
        $nestedAreas = $this->parseAreaFullRows((string) ($data['nested_areas'] ?? ''), $areas);
        if (!empty($areaFullRows) && !empty($settings['use_flex'])) {
            $settings['wrap'] = 'wrap';
        }
        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
        $overwrite = !empty($data['overwrite']);
        if (file_exists($file) && !$overwrite) {
            $result['skipped'][] = $file;
        } else {
            $php = $this->buildFlexContainerPhp($handle, $areas, $settings, $areaWidths, $areaFullRows, $responsiveColumns ?? [], $nestedAreas ?? []);
            if (@file_put_contents($file, $php) === false) {
                $result['errors'][] = t('Could not write file: %s', $file);
                return $result;
            }
            $result['created'][] = $file;
        }

        if (!empty($data['register'])) {
            $registered = $this->tryRegisterContainer($handle, $name);
            if ($registered === true) {
                $result['registered'][] = $name . ' (' . $handle . ')';
            } elseif (is_string($registered)) {
                $result['errors'][] = $registered;
            }
        }

        return $result;
    }

    protected function buildFlexContainerPhp($handle, array $areas, array $settings, array $areaWidths = [], array $areaFullRows = [], array $responsiveColumns = [], array $nestedAreas = [])
    {
        $areasExport = var_export($areas, true);
        $class = 'cm-flex-' . str_replace('_', '-', $handle);
        $direction = addslashes($settings['direction']);
        $wrap = addslashes($settings['wrap']);
        $gap = addslashes($settings['gap']);
        $align = addslashes($settings['align']);
        $justify = addslashes($settings['justify']);
        $inner = addslashes($settings['inner']);
        $padding = addslashes($settings['padding']);
        $mobile = addslashes($settings['mobile']);
        $basis = addslashes($settings['basis']);
        $grow = addslashes($settings['grow']);
        $shrink = addslashes($settings['shrink']);
        $useFlex = !empty($settings['use_flex']);
        $isCssGrid = $settings['layout_mode'] === 'css_grid';
        $display = $isCssGrid ? 'grid' : ($useFlex ? 'flex' : 'block');
        $widthsExport = var_export($areaWidths, true);
        $fullRowsExport = var_export($areaFullRows, true);
        $responsiveExport = var_export($responsiveColumns, true);
        $nestedExport = var_export($nestedAreas, true);

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

use Concrete\Core\Area\ContainerArea;

\$areas = {$areasExport};
\$areaWidths = {$widthsExport};
\$areaFullRows = {$fullRowsExport};
\$responsiveColumns = {$responsiveExport};
\$nestedAreas = {$nestedExport};
?>
<section class="{$class} cm-visual-container" style="--cm-container-display: {$display}; --cm-flex-direction: {$direction}; --cm-flex-wrap: {$wrap}; --cm-flex-gap: {$gap}; --cm-flex-align: {$align}; --cm-flex-justify: {$justify}; --cm-flex-padding: {$padding}; --cm-flex-mobile-direction: {$mobile}; --cm-flex-child-basis: {$basis}; --cm-flex-child-grow: {$grow}; --cm-flex-child-shrink: {$shrink};">
    <div class="{$inner}">
        <div class="cm-visual-container__items">
            <?php foreach (\$areas as \$areaName) { ?>
                <div class="cm-visual-container__item cm-visual-container__item--<?= h(strtolower(preg_replace('/[^a-z0-9]+/i', '-', \$areaName))) ?><?= in_array(\$areaName, \$areaFullRows, true) ? ' cm-visual-container__item--full-row' : '' ?><?= in_array(\$areaName, \$nestedAreas, true) ? ' cm-visual-container__item--nested' : '' ?>" style="--cm-flex-child-basis: <?= h(in_array(\$areaName, \$areaFullRows, true) ? '100%' : (\$areaWidths[\$areaName] ?? '{$basis}')) ?>; --cm-col-desktop: <?= h((string)(\$responsiveColumns[\$areaName]['desktop'] ?? 12)) ?>; --cm-col-tablet: <?= h((string)(\$responsiveColumns[\$areaName]['tablet'] ?? 12)) ?>; --cm-col-mobile: <?= h((string)(\$responsiveColumns[\$areaName]['mobile'] ?? 12)) ?>;">
                    <?php
                    \$area = new ContainerArea(\$container, \$areaName);
                    if (method_exists(\$area, 'setAreaGridMaximumColumns')) {
                        \$area->setAreaGridMaximumColumns(12);
                    }
                    if (method_exists(\$area, 'enableGridContainer')) {
                        \$area->enableGridContainer();
                    }
                    \$area->display(\$c);
                    ?>
                </div>
            <?php } ?>
        </div>
    </div>
</section>
<style>
.{$class} { padding: var(--cm-flex-padding, 0); }
.{$class} .cm-visual-container__items {
    display: var(--cm-container-display, flex);
    grid-template-columns: repeat(12, minmax(0, 1fr));
    flex-direction: var(--cm-flex-direction, row);
    flex-wrap: var(--cm-flex-wrap, wrap);
    gap: var(--cm-flex-gap, 1rem);
    align-items: var(--cm-flex-align, stretch);
    justify-content: var(--cm-flex-justify, flex-start);
}
.{$class} .cm-visual-container__item {
    grid-column: span var(--cm-col-desktop, 12);
    flex: var(--cm-flex-child-grow, 1) var(--cm-flex-child-shrink, 1) var(--cm-flex-child-basis, 0);
    min-width: 0;
    position: relative;
}
.ccm-edit-mode .{$class} .cm-visual-container__item,
.{$class}.ccm-edit-mode .cm-visual-container__item {
    min-height: 72px;
    outline: 1px dashed rgba(0, 0, 0, .25);
    outline-offset: -1px;
    padding: .5rem;
}
.ccm-edit-mode .{$class} .ccm-area,
.{$class}.ccm-edit-mode .ccm-area {
    min-height: 48px;
}
.{$class} .cm-visual-container__item--full-row {
    flex: 0 0 100%;
    max-width: 100%;
}
@media (max-width: 991px) {
    .{$class} .cm-visual-container__item { grid-column: span var(--cm-col-tablet, 12); }
}
@media (max-width: 767px) {
    .{$class} .cm-visual-container__items {
        flex-direction: var(--cm-flex-mobile-direction, column);
    }
    .{$class} .cm-visual-container__item { grid-column: span var(--cm-col-mobile, 12); }
}
.ccm-edit-mode .{$class} .cm-visual-container__item--nested::before {
    content: 'Nested-friendly area';
    display: block;
    font-size: 11px;
    opacity: .65;
    margin-bottom: .25rem;
}
</style>
PHP;
    }

    protected function parseAreaNames($input)
    {
        $parts = preg_split('/[\r\n,]+/', $input);
        $areas = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $areas[] = $part;
            }
        }
        return array_values(array_unique($areas));
    }

    protected function parseAreaWidths($input, array $areas)
    {
        $widths = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $width] = array_map('trim', explode('::', $line, 2));
            if ($area !== '' && in_array($area, $areas, true)) {
                $widths[$area] = $this->safeCssLength($width, '0');
            }
        }
        return $widths;
    }


    protected function parseAreaGridColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $span] = array_map('trim', explode('::', $line, 2));
            $span = (int) $span;
            if ($area !== '' && in_array($area, $areas, true) && $span >= 1 && $span <= 12) {
                $columns[$area] = $span;
            }
        }
        return $columns;
    }



    protected function parseResponsiveColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_map('intval', array_pad(explode('|', $value), 3, 12));
            $columns[$area] = [
                'desktop' => max(1, min(12, $parts[0])),
                'tablet' => max(1, min(12, $parts[1])),
                'mobile' => max(1, min(12, $parts[2])),
            ];
        }
        return $columns;
    }

    protected function parseAreaFullRows($input, array $areas)
    {
        $fullRows = [];
        $lines = preg_split('/[\r\n,]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && in_array($line, $areas, true)) {
                $fullRows[] = $line;
            }
        }
        return array_values(array_unique($fullRows));
    }

    protected function normalizeFlexSettings(array $data)
    {
        return [
            'layout_mode' => $this->inList($data['layout_mode'] ?? 'flex', ['flex', 'grid12', 'css_grid', 'plain'], 'flex'),
            'use_flex' => !empty($data['use_flex']) || (($data['layout_mode'] ?? '') === 'grid12'),
            'direction' => $this->inList($data['direction'] ?? 'row', ['row', 'row-reverse', 'column', 'column-reverse'], 'row'),
            'wrap' => $this->inList($data['wrap'] ?? 'wrap', ['nowrap', 'wrap', 'wrap-reverse'], 'wrap'),
            'align' => $this->inList($data['align'] ?? 'stretch', ['stretch', 'flex-start', 'center', 'flex-end', 'baseline'], 'stretch'),
            'justify' => $this->inList($data['justify'] ?? 'flex-start', ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], 'flex-start'),
            'inner' => $this->inList($data['inner'] ?? 'container', ['container', 'container-fluid', ''], 'container'),
            'mobile' => $this->inList($data['mobile'] ?? 'column', ['column', 'row'], 'column'),
            'gap' => $this->safeCssLength($data['gap'] ?? '1rem', '1rem'),
            'padding' => $this->safeCssLengthList($data['padding'] ?? '2rem 0', '2rem 0'),
            'basis' => $this->safeCssLength($data['basis'] ?? '0', '0'),
            'grow' => preg_match('/^[0-9]+(\.[0-9]+)?$/', (string) ($data['grow'] ?? '1')) ? (string) $data['grow'] : '1',
            'shrink' => preg_match('/^[0-9]+(\.[0-9]+)?$/', (string) ($data['shrink'] ?? '1')) ? (string) $data['shrink'] : '1',
        ];
    }

    protected function sanitizeHandle($handle)
    {
        $handle = strtolower(trim($handle));
        $handle = preg_replace('/[^a-z0-9]+/', '_', $handle);
        return trim($handle, '_');
    }

    protected function inList($value, array $allowed, $default)
    {
        $value = (string) $value;
        return in_array($value, $allowed, true) ? $value : $default;
    }

    protected function safeCssLength($value, $default)
    {
        $value = trim((string) $value);
        return preg_match('/^[-0-9.]+(px|rem|em|%|vw|vh)?$/', $value) ? $value : $default;
    }

    protected function safeCssLengthList($value, $default)
    {
        $value = trim((string) $value);
        return preg_match('/^[-0-9. ]+(px|rem|em|%|vw|vh)?( [-0-9.]+(px|rem|em|%|vw|vh)?){0,3}$/', $value) ? $value : $default;
    }

    protected function getThemePath(Theme $theme)
    {
        if (method_exists($theme, 'getThemeDirectory')) {
            $dir = $theme->getThemeDirectory();
            if ($dir && is_dir($dir)) {
                return $dir;
            }
        }

        $handle = $theme->getThemeHandle();
        $paths = [
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ];
        foreach ($paths as $path) {
            if (is_dir($path)) {
                return $path;
            }
        }
        return null;
    }

    protected function tryRegisterContainer($handle, $name)
    {
        // Concrete 9 stores containers as Doctrine entities. Class names have varied in some builds,
        // so this method is intentionally defensive. File generation still works if this fails.
        $classes = [
            '\\Concrete\\Core\\Entity\\Page\\Container',
            '\\Concrete\\Core\\Entity\\Page\\ContainerTemplate',
        ];

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                continue;
            }
            try {
                $app = \Core::make('app');
                $em = $app->make('database/orm')->entityManager();
                $repo = $em->getRepository($class);
                $existing = method_exists($repo, 'findOneBy') ? $repo->findOneBy(['containerHandle' => $handle]) : null;
                if ($existing) {
                    return true;
                }
                $entity = new $class();
                if (method_exists($entity, 'setContainerName')) {
                    $entity->setContainerName($name);
                }
                if (method_exists($entity, 'setContainerHandle')) {
                    $entity->setContainerHandle($handle);
                }
                $em->persist($entity);
                $em->flush();
                return true;
            } catch (\Throwable $e) {
                return t('Created file for %s, but automatic registration failed: %s', $handle, $e->getMessage());
            }
        }

        return t('Created file for %s, but automatic registration is not available on this Concrete install. Add it manually in Dashboard → Pages & Themes → Containers.', $handle);
    }
}
