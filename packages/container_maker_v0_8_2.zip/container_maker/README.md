# Container Maker for Concrete CMS

Version: 0.8.2

Container Maker adds a dashboard tool at **Dashboard → Pages & Themes → Container Maker** for generating Concrete CMS container PHP files for installed themes.

## New in 0.8.2

- Fixed preview canvas dragging so areas are clamped inside the preview instead of pulling outside the viewport.
- Preview tiles use pointer-based dragging; inspector rows still use simple drag/drop ordering.
- Added safer canvas overflow handling for the resizable preview.

## New in 0.8.0

- Visual designer canvas
- Drag/drop area ordering
- Resizable preview width
- Responsive breakpoints: desktop, tablet, mobile
- 12-column grid mode with automatic wrapping
- Native CSS Grid mode
- Flexbox mode and plain stacked mode
- Per-area desktop/tablet/mobile spans
- Full-row areas
- Nested-friendly areas
- Live generated PHP/CSS code preview
- Save as browser preset
- Import/export JSON presets
- Local container library manager with search, load, duplicate, and delete
- Basic theme framework detection: Bootstrap, Tailwind, Foundation, or custom

## Install

1. Unzip this package.
2. Put the `container_maker` folder into your Concrete CMS `packages/` directory.
3. Go to **Dashboard → Extend Concrete**.
4. Install **Container Maker**.
5. Open **Dashboard → Pages & Themes → Container Maker**.

## Upgrade

Replace the older `packages/container_maker` folder with this one, then visit **Dashboard → Extend Concrete** if Concrete offers an update.

## Important notes

- The visual library/preset manager stores presets in the browser using `localStorage`.
- Export JSON if you want to move presets between browsers or projects.
- Generated container PHP files are written into the selected theme’s `elements/containers/` directory.
- Existing files are not overwritten unless **Overwrite existing PHP file** is checked.
- Auto-registration is defensive because Concrete CMS container internals vary by version. If registration fails, the PHP file is still created and you can register it manually.
- Uninstalling a container removes its registration only. It does not delete the PHP template file.

## Suggested workflow

1. Pick your installed theme.
2. Name the container.
3. Choose layout mode: 12-column, CSS Grid, Flexbox, or Plain.
4. Add areas on the canvas.
5. Set each area’s desktop/tablet/mobile span.
6. Preview the wrap behavior by dragging the preview width.
7. Check the code preview.
8. Save as a preset if you want to reuse it.
9. Save the container PHP file.



## v0.8.2

- Area Settings controls no longer drag the whole settings card.
- Drag ordering now uses a dedicated drag handle.
- Delete asks for confirmation and has Restore Deleted recovery.
- Added desktop, tablet, and mobile live canvas previews.
