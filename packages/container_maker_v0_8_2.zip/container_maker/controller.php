<?php
namespace Concrete\Package\ContainerMaker;

use Concrete\Core\Package\Package;
use Concrete\Core\Page\Single as SinglePage;

class Controller extends Package
{
    protected $pkgHandle = 'container_maker';
    protected $appVersionRequired = '9.0.0';
    protected $pkgVersion = '0.8.2';
    protected $pkgAutoloaderRegistries = [
        'src/Service' => '\\Concrete\\Package\\ContainerMaker\\Service',
    ];

    public function getPackageName()
    {
        return t('Container Maker');
    }

    public function getPackageDescription()
    {
        return t('Generate and manage Concrete CMS container template files for installed themes, including a visual responsive container designer with flex, 12-column, CSS Grid, presets, import/export, code preview, responsive breakpoints, and library-management helpers.');
    }

    public function install()
    {
        $pkg = parent::install();
        $this->installSinglePage($pkg, '/dashboard/pages/container_maker', t('Container Maker'));
        return $pkg;
    }

    protected function installSinglePage($pkg, $path, $name)
    {
        $page = SinglePage::add($path, $pkg);
        if (is_object($page) && !$page->isError()) {
            $page->update(['cName' => $name]);
        }
    }
}
