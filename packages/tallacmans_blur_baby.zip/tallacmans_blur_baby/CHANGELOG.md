### version 0.9.5 - April 21, 2020  

- numeric inputs now numeric with limits

### version 0.9.3 - April 15, 2020

- all css now in controller
- numeric inputs

### version 0.9.2 - March 5, 2020

- moved dynamic css to controller :: header
- responsive image now used
- added variable for image width


### version 0.9.0 - February 27 - 28, 2020

- to prb
- changed db types to integer and float
- removed numeric testing in controller
- moved css to inline


### version 1.0.0 - January 23, 2023

- PHP 8 support
