<?php defined('C5_EXECUTE') or exit('Access Denied.');
?>

<?php
if ($image) {
    $image_tag = $app->make('html/image', [$image])->getTag();
    $image_tag->alt($image->getTitle());
    ?>
<div class="tallacmans-blur-baby-wrapper-<?php echo $bID; ?>">
    <div class="tallacmans-blur-baby-background-<?php echo $bID; ?>">
      <img src="<?php echo $image->getURL(); ?>" alt="<?php echo $image->getTitle(); ?>"/>
    </div>
   <div class="tallacmans-blur-baby-image-<?php echo $bID; ?>">
     <img src="<?php echo $image->getURL(); ?>" alt="<?php echo $image->getTitle(); ?>"/>

   </div>
</div>
<?php
}
?>
