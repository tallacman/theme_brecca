<?php

namespace Concrete\Package\TallacmansBlurBaby\Block\TallacmansBlurBaby;

defined('C5_EXECUTE') or exit('Access Denied.');

use Concrete\Core\Block\BlockController;
use Concrete\Core\File\File;

class Controller extends BlockController
{
    protected $btTable = 'btTallacmansBlurBaby';

    protected $btInterfaceWidth = 400;

    protected $btInterfaceHeight = 700;

    protected $btIgnorePageThemeGridFrameworkContainer = true;

    protected $pkg = 'tallacmans_blur_baby';

    protected $btDefaultSet = 'basic';

    public function getBlockTypeDescription()
    {
        return t('A unique way to show a featured image.');
    }

    public function getBlockTypeName()
    {
        return t('Tallacmans Blur Baby');
    }

    public function on_start()
    {
        $this->set('app', $this->app);
    }

    private function generate_styles()
    {
        ob_start();
        ?>
        div.tallacmans-blur-baby-background-<?php echo $this->bID; ?>{
          height:<?php echo h($this->height); ?>%;
          align-self: <?php echo h($this->placement); ?>;
        }
        div.tallacmans-blur-baby-image-<?php echo $this->bID; ?> img {
          width: <?php echo h($this->imageWidth); ?>px;
        }
        div.tallacmans-blur-baby-background-<?php echo $this->bID; ?> img {
          filter: blur(<?php echo h($this->blur); ?>px);
          transform: scale(<?php echo h($this->scale); ?>)
        }
        div.tallacmans-blur-baby-wrapper-<?php echo $this->bID; ?> {
          display: flex;
          justify-content: center;
          position: relative;
          margin-top: 3vw;
          margin-bottom: 3vw;
        }
        div.tallacmans-blur-baby-image-<?php echo $this->bID; ?> {
          position: relative;
          margin-right: 25px;
          margin-left: 25px;
          box-shadow: 2px 5px 14px -4px rgba(0, 0, 0, 0.5);
        }
        div.tallacmans-blur-baby-background-<?php echo $this->bID; ?> {
          position: absolute;
          overflow: hidden;
          width: 100%;
        }
        div.tallacmans-blur-baby-background-<?php echo $this->bID; ?> img {
          width: 100%;
        }

       <?php

        $styles = ob_get_contents();
        ob_end_clean();

        return $styles;
    }

    public function view()
    {
        if ($this->image && ($f = File::getByID($this->image)) && is_object($f)) {
            $this->set('image', $f);
        } else {
            $this->set('image', false);
        }

        $this->addHeaderItem('<style>'.$this->generate_styles().'</style>');
    }

    public function add()
    {
        $this->addEdit();

        $this->set('blur', 15);

        $this->set('scale', 1.4);

        $this->set('height', 90);

        $this->set('imageWidth', 700);

        $this->set('identifier_getString', '');

        $this->set('image_o', '');

        $this->set('placement', '');

    }

    public function edit()
    {
        $this->addEdit();
        $this->set('identifier_getString', '');

    }

    protected function addEdit()
    {
        $this->set('placement_options', [
            'flex-start' => t('Align Top'),
            'center' => t('Center'),
            'flex-end' => t('Align Bottom'),
        ]
        );

    }

    public function save($args)
    {
        $args['blur'] = trim($args['blur']) != '' ? number_format(floatval(str_replace(',', '.', $args['blur'])), 2, '.', '') : '';
        $args['scale'] = trim($args['scale']) != '' ? number_format(floatval(str_replace(',', '.', $args['scale'])), 2, '.', '') : '';
        $args['height'] = trim($args['height']) != '' ? number_format(floatval(str_replace(',', '.', $args['height'])), 2, '.', '') : '';
        $args['imageWidth'] = trim($args['imageWidth']) != '' ? number_format(floatval(str_replace(',', '.', $args['imageWidth'])), 2, '.', '') : '';

        parent::save($args);
    }

    public function validate($data)
    {
        $e = $this->app->make('error');

        if (($data['scale']) > '5') {
            $e->add(t('Scale needs to be between 1 and 5.'));
        }
        if (($data['scale']) < '1') {
            $e->add(t('Scale needs to be between 1 and 5.'));
        }
        if (($data['height']) < '1') {
            $e->add(t('Height needs to be between 1 and 200.'));
        }
        if (($data['height']) > '200') {
            $e->add(t('Height needs to be between 1 and 200.'));
        }
        if (($data['imageWidth']) < '1') {
            $e->add(t('Image width needs to be between 1 and 1200.'));
        }
        if (($data['imageWidth']) > '1200') {
            $e->add(t('Image width needs to be between 1 and 1200.'));
        }
        if (empty($data['image'])) {
            $e->add(t('You must choose an image.'));
        }

        return $e;
    }
}
