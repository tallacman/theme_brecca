<?php defined('C5_EXECUTE') or exit('Access Denied.');
$app = \Concrete\Core\Support\Facade\Application::getFacadeApplication();
?>

<div class="form-group">
    <?php
    if (isset($image) && $image > 0) {
        $image_o = File::getByID($image);
        if (! is_object($image_o)) {
            unset($image_o);
        }
    } ?>
    <?php echo $form->label('image', t('Image')); ?>
    <?php echo $app->make('helper/concrete/asset_library')->image('ccm-b-tallacmans_blur_baby-image-'.$identifier_getString, $view->field('image'), t('Choose Image'), $image_o); ?>
</div>

<div class="form-group">
    <?php echo $form->label($view->field('placement'), t('Image Placement')); ?>
    <?php echo $form->select($view->field('placement'), $placement_options, $placement, []); ?>
</div>
<!--   thank you @jtf  -->
<div class="form-group">
    <?php echo $form->label('imageWidth', t('Image Width')); ?><br>
    <?php echo t('Width in pixels.'); ?>
    <?php echo $form->number($view->field('imageWidth'), $imageWidth, ['min' => 1, 'max' => 10000]); ?>
</div>


<div class="form-group">
    <?php echo $form->label('blur', t('Blur Amount')); ?><br>
    <?php echo t('Blur in pixels. Allowed range 0 through 99.'); ?>
    <?php echo $form->number($view->field('blur'), $blur, ['min' => 0, 'max' => 99]); ?>
</div>

<div class="form-group">
    <?php echo $form->label('scale', t('Scale')); ?><br>
    <?php echo t('Scale allowed range 1.00 through 4.99.'); ?>
    <?php echo $form->number($view->field('scale'), $scale, ['min' => 1, 'max' => 5, 'step' => 0.01]); ?>
</div>

<div class="form-group">
    <?php echo $form->label('height', t('Height of Background Blur')); ?><br>
    <?php echo t('Scale allowed range 1 through 200. Larger than 100 may cause layout issues.'); ?>
    <?php echo $form->number($view->field('height'), $height, ['min' => 1, 'max' => 200]); ?>
</div>
