<?php

namespace Concrete\Package\TallacmansBlurBaby;

use Concrete\Core\Block\BlockType\BlockType;
use Concrete\Core\Package\Package;
use Concrete\Core\Support\Facade\Database;

defined('C5_EXECUTE') or exit('Access Denied.');

class Controller extends Package
{
    protected $pkgHandle = 'tallacmans_blur_baby';

    protected $appVersionRequired = '8.0.0';

    protected $pkgVersion = '1.0.0';

    public function getPackageName()
    {
        return t('Tallacmans Blur Baby');
    }

    public function getPackageDescription()
    {
        return t('Feature an image with a unique look.');
    }

    public function install()
    {
        $pkg = parent::install();
        $btHandles = [
            'tallacmans_blur_baby',
        ];

        foreach ($btHandles as $btHandle) {
            if (! BlockType::getByHandle($btHandle)) {
                BlockType::installBlockType($btHandle, $pkg);
            }
        }
    }

    public function uninstall()
    {
        // needs use Concrete\Core\Support\Facade\Database;
        // cleanup package on uninstall
        $pkg = parent::uninstall();

        // drop database table
        $db = Database::connection();
        $db->executeQuery('drop table if exists btTallacmansBlurBaby');
    }
}
