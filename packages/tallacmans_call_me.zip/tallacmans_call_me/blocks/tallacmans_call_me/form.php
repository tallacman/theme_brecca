<?php defined('C5_EXECUTE') or exit('Access Denied.'); ?>

<div class="form-group">
    <?php
      echo $form->label('callOrText', t('Call or text'));
echo $form->select(('callOrText'), $callOrText_options, $callOrText, []); ?>
</div>

<div class="form-group">
  <?php
echo $form->label('phoneNumber', t('Phone Number'));
echo '&nbsp;&nbsp;&nbsp;<small class="required">'.t('Required').'</small>';
echo $form->text(('phoneNumber'), $phoneNumber, [
    'maxlength' => 255,
    'placeholder' => t('your phone number'),
]); ?>
</div>

<div class="form-group">
    <?php
echo $form->label('displayText', t('Displayed text'));
echo '&nbsp;&nbsp;&nbsp;<small class="required">'.t('Required').'</small>';
echo $form->text(('displayText'), $displayText, [
    'maxlength' => 255,
    'placeholder' => t('viewer sees this'),
]); ?>
</div>

<div class="form-group">
    <?php
echo $form->label('displayAs', t('Display link as'));
echo $form->select(('displayAs'), $displayAs_options, $displayAs, []); ?>
</div>
