<?php defined('C5_EXECUTE') or exit('Access Denied.');
if ($displayAs == '1') { ?>
  <a class="btn btn-primary" href="<?php echo $callOrText_options[$callOrText]; ?>:<?php echo $phoneNumber; ?>">
    <?php echo h($displayText); ?>
  </a>
<?php } else { ?>
  <a href="<?php echo $callOrText_options[$callOrText]; ?>:<?php echo $phoneNumber; ?>">
    <<?php echo $displayAs_options[$displayAs]; ?>>
      <?php echo h($displayText); ?>
    </<?php echo $displayAs_options[$displayAs]; ?>>
  </a>
<?php }
?>
