<?php

namespace Concrete\Package\TallacmansCallMe;

use Concrete\Core\Block\BlockType\BlockType;
use Concrete\Core\Package\Package;
use Concrete\Core\Support\Facade\Database;

defined('C5_EXECUTE') or exit('Access Denied.');

class Controller extends Package
{
    protected $pkgHandle = 'tallacmans_call_me';

    protected $appVersionRequired = '8.0.0';

    protected $pkgVersion = '1.2';

    public function getPackageName()
    {
        return t("Tallacman's Call Me");
    }

    public function getPackageDescription()
    {
        return t('Click to call or text (sms).');
    }

    public function install()
    {
        $pkg = parent::install();
        $btHandles = [
            'tallacmans_call_me',
        ];
        foreach ($btHandles as $btHandle) {
            if (! BlockType::getByHandle($btHandle)) {
                BlockType::installBlockType($btHandle, $pkg);
            }
        }
    }

    public function uninstall()
    {
        // needs use Concrete\Core\Support\Facade\Database;
        // cleanup package on uninstall
        $pkg = parent::uninstall();

        // drop database table
        $db = Database::connection();
        $db->executeQuery('drop table if exists btTallacmansCallMe');
    }
}
