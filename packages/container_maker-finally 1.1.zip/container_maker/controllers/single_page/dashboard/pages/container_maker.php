<?php
namespace Concrete\Package\ContainerMaker\Controller\SinglePage\Dashboard\Pages;

use Concrete\Core\Page\Controller\DashboardPageController;
use Concrete\Core\Page\Theme\Theme as PageTheme;
use Concrete\Package\ContainerMaker\Service\ContainerGenerator;
use Concrete\Package\ContainerMaker\Service\ContainerManager;

class ContainerMaker extends DashboardPageController
{
    public function view()
    {
        $themes = $this->getInstalledThemes();
        $themeDebug = null;
        $activeTheme = $this->resolveActiveTheme($themeDebug);
        $selectedThemeID = (int) $this->request->query->get('themeID');
        if ($selectedThemeID <= 0 && is_object($activeTheme) && $activeTheme->getThemeID()) {
            $selectedThemeID = (int) $activeTheme->getThemeID();
        }
        if ($selectedThemeID <= 0 && !empty($themes)) {
            $selectedThemeID = (int) $themes[0]['id'];
        }

        $theme = $this->resolveThemeByID($selectedThemeID);
        if (!is_object($theme) || !$theme->getThemeID()) {
            $theme = $activeTheme;
            if (is_object($theme) && $theme->getThemeID()) {
                $selectedThemeID = (int) $theme->getThemeID();
            }
        }

        $registeredContainers = [];
        if (is_object($theme) && $theme->getThemeID()) {
            $manager = $this->app->make(ContainerManager::class);
            $registeredContainers = $manager->getRegisteredContainersForTheme($theme);
        }

        $editingContainer = null;
        $editHandle = (string) $this->request->query->get('edit');
        if ($editHandle !== '' && is_object($theme) && $theme->getThemeID()) {
            $editingContainer = $this->loadEditingContainer($registeredContainers, $editHandle);
            if ($editingContainer === null) {
                $this->error->add(t('That container was not created with Container Maker and cannot be edited here.'));
            } else {
                $editingContainer['theme_id'] = (int) $theme->getThemeID();
            }
        }

        $this->set('themes', $themes);
        $this->set('activeTheme', $activeTheme);
        $this->set('theme', $theme);
        $this->set('selectedThemeID', $selectedThemeID);
        $this->set('canSave', !empty($themes));
        $this->set('themeDebug', $themeDebug ?? null);
        $this->set('registeredContainers', $registeredContainers);
        $this->set('editingContainer', $editingContainer);
    }

    public function save()
    {
        if (!$this->token->validate('container_maker_save')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $themeID = (int) $this->request->request->get('themeID');
        $theme = $this->resolveThemeByID($themeID);
        if (!is_object($theme) || !$theme->getThemeID()) {
            $this->error->add(t('Please choose a valid theme.'));
            return $this->view();
        }

        $data = $this->request->request->all();
        $data['layout_mode'] = 'css_grid';
        $data['theme_id'] = (int) $theme->getThemeID();

        $generator = $this->app->make(ContainerGenerator::class);
        $result = $generator->generate($theme, $data);

        foreach ($result['created'] as $item) {
            $this->flash('success', t('Created container file: %s', $item));
        }
        foreach ($result['registered'] as $item) {
            $this->flash('success', t('Registered %s', $item));
        }
        foreach ($result['skipped'] as $item) {
            $this->flash('info', t('Skipped existing file %s. Check overwrite if you want to replace it.', $item));
        }
        foreach ($result['errors'] as $item) {
            $this->error->add($item);
        }

        return $this->buildRedirect('/dashboard/pages/container_maker?themeID=' . (int) $theme->getThemeID());
    }

    /** @deprecated Use save() — kept so old bookmarks still work. */
    public function build_flex()
    {
        return $this->save();
    }

    public function uninstall()
    {
        if (!$this->token->validate('container_maker_uninstall')) {
            $this->error->add($this->token->getErrorMessage());
            return $this->view();
        }

        $handle = (string) $this->request->request->get('containerHandle');
        $themeID = (int) $this->request->request->get('themeID');
        $confirm = (bool) $this->request->request->get('confirm');

        if (!$confirm) {
            $this->error->add(t('Please confirm before uninstalling a container.'));
            return $this->buildRedirect('/dashboard/pages/container_maker' . ($themeID ? '?themeID=' . $themeID : ''));
        }

        $manager = $this->app->make(ContainerManager::class);
        $result = $manager->uninstallByHandle($handle);
        if ($result === true) {
            $this->flash('success', t('Uninstalled container registration: %s', $handle));
        } else {
            $this->error->add($result);
        }

        return $this->buildRedirect('/dashboard/pages/container_maker' . ($themeID ? '?themeID=' . $themeID : ''));
    }

    protected function loadEditingContainer(array $registeredContainers, $handle)
    {
        foreach ($registeredContainers as $container) {
            if ($container['handle'] !== $handle) {
                continue;
            }
            if (empty($container['template_exists']) || empty($container['template_path'])) {
                return null;
            }
            $generator = $this->app->make(ContainerGenerator::class);
            $state = $generator->readDesignerState($container['template_path']);
            if (!is_array($state)) {
                return null;
            }
            $state['handle'] = $handle;
            $state['name'] = $container['name'];
            return $state;
        }
        return null;
    }

    protected function getInstalledThemes()
    {
        $rows = [];
        foreach (PageTheme::getList() as $theme) {
            if (!is_object($theme) || !$theme->getThemeID()) {
                continue;
            }
            $rows[] = [
                'id' => (int) $theme->getThemeID(),
                'name' => $theme->getThemeName(),
                'handle' => $theme->getThemeHandle(),
            ];
        }
        usort($rows, static function ($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });

        return $rows;
    }

    protected function resolveThemeByID($themeID)
    {
        $themeID = (int) $themeID;
        if ($themeID <= 0) {
            return null;
        }
        $theme = PageTheme::getByID($themeID);

        return (is_object($theme) && $theme->getThemeID()) ? $theme : null;
    }

    protected function resolveActiveTheme(&$debug = null)
    {
        try {
            $theme = PageTheme::getSiteTheme();
            if (is_object($theme) && $theme->getThemeID()) {
                return $theme;
            }
        } catch (\Throwable $e) {
            $debug = 'getSiteTheme() threw: ' . $e->getMessage();
        }

        try {
            $db = \Database::connection();
            $themeID = (int) $db->fetchOne('SELECT pThemeID FROM Sites ORDER BY siteID ASC LIMIT 1');
        } catch (\Throwable $e) {
            $themeID = 0;
            $debug = ($debug ? $debug . ' | ' : '') . 'Direct Sites query failed: ' . $e->getMessage();
        }

        if ($themeID > 0) {
            $fresh = PageTheme::getByID($themeID);
            if (is_object($fresh) && $fresh->getThemeID()) {
                return $fresh;
            }
            $debug = ($debug ? $debug . ' | ' : '') . 'Sites.pThemeID=' . $themeID . ' but theme record missing.';
        } else {
            $debug = ($debug ? $debug . ' | ' : '') . 'Sites.pThemeID is empty.';
        }

        return null;
    }
}
