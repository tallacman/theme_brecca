<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>

<?php
$pageUrl = $view->url('/dashboard/pages/container_maker');
$canSave = !empty($themes);
$hasTheme = is_object($theme) && $theme->getThemeID();
?>

<p class="text-muted mb-3">
    <?= t('Choose a theme, drag presets onto the grid, and compose complex layouts. Areas snap to column/row — no Bootstrap offsets needed.') ?>
</p>

<form method="post" action="<?= $view->action('save') ?>" id="cmForm" class="cm-app">
    <?php $token->output('container_maker_save'); ?>
    <input type="hidden" name="layout_mode" value="css_grid">
    <input type="hidden" name="areas" id="cmAreas" value="">
    <input type="hidden" name="area_placement" id="cmPlacement" value="">
    <input type="hidden" name="responsive_columns" id="cmResponsive" value="">
    <input type="hidden" name="area_full_rows" id="cmFullRows" value="">
    <input type="hidden" name="nested_areas" id="cmNested" value="">
    <input type="hidden" name="area_padding" id="cmPadding" value="">

    <div class="cm-workspace">
        <aside class="cm-palette">
            <div class="cm-panel-title"><?= t('Presets') ?></div>
            <p class="small text-muted mb-2"><?= t('Drop onto the canvas to add — stack as many as you need.') ?></p>
            <div id="cmPresets" class="cm-presets"></div>
            <button type="button" id="cmClear" class="btn btn-sm btn-outline-secondary w-100 mt-3"><?= t('Clear canvas') ?></button>
        </aside>

        <section class="cm-main">
            <div id="cmCanvas" class="cm-canvas">
                <div id="cmRowLines" class="cm-row-lines" aria-hidden="true"></div>
                <div id="cmColLines" class="cm-col-lines" aria-hidden="true"></div>
                <div id="cmTiles" class="cm-tiles"></div>
                <div id="cmDropHint" class="cm-drop-hint"><?= t('Drag presets here') ?></div>
            </div>

            <div id="cmSelection" class="cm-selection d-none">
                <div class="row g-2 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label mb-1"><?= t('Name') ?></label>
                        <input type="text" id="cmSelName" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label mb-1"><?= t('Column') ?></label>
                        <input type="number" id="cmSelCol" class="form-control form-control-sm" min="1" max="12">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label mb-1"><?= t('Span') ?></label>
                        <input type="number" id="cmSelSpan" class="form-control form-control-sm" min="1" max="12">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label mb-1"><?= t('Row') ?></label>
                        <input type="number" id="cmSelRow" class="form-control form-control-sm" min="1">
                    </div>
                    <div class="col-md-2">
                        <button type="button" id="cmSelDelete" class="btn btn-outline-danger btn-sm w-100"><?= t('Remove') ?></button>
                    </div>
                </div>
                <div class="form-check form-check-inline mt-2">
                    <input class="form-check-input" type="checkbox" id="cmSelFull">
                    <label class="form-check-label" for="cmSelFull"><?= t('Full row') ?></label>
                </div>
            </div>
        </section>

        <aside class="cm-code-wrap">
            <div class="cm-panel-title"><?= t('Generated code') ?></div>
            <pre id="cmCode" class="cm-code"></pre>
        </aside>
    </div>

    <div class="cm-toolbar">
        <div class="row g-2 align-items-end">
            <div class="col-lg-2">
                <label class="form-label" for="cmTheme"><?= t('Save to theme') ?></label>
                <select name="themeID" id="cmTheme" class="form-select form-select-sm">
                    <?php if (empty($themes)) { ?>
                        <option value=""><?= t('No themes installed') ?></option>
                    <?php } else { ?>
                        <?php foreach ($themes as $t) { ?>
                            <option value="<?= h($t['id']) ?>" <?= (int) $t['id'] === (int) $selectedThemeID ? 'selected' : '' ?>>
                                <?= h($t['name']) ?><?php if (is_object($activeTheme) && (int) $activeTheme->getThemeID() === (int) $t['id']) { ?> (<?= t('active') ?>)<?php } ?>
                            </option>
                        <?php } ?>
                    <?php } ?>
                </select>
            </div>
            <div class="col-lg-2">
                <label class="form-label" for="cmName"><?= t('Name') ?></label>
                <input type="text" name="name" id="cmName" class="form-control form-control-sm" required <?= $editingContainer ? '' : 'autofocus' ?>>
            </div>
            <div class="col-lg-2">
                <label class="form-label" for="cmHandle"><?= t('Handle') ?></label>
                <input type="text" name="handle" id="cmHandle" class="form-control form-control-sm" <?= $editingContainer ? 'readonly' : '' ?>>
            </div>
            <div class="col-lg-1">
                <label class="form-label" for="cmGap"><?= t('Gap') ?></label>
                <input type="text" name="gap" id="cmGap" class="form-control form-control-sm" value="1rem">
            </div>
            <div class="col-lg-2">
                <label class="form-label" for="cmInner"><?= t('Inner wrapper') ?></label>
                <select name="inner" id="cmInner" class="form-select form-select-sm">
                    <option value=""><?= t('None') ?></option>
                    <option value="container">container</option>
                    <option value="container-fluid">container-fluid</option>
                </select>
            </div>
            <div class="col-lg-3 d-flex gap-3 align-items-center flex-wrap">
                <div class="form-check mb-0">
                    <input class="form-check-input" type="checkbox" name="register" id="cmRegister" value="1" checked>
                    <label class="form-check-label" for="cmRegister"><?= t('Register') ?></label>
                </div>
                <div class="form-check mb-0">
                    <input class="form-check-input" type="checkbox" name="overwrite" id="cmOverwrite" value="1" <?= $editingContainer ? 'checked' : '' ?>>
                    <label class="form-check-label" for="cmOverwrite"><?= t('Overwrite') ?></label>
                </div>
                <button type="submit" class="btn btn-primary btn-sm" id="cmSaveBtn" <?= $canSave ? '' : 'disabled' ?>><?= t('Save') ?></button>
            </div>
        </div>
    </div>
</form>

<?php if ($hasTheme && !empty($registeredContainers)) { ?>
<details class="cm-installed mt-3">
    <summary class="text-muted"><?= t('Containers in %s (%s)', h($theme->getThemeName()), count($registeredContainers)) ?></summary>
    <div class="table-responsive mt-2">
        <table class="table table-sm table-striped mb-0">
            <thead><tr><th><?= t('Name') ?></th><th><?= t('Handle') ?></th><th></th></tr></thead>
            <tbody>
            <?php foreach ($registeredContainers as $container) { ?>
                <tr>
                    <td><?= h($container['name'] ?? '') ?></td>
                    <td><code><?= h($container['handle'] ?? '') ?></code></td>
                    <td class="text-end">
                        <?php if (!empty($container['template_exists'])) { ?>
                            <a class="btn btn-sm btn-outline-primary" href="<?= h($pageUrl) ?>?themeID=<?= (int) $selectedThemeID ?>&amp;edit=<?= h(urlencode($container['handle'] ?? '')) ?>"><?= t('Edit') ?></a>
                        <?php } ?>
                        <form method="post" action="<?= $view->action('uninstall') ?>" class="d-inline" onsubmit="return confirm('<?= h(t('Uninstall this container?')) ?>');">
                            <?php $token->output('container_maker_uninstall'); ?>
                            <input type="hidden" name="themeID" value="<?= (int) $selectedThemeID ?>">
                            <input type="hidden" name="containerHandle" value="<?= h($container['handle'] ?? '') ?>">
                            <input type="hidden" name="confirm" value="1">
                            <button class="btn btn-sm btn-outline-danger" type="submit"><?= t('Remove') ?></button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</details>
<?php } ?>

<style>
.cm-app{--cm-accent:#0d6efd;--cm-border:#dee2e6;--cm-bg:#f8f9fa;--cm-row-h:72px}
.cm-workspace{display:grid;grid-template-columns:190px minmax(0,1fr) minmax(220px,30%);gap:1rem;min-height:460px}
.cm-panel-title{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:#6c757d;margin-bottom:.35rem}
.cm-palette,.cm-code-wrap{background:var(--cm-bg);border:1px solid var(--cm-border);border-radius:.375rem;padding:.75rem}
.cm-presets{display:grid;gap:.45rem}
.cm-preset{display:flex;align-items:center;gap:.5rem;padding:.4rem .5rem;border:1px solid var(--cm-border);border-radius:.25rem;background:#fff;cursor:grab;font-size:.82rem;user-select:none}
.cm-preset:active{cursor:grabbing}
.cm-preset-icon{font-family:monospace;min-width:2.5rem;text-align:center;opacity:.65}
.cm-preset-preview{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:1px;width:2.5rem;height:.85rem;background:#ddd;border-radius:2px;overflow:hidden}
.cm-preset-preview span{background:var(--cm-accent);opacity:.6}
.cm-main{display:flex;flex-direction:column;gap:.65rem;min-width:0}
.cm-canvas{position:relative;flex:1;min-height:360px;background:#fff;border:2px dashed var(--cm-border);border-radius:.375rem;padding:1rem;transition:border-color .15s,background .15s}
.cm-canvas.cm-drag-over{border-color:var(--cm-accent);background:#f0f6ff}
.cm-col-lines,.cm-row-lines{position:absolute;inset:1rem;pointer-events:none;z-index:0}
.cm-col-lines{display:grid;grid-template-columns:repeat(12,minmax(0,1fr))}
.cm-col-lines span{border-left:1px dashed rgba(173,181,189,.45);height:100%}
.cm-row-lines{background:repeating-linear-gradient(to bottom,transparent 0,transparent calc(var(--cm-row-h) - 1px),rgba(173,181,189,.35) calc(var(--cm-row-h) - 1px),rgba(173,181,189,.35) var(--cm-row-h))}
.cm-tiles{position:relative;display:grid;grid-template-columns:repeat(12,minmax(0,1fr));grid-auto-rows:var(--cm-row-h);gap:var(--cm-gap,1rem);min-height:calc(var(--cm-row-h) * 3);z-index:1}
.cm-tile{grid-column:var(--col-start)/span var(--span,12);grid-row:var(--row,1);border:2px solid var(--cm-accent);background:rgba(13,110,253,.08);padding:.55rem .85rem;position:relative;cursor:grab;touch-action:none;align-self:stretch;display:flex;flex-direction:column;justify-content:center}
.cm-tile.active{box-shadow:0 0 0 3px rgba(13,110,253,.28)}
.cm-tile.cm-dragging{opacity:.88;z-index:5;cursor:grabbing}
.cm-tile-name{font-weight:600;font-size:.85rem;line-height:1.2}
.cm-tile-meta{font-size:.7rem;color:#6c757d;margin-top:.1rem}
.cm-tile-resize-left,.cm-tile-resize-right{position:absolute;top:0;width:10px;height:100%;cursor:col-resize;touch-action:none;z-index:2}
.cm-tile-resize-left{left:0}
.cm-tile-resize-right{right:0}
.cm-tile-resize-left::after,.cm-tile-resize-right::after{content:'';position:absolute;top:50%;width:4px;height:22px;transform:translateY(-50%);border-left:2px dotted rgba(0,0,0,.35);border-right:2px dotted rgba(0,0,0,.35)}
.cm-tile-resize-left::after{left:2px}
.cm-tile-resize-right::after{right:2px}
.cm-tile-resize-left:hover::after,.cm-tile-resize-right:hover::after,.cm-tile.active .cm-tile-resize-left::after,.cm-tile.active .cm-tile-resize-right::after{border-color:var(--cm-accent)}
.cm-drop-hint{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#adb5bd;font-size:.95rem;pointer-events:none;z-index:0}
.cm-tiles:not(:empty)~.cm-drop-hint{display:none}
.cm-selection{background:var(--cm-bg);border:1px solid var(--cm-border);border-radius:.375rem;padding:.65rem .75rem}
.cm-code{background:#1e1e1e;color:#d4d4d4;font-size:11px;line-height:1.45;padding:.75rem;border-radius:.25rem;max-height:400px;overflow:auto;margin:0;white-space:pre-wrap;word-break:break-word}
.cm-toolbar{margin-top:1rem;padding-top:1rem;border-top:1px solid var(--cm-border)}
.cm-installed summary{cursor:pointer}
@media (max-width:1199px){.cm-workspace{grid-template-columns:1fr}.cm-code-wrap{order:3}}
</style>

<script>
(function(){
    const EDIT = <?= $editingContainer ? json_encode($editingContainer) : 'null' ?>;
    const PAGE_URL = <?= json_encode($pageUrl) ?>;
    const ROW_H = 72;
    const PRESETS = [
        { id:'free', label:'<?= h(t('Free block')) ?>', areas:[{name:'Block',span:6}], hint:'<?= h(t('One area — drag edges to size, drag body to place')) ?>' },
        { id:'full', label:'<?= h(t('Full width')) ?>', areas:[{name:'Main',span:12}] },
        { id:'half', label:'<?= h(t('50 / 50')) ?>', areas:[{name:'Left',span:6},{name:'Right',span:6}] },
        { id:'thirds', label:'<?= h(t('Three columns')) ?>', areas:[{name:'Column 1',span:4},{name:'Column 2',span:4},{name:'Column 3',span:4}] },
        { id:'two-one', label:'<?= h(t('2/3 + 1/3')) ?>', areas:[{name:'Main',span:8},{name:'Aside',span:4}] },
        { id:'one-two', label:'<?= h(t('1/3 + 2/3')) ?>', areas:[{name:'Aside',span:4},{name:'Main',span:8}] },
        { id:'quarters', label:'<?= h(t('Four columns')) ?>', areas:[{name:'Col 1',span:3},{name:'Col 2',span:3},{name:'Col 3',span:3},{name:'Col 4',span:3}] },
        { id:'sidebar-left', label:'<?= h(t('Sidebar left')) ?>', areas:[{name:'Sidebar',span:3},{name:'Content',span:9}] },
        { id:'sidebar-right', label:'<?= h(t('Sidebar right')) ?>', areas:[{name:'Content',span:9},{name:'Sidebar',span:3}] },
        { id:'hero', label:'<?= h(t('Hero + content')) ?>', areas:[{name:'Hero',span:12,full:true},{name:'Content',span:12,full:true}] },
    ];
    const $ = id => document.getElementById(id);
    let handleTouched = false;
    let selected = -1;
    let areas = [];
    let drag = null;

    function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
    function slug(s){return (s||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'')||'container';}
    function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

    function usedNames(){return new Set(areas.map(a=>a.name));}
    function uniqueName(base){
        base = (base||'Area').trim() || 'Area';
        if(!usedNames().has(base)) return base;
        let i = 2;
        while(usedNames().has(base+' '+i)) i++;
        return base+' '+i;
    }

    function maxRow(){return areas.length ? Math.max(...areas.map(a=>a.row)) : 0;}

    function gridMetrics(){
        const tiles = $('cmTiles');
        const rect = tiles.getBoundingClientRect();
        return { rect, colW: rect.width / 12, rowH: ROW_H };
    }

    function pointerToCell(clientX, clientY, span){
        const { rect, colW, rowH } = gridMetrics();
        span = span || 1;
        let col = Math.floor((clientX - rect.left) / colW) + 1;
        let row = Math.floor((clientY - rect.top) / rowH) + 1;
        col = clamp(col, 1, 13 - span);
        row = Math.max(1, row);
        return { col, row };
    }

    function layoutPresetAreas(presetAreas, startCol, startRow){
        let col = startCol;
        let row = startRow;
        const out = [];
        presetAreas.forEach(a=>{
            const span = a.full ? 12 : a.span;
            if(col + span - 1 > 12){
                col = 1;
                row++;
            }
            const placeCol = a.full ? 1 : col;
            out.push({ name: uniqueName(a.name), col: placeCol, span, row, full: !!a.full, padding:'' });
            if(a.full){
                col = 1;
                row++;
            } else {
                col += span;
                if(col > 12){ col = 1; row++; }
            }
        });
        return out;
    }

    function nextFreeRow(){
        return maxRow() + 1;
    }

    function updateCanvasHeight(){
        const rows = Math.max(4, maxRow() + 2);
        $('cmCanvas').style.setProperty('--cm-rows', rows);
        $('cmRowLines').style.height = (rows * ROW_H) + 'px';
        $('cmTiles').style.minHeight = (rows * ROW_H) + 'px';
    }

    function presetPreviewHtml(list){
        if(list.length === 1 && !list[0].full){
            const span = list[0].span;
            const start = Math.max(1, Math.floor((12 - span) / 2) + 1);
            return '<span class="cm-preset-preview"><span style="grid-column:'+start+' / span '+span+'"></span></span>';
        }
        return '<span class="cm-preset-preview">'+list.map(a=>'<span style="grid-column:span '+(a.full?12:a.span)+'"></span>').join('')+'</span>';
    }

    function applyAreaToTile(a, tile){
        if(!tile) return;
        const span = a.full ? 12 : a.span;
        tile.style.setProperty('--col-start', a.full ? 1 : a.col);
        tile.style.setProperty('--span', span);
        tile.style.setProperty('--row', a.row);
        const meta = tile.querySelector('.cm-tile-meta');
        if(meta) meta.textContent = tileMeta(a);
    }

    function renderPresets(){
        $('cmPresets').innerHTML = PRESETS.map(p =>
            '<div class="cm-preset" draggable="true" data-preset="'+p.id+'" title="'+esc(p.hint || p.label)+'">'+presetPreviewHtml(p.areas)+'<span>'+esc(p.label)+'</span></div>'
        ).join('');
    }

    function buildColLines(){
        $('cmColLines').innerHTML = Array(12).fill('<span></span>').join('');
    }

    function tileMeta(a){
        const span = a.full ? 12 : a.span;
        return 'col '+a.col+' · span '+span+' · row '+a.row+(a.full?' · full':'');
    }

    function renderTiles(){
        const gap = $('cmGap').value || '1rem';
        $('cmTiles').style.setProperty('--cm-gap', gap);
        $('cmCanvas').style.setProperty('--cm-row-h', ROW_H+'px');
        updateCanvasHeight();
        $('cmTiles').innerHTML = areas.map((a,i)=>{
            const span = a.full ? 12 : a.span;
            const handles = a.full ? '' :
                '<div class="cm-tile-resize-left" data-resize="'+i+'" data-edge="left" title="<?= h(t('Resize from left')) ?>"></div>'
                +'<div class="cm-tile-resize-right" data-resize="'+i+'" data-edge="right" title="<?= h(t('Resize from right')) ?>"></div>';
            return '<div class="cm-tile'+(i===selected?' active':'')+'" data-i="'+i+'" style="--col-start:'+(a.full?1:a.col)+';--span:'+span+';--row:'+a.row+'">'
                +handles
                +'<div class="cm-tile-name">'+esc(a.name)+'</div>'
                +'<div class="cm-tile-meta">'+esc(tileMeta(a))+'</div></div>';
        }).join('');
        syncHidden();
        renderCode();
        syncSelectionPanel();
    }

    function syncHidden(){
        $('cmAreas').value = areas.map(a=>a.name).join('\n');
        $('cmPlacement').value = areas.map(a=>{
            const span = a.full ? 12 : a.span;
            return a.name+'::'+(a.full?1:a.col)+'|'+span+'|'+a.row;
        }).join('\n');
        $('cmResponsive').value = areas.map(a=>a.name+'::'+(a.full?12:a.span)+'|'+(a.full?12:a.span)+'|'+(a.full?12:a.span)).join('\n');
        $('cmFullRows').value = areas.filter(a=>a.full).map(a=>a.name).join('\n');
        $('cmNested').value = areas.map(a=>a.name).join('\n');
        $('cmPadding').value = areas.filter(a=>a.padding).map(a=>a.name+'::'+a.padding).join('\n');
    }

    function syncSelectionPanel(){
        const panel = $('cmSelection');
        if(selected < 0 || !areas[selected]){ panel.classList.add('d-none'); return; }
        panel.classList.remove('d-none');
        const a = areas[selected];
        $('cmSelName').value = a.name;
        $('cmSelCol').value = a.full ? 1 : a.col;
        $('cmSelSpan').value = a.full ? 12 : a.span;
        $('cmSelRow').value = a.row;
        $('cmSelFull').checked = !!a.full;
        $('cmSelCol').disabled = !!a.full;
        $('cmSelSpan').disabled = !!a.full;
    }

    function indent(text,n){const p=' '.repeat(n);return p+text.replace(/\n/g,'\n'+p);}
    function areaBlock(name){return "<?php\n$area = new ContainerArea($container, '"+name.replace(/'/g,"\\'")+"');\n$area->display($c);\n?>";}

    function renderCode(){
        const handle = slug($('cmHandle').value || $('cmName').value);
        const cls = 'cm-'+handle.replace(/_/g,'-');
        const gap = $('cmGap').value || '1rem';
        const inner = $('cmInner').value;
        const items = areas.map(a=>'<div class="'+cls+'__item">\n'+indent(areaBlock(a.name),4)+'\n</div>').join('\n');
        const grid = '<div class="'+cls+'__grid">\n'+indent(items,4)+'\n</div>';
        const wrapped = inner ? '<div class="'+inner+'">\n'+indent(grid,4)+'\n</div>' : grid;
        const body = '<div class="'+cls+'">\n'+indent(wrapped,4)+'\n</div>';
        const rules = ['.'+cls+'__grid { display: grid; grid-template-columns: repeat(12, minmax(0, 1fr)); grid-auto-rows: minmax(64px, auto); gap: '+gap+'; }'];
        areas.forEach((a,i)=>{
            const sel = '.'+cls+'__grid > *:nth-child('+(i+1)+')';
            const span = a.full ? 12 : a.span;
            if(a.full) rules.push(sel+' { grid-row: '+a.row+'; grid-column: 1 / -1; }');
            else rules.push(sel+' { grid-row: '+a.row+'; grid-column: '+a.col+' / span '+span+'; }');
        });
        rules.push('.ccm-edit-mode .'+cls+' .ccm-area { min-height: 48px; outline: 1px dashed rgba(0,0,0,.25); outline-offset: -1px; }');
        $('cmCode').textContent = "<?php\ndefined('C5_EXECUTE') or die('Access Denied.');\n\nuse Concrete\\Core\\Area\\ContainerArea;\n?>\n"+body+'\n<style>\n'+rules.join('\n')+'\n</style>\n';
    }

    function addPresetAt(presetId, clientX, clientY){
        const preset = PRESETS.find(p=>p.id===presetId);
        if(!preset) return;
        const start = areas.length ? pointerToCell(clientX, clientY, 12) : { col: 1, row: 1 };
        const placed = layoutPresetAreas(preset.areas, start.col, start.row);
        areas = areas.concat(placed);
        selected = areas.length - placed.length;
        renderTiles();
    }

    function loadEdit(ed){
        if(!ed) return;
        $('cmName').value = ed.name || '';
        $('cmHandle').value = ed.handle || '';
        handleTouched = true;
        if(ed.theme_id && $('cmTheme')) $('cmTheme').value = String(ed.theme_id);
        if(ed.settings){
            if(ed.settings.gap) $('cmGap').value = ed.settings.gap;
            if(ed.settings.inner !== undefined) $('cmInner').value = ed.settings.inner;
        }
        if(ed.areas && ed.areas.length){
            areas = ed.areas.map(a=>({
                name: a.name,
                col: parseInt(a.col,10) || 1,
                row: parseInt(a.row,10) || 1,
                span: parseInt(a.desktop,10) || 12,
                full: !!a.full,
                padding: a.padding || ''
            }));
            selected = 0;
        }
        renderTiles();
    }

    // Theme switch reloads container list for that theme
    function updateSaveBtn(){
        const btn = $('cmSaveBtn');
        if(btn) btn.disabled = !$('cmTheme').value;
    }
    $('cmTheme').addEventListener('change', ()=>{
        window.location = PAGE_URL + '?themeID=' + encodeURIComponent($('cmTheme').value);
    });
    updateSaveBtn();

    // Palette drag
    $('cmPresets').addEventListener('dragstart', e=>{
        const el = e.target.closest('[data-preset]');
        if(!el) return;
        e.dataTransfer.setData('text/cm-preset', el.dataset.preset);
        e.dataTransfer.effectAllowed = 'copy';
    });

    const canvas = $('cmCanvas');
    ['dragenter','dragover'].forEach(ev=>canvas.addEventListener(ev,e=>{e.preventDefault();canvas.classList.add('cm-drag-over');}));
    canvas.addEventListener('dragleave', e=>{ if(!canvas.contains(e.relatedTarget)) canvas.classList.remove('cm-drag-over'); });
    canvas.addEventListener('drop', e=>{
        e.preventDefault();
        canvas.classList.remove('cm-drag-over');
        const preset = e.dataTransfer.getData('text/cm-preset');
        if(preset) addPresetAt(preset, e.clientX, e.clientY);
    });

    $('cmClear').addEventListener('click', ()=>{
        if(areas.length && !confirm('<?= h(t('Clear all areas from the canvas?')) ?>')) return;
        areas = [];
        selected = -1;
        renderTiles();
    });

    // Tile interactions
    $('cmTiles').addEventListener('pointerdown', e=>{
        const resize = e.target.closest('[data-resize]');
        if(resize){
            e.preventDefault();
            const i = parseInt(resize.dataset.resize,10);
            const a = areas[i];
            if(a.full) return;
            selected = i;
            const { colW } = gridMetrics();
            drag = {
                type:'resize',
                edge: resize.dataset.edge || 'right',
                i,
                startX:e.clientX,
                startCol:a.col,
                startSpan:a.span,
                startRight:a.col + a.span - 1,
                colW,
                moved:false
            };
            resize.setPointerCapture(e.pointerId);
            syncSelectionPanel();
            renderTiles();
            return;
        }
        const tile = e.target.closest('.cm-tile');
        if(!tile || e.target.closest('[data-resize]')) return;
        e.preventDefault();
        selected = parseInt(tile.dataset.i,10);
        drag = { type:'move', i:selected, startX:e.clientX, startY:e.clientY, moved:false, span:areas[selected].full?12:areas[selected].span };
        tile.setPointerCapture(e.pointerId);
        syncSelectionPanel();
        renderTiles();
    });

    document.addEventListener('pointermove', e=>{
        if(!drag) return;
        if(drag.type==='resize'){
            e.preventDefault();
            drag.moved = true;
            const delta = Math.round((e.clientX - drag.startX) / drag.colW);
            const a = areas[drag.i];
            a.full = false;
            if(drag.edge === 'left'){
                const newCol = clamp(drag.startCol + delta, 1, drag.startRight);
                a.col = newCol;
                a.span = drag.startRight - newCol + 1;
            } else {
                a.span = clamp(drag.startSpan + delta, 1, 13 - drag.startCol);
                a.col = drag.startCol;
            }
            applyAreaToTile(a, document.querySelector('.cm-tile[data-i="'+drag.i+'"]'));
            syncHidden();
            renderCode();
            syncSelectionPanel();
        } else if(drag.type==='move'){
            if(Math.hypot(e.clientX-drag.startX, e.clientY-drag.startY) < 8) return;
            e.preventDefault();
            drag.moved = true;
            const { col, row } = pointerToCell(e.clientX, e.clientY, drag.span);
            const a = areas[drag.i];
            if(!a.full){ a.col = col; }
            a.row = row;
            const tile = document.querySelector('.cm-tile[data-i="'+drag.i+'"]');
            if(tile) tile.classList.add('cm-dragging');
            applyAreaToTile(a, tile);
            updateCanvasHeight();
            syncHidden();
            renderCode();
            syncSelectionPanel();
        }
    });

    document.addEventListener('pointerup', ()=>{
        if(!drag) return;
        document.querySelectorAll('.cm-tile.cm-dragging').forEach(t=>t.classList.remove('cm-dragging'));
        if(drag.moved) renderTiles();
        drag = null;
    });

    // Selection panel
    $('cmSelName').addEventListener('input', e=>{ if(areas[selected]){ areas[selected].name=e.target.value; renderTiles(); }});
    $('cmSelCol').addEventListener('input', e=>{ if(areas[selected]&&!areas[selected].full){ areas[selected].col=clamp(parseInt(e.target.value,10)||1,1,12); renderTiles(); }});
    $('cmSelSpan').addEventListener('input', e=>{ if(areas[selected]&&!areas[selected].full){ areas[selected].span=clamp(parseInt(e.target.value,10)||1,1,12); renderTiles(); }});
    $('cmSelRow').addEventListener('input', e=>{ if(areas[selected]){ areas[selected].row=Math.max(1,parseInt(e.target.value,10)||1); renderTiles(); }});
    $('cmSelFull').addEventListener('change', e=>{ if(areas[selected]){ areas[selected].full=e.target.checked; if(e.target.checked){ areas[selected].col=1; areas[selected].span=12; } renderTiles(); }});
    $('cmSelDelete').addEventListener('click', ()=>{
        if(selected < 0) return;
        areas.splice(selected,1);
        selected = areas.length ? Math.min(selected, areas.length-1) : -1;
        renderTiles();
    });

    ['cmName','cmHandle','cmGap','cmInner'].forEach(id=>{
        $(id).addEventListener('input', ()=>{
            if(id==='cmName' && !handleTouched) $('cmHandle').value = slug($('cmName').value);
            if(id==='cmHandle') handleTouched = true;
            renderTiles();
        });
    });

    $('cmForm').addEventListener('submit', e=>{
        if(!areas.length){
            e.preventDefault();
            alert('<?= h(t('Add at least one area before saving.')) ?>');
        }
    });

    buildColLines();
    renderPresets();
    loadEdit(EDIT);
    renderTiles();
})();
</script>
