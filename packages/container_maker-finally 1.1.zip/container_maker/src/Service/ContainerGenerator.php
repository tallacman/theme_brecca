<?php
namespace Concrete\Package\ContainerMaker\Service;

use Concrete\Core\Page\Theme\Theme;

class ContainerGenerator
{
    public function readDesignerState($filePath)
    {
        if (!$filePath || !is_file($filePath)) {
            return null;
        }
        $contents = @file_get_contents($filePath);
        if ($contents === false) {
            return null;
        }
        if (!preg_match('/CM_DESIGNER_STATE\s+([A-Za-z0-9+\/=]+)\s+CM_DESIGNER_STATE_END/', $contents, $m)) {
            return null;
        }
        $json = base64_decode($m[1], true);
        if ($json === false) {
            return null;
        }
        $data = json_decode($json, true);
        return is_array($data) ? $data : null;
    }

    /** @deprecated Use generate() */
    public function generateFlex(Theme $theme, array $data)
    {
        return $this->generate($theme, $data);
    }

    public function generate(Theme $theme, array $data)
    {
        $result = ['created' => [], 'registered' => [], 'skipped' => [], 'errors' => []];
        $themePath = $this->getThemePath($theme);
        if (!$themePath || !is_dir($themePath)) {
            $result['errors'][] = t('Could not find the selected theme directory.');
            return $result;
        }

        $name = trim((string) ($data['name'] ?? ''));
        $handle = $this->sanitizeHandle((string) ($data['handle'] ?? ''));
        if ($name === '') {
            $name = t('Grid Container');
        }
        if ($handle === '') {
            $handle = $this->sanitizeHandle($name);
        }
        if ($handle === '') {
            $result['errors'][] = t('Please enter a valid container handle.');
            return $result;
        }

        $areas = $this->parseAreaNames((string) ($data['areas'] ?? 'Main'));
        if (empty($areas)) {
            $result['errors'][] = t('Please add at least one area.');
            return $result;
        }

        $responsiveColumns = $this->parseResponsiveColumns((string) ($data['responsive_columns'] ?? ''), $areas);
        $areaPlacement = $this->parseAreaPlacement((string) ($data['area_placement'] ?? ''), $areas);
        $areaFullRows = $this->parseAreaFullRows((string) ($data['area_full_rows'] ?? ''), $areas);
        $nestedAreas = $this->parseAreaFullRows((string) ($data['nested_areas'] ?? ''), $areas);
        $areaPadding = $this->parseAreaPadding((string) ($data['area_padding'] ?? ''), $areas);
        $settings = $this->normalizeSettings($data);

        $containerDir = rtrim($themePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'elements' . DIRECTORY_SEPARATOR . 'containers';
        if (!is_dir($containerDir) && !@mkdir($containerDir, 0755, true)) {
            $result['errors'][] = t('Could not create directory: %s', $containerDir);
            return $result;
        }

        $file = $containerDir . DIRECTORY_SEPARATOR . $handle . '.php';
        $overwrite = !empty($data['overwrite']);
        if (file_exists($file) && !$overwrite) {
            $result['skipped'][] = $file;
        } else {
            $php = $this->buildContainerPhp($handle, $name, $areas, $settings, $areaFullRows, $responsiveColumns, $nestedAreas, $areaPadding, $areaPlacement);
            if (@file_put_contents($file, $php) === false) {
                $result['errors'][] = t('Could not write file: %s', $file);
                return $result;
            }
            $result['created'][] = $file;
        }

        if (!empty($data['register'])) {
            $registered = $this->tryRegisterContainer($handle, $name);
            if ($registered === true) {
                $result['registered'][] = $name . ' (' . $handle . ')';
            } elseif (is_string($registered)) {
                $result['errors'][] = $registered;
            }
        }

        return $result;
    }

    protected function buildContainerPhp($handle, $name, array $areas, array $settings, array $areaFullRows, array $responsiveColumns, array $nestedAreas, array $areaPadding, array $areaPlacement = [])
    {
        $class = 'cm-' . str_replace('_', '-', $handle);
        $inner = $settings['inner'];

        $designerState = base64_encode(json_encode([
            'name' => $name,
            'handle' => $handle,
            'layout_mode' => 'css_grid',
            'theme_id' => (int) ($settings['theme_id'] ?? 0),
            'settings' => [
                'gap' => $settings['gap'],
                'inner' => $settings['inner'],
            ],
            'areas' => array_map(static function ($areaName) use ($responsiveColumns, $areaFullRows, $areaPadding, $areaPlacement, $nestedAreas) {
                $placement = $areaPlacement[$areaName] ?? [];
                return [
                    'name' => $areaName,
                    'col' => (int) ($placement['col'] ?? 1),
                    'row' => (int) ($placement['row'] ?? 1),
                    'desktop' => (int) ($responsiveColumns[$areaName]['desktop'] ?? ($placement['span'] ?? 12)),
                    'tablet' => (int) ($responsiveColumns[$areaName]['tablet'] ?? ($placement['span'] ?? 12)),
                    'mobile' => (int) ($responsiveColumns[$areaName]['mobile'] ?? ($placement['span'] ?? 12)),
                    'full' => in_array($areaName, $areaFullRows, true),
                    'nested' => in_array($areaName, $nestedAreas, true),
                    'padding' => $areaPadding[$areaName] ?? '',
                ];
            }, $areas),
        ]));

        [$body, $style] = $this->buildCssGridMarkup($class, $inner, $areas, $areaFullRows, $responsiveColumns, $settings, $areaPadding, $areaPlacement);

        return <<<PHP
<?php
defined('C5_EXECUTE') or die('Access Denied.');

/* CM_DESIGNER_STATE {$designerState} CM_DESIGNER_STATE_END */

use Concrete\Core\Area\ContainerArea;
?>
{$body}
{$style}

PHP;
    }

    protected function areaPhpBlock($areaName)
    {
        $escapedName = addslashes($areaName);

        return "<?php\n"
            . '$area = new ContainerArea($container, \'' . $escapedName . "');\n"
            . "\$area->display(\$c);\n"
            . '?>';
    }

    protected function indentLines($text, $spaces)
    {
        $prefix = str_repeat(' ', $spaces);

        return $prefix . str_replace("\n", "\n" . $prefix, rtrim((string) $text));
    }

    protected function wrapInner($inner, $content)
    {
        if ($inner === '') {
            return $content;
        }

        return '<div class="' . $inner . "\">\n" . $this->indentLines($content, 4) . "\n</div>";
    }

    protected function wrapStyle($class, array $rules, $mediaExtra = '')
    {
        $lines = $rules;
        $lines[] = '.ccm-edit-mode .' . $class . ' .ccm-area { min-height: 48px; outline: 1px dashed rgba(0, 0, 0, .25); outline-offset: -1px; }';
        $css = implode("\n", $lines);
        if ($mediaExtra !== '') {
            $css .= "\n" . rtrim($mediaExtra);
        }

        return "<style>\n{$css}\n</style>";
    }

    protected function buildCssGridMarkup($class, $inner, array $areas, array $areaFullRows, array $responsiveColumns, array $settings, array $areaPadding = [], array $areaPlacement = [])
    {
        $items = [];
        $desktopRules = [];
        $tabletRules = [];
        $mobileRules = [];
        $maxRow = 1;
        $i = 0;
        foreach ($areas as $areaName) {
            $i++;
            $placement = $areaPlacement[$areaName] ?? ['col' => 1, 'span' => 12, 'row' => 1];
            $row = max(1, (int) ($placement['row'] ?? 1));
            $maxRow = max($maxRow, $row);
            $items[] = '<div class="' . $class . "__item\">\n" . $this->indentLines($this->areaPhpBlock($areaName), 4) . "\n</div>";
            $selector = '.' . $class . '__grid > *:nth-child(' . $i . ')';
            $ruleParts = ['grid-row: ' . $row];
            if (in_array($areaName, $areaFullRows, true)) {
                $ruleParts[] = 'grid-column: 1 / -1';
            } else {
                $col = max(1, min(12, (int) ($placement['col'] ?? 1)));
                $desktop = (int) ($responsiveColumns[$areaName]['desktop'] ?? ($placement['span'] ?? 12));
                $tablet = (int) ($responsiveColumns[$areaName]['tablet'] ?? $desktop);
                $mobile = (int) ($responsiveColumns[$areaName]['mobile'] ?? $tablet);
                $desktop = max(1, min(12, $desktop));
                $col = min($col, 13 - $desktop);
                $ruleParts[] = 'grid-column: ' . $col . ' / span ' . $desktop;
                if ($tablet !== $desktop) {
                    $tabletRules[] = $selector . ' { grid-column: ' . $col . ' / span ' . max(1, min(12, $tablet)) . '; }';
                }
                if ($mobile !== $tablet) {
                    $mobileRules[] = $selector . ' { grid-column: ' . $col . ' / span ' . max(1, min(12, $mobile)) . '; }';
                }
            }
            if (!empty($areaPadding[$areaName])) {
                $ruleParts[] = 'padding: ' . $areaPadding[$areaName];
            }
            $desktopRules[] = $selector . ' { ' . implode('; ', $ruleParts) . '; }';
        }
        $itemsHtml = $this->indentLines(implode("\n", $items), 4);
        $grid = '<div class="' . $class . "__grid\">\n{$itemsHtml}\n</div>";

        $content = $this->indentLines($this->wrapInner($inner, $grid), 4);
        $body = '<div class="' . $class . "\">\n{$content}\n</div>";

        $rules = array_merge(
            [
                '.' . $class . '__grid { display: grid; grid-template-columns: repeat(12, minmax(0, 1fr)); grid-auto-rows: minmax(64px, auto); gap: ' . $settings['gap'] . '; }',
            ],
            $desktopRules
        );
        $media = '';
        if (!empty($tabletRules)) {
            $media .= "@media (max-width: 991px) {\n    " . implode("\n    ", $tabletRules) . "\n}\n";
        }
        if (!empty($mobileRules)) {
            $media .= "@media (max-width: 767px) {\n    " . implode("\n    ", $mobileRules) . "\n}\n";
        }
        $style = $this->wrapStyle($class, $rules, $media);

        return [$body, $style];
    }

    protected function parseAreaNames($input)
    {
        $parts = preg_split('/[\r\n,]+/', $input);
        $areas = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $areas[] = $part;
            }
        }
        return array_values(array_unique($areas));
    }

    protected function parseAreaPlacement($input, array $areas)
    {
        $placement = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_map('intval', array_pad(explode('|', $value), 3, 1));
            $placement[$area] = [
                'col' => max(1, min(12, $parts[0])),
                'span' => max(1, min(12, $parts[1])),
                'row' => max(1, $parts[2]),
            ];
        }

        return $placement;
    }

    protected function parseResponsiveColumns($input, array $areas)
    {
        $columns = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area === '' || !in_array($area, $areas, true)) {
                continue;
            }
            $parts = array_map('intval', array_pad(explode('|', $value), 3, 12));
            $columns[$area] = [
                'desktop' => max(1, min(12, $parts[0])),
                'tablet' => max(1, min(12, $parts[1])),
                'mobile' => max(1, min(12, $parts[2])),
            ];
        }
        return $columns;
    }

    protected function parseAreaFullRows($input, array $areas)
    {
        $fullRows = [];
        $lines = preg_split('/[\r\n,]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && in_array($line, $areas, true)) {
                $fullRows[] = $line;
            }
        }
        return array_values(array_unique($fullRows));
    }

    protected function parseAreaPadding($input, array $areas)
    {
        $padding = [];
        $lines = preg_split('/[\r\n]+/', $input);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '::') === false) {
                continue;
            }
            [$area, $value] = array_map('trim', explode('::', $line, 2));
            if ($area !== '' && in_array($area, $areas, true) && $value !== '') {
                $padding[$area] = $this->safeCssLengthList($value, $value);
            }
        }
        return $padding;
    }

    protected function normalizeSettings(array $data)
    {
        return [
            'inner' => $this->inList($data['inner'] ?? '', ['container', 'container-fluid', ''], ''),
            'gap' => $this->safeCssLength($data['gap'] ?? '1rem', '1rem'),
            'theme_id' => (int) ($data['theme_id'] ?? 0),
        ];
    }

    protected function sanitizeHandle($handle)
    {
        $handle = strtolower(trim($handle));
        $handle = preg_replace('/[^a-z0-9]+/', '_', $handle);

        return trim($handle, '_');
    }

    protected function inList($value, array $allowed, $default)
    {
        $value = (string) $value;

        return in_array($value, $allowed, true) ? $value : $default;
    }

    protected function safeCssLength($value, $default)
    {
        $value = trim((string) $value);

        return preg_match('/^[-0-9.]+(px|rem|em|%|vw|vh)?$/', $value) ? $value : $default;
    }

    protected function safeCssLengthList($value, $default)
    {
        $value = trim((string) $value);

        return preg_match('/^[-0-9. ]+(px|rem|em|%|vw|vh)?( [-0-9.]+(px|rem|em|%|vw|vh)?){0,3}$/', $value) ? $value : $default;
    }

    protected function getThemePath(Theme $theme)
    {
        if (method_exists($theme, 'getThemeDirectory')) {
            $dir = $theme->getThemeDirectory();
            if ($dir && is_dir($dir)) {
                return $dir;
            }
        }

        $handle = $theme->getThemeHandle();
        $paths = [
            DIR_BASE . '/application/themes/' . $handle,
            DIR_BASE . '/themes/' . $handle,
            DIR_BASE_CORE . '/themes/' . $handle,
        ];
        foreach ($paths as $path) {
            if (is_dir($path)) {
                return $path;
            }
        }
        return null;
    }

    protected function tryRegisterContainer($handle, $name)
    {
        $classes = [
            '\\Concrete\\Core\\Entity\\Page\\Container',
            '\\Concrete\\Core\\Entity\\Page\\ContainerTemplate',
        ];

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                continue;
            }
            try {
                $app = \Core::make('app');
                $em = $app->make('database/orm')->entityManager();
                $repo = $em->getRepository($class);
                $existing = method_exists($repo, 'findOneBy') ? $repo->findOneBy(['containerHandle' => $handle]) : null;
                if ($existing) {
                    return true;
                }
                $entity = new $class();
                if (method_exists($entity, 'setContainerName')) {
                    $entity->setContainerName($name);
                }
                if (method_exists($entity, 'setContainerHandle')) {
                    $entity->setContainerHandle($handle);
                }
                $em->persist($entity);
                $em->flush();

                return true;
            } catch (\Throwable $e) {
                return t('Created file for %s, but automatic registration failed: %s', $handle, $e->getMessage());
            }
        }

        return t('Created file for %s, but automatic registration is not available. Add it manually in Dashboard → Pages & Themes → Containers.', $handle);
    }
}
